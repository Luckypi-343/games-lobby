"use client"

import { useEffect, useRef } from "react"
import type { PuzzleGame } from "@/lib/luckypi/data"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { puzzleGameText, puzzleCommonText } from "@/lib/luckypi/puzzle-i18n"
import { PuzzleHeader } from "@/components/luckypi/puzzle-header"
import { TicTacToeView } from "@/components/games/tictactoe-view"
import { GomokuView } from "@/components/games/gomoku-view"
import { OthelloView } from "@/components/games/othello-view"
import { CheckersView } from "@/components/games/checkers-view"
import { GoView } from "@/components/games/go-view"
import { XiangqiView } from "@/components/games/xiangqi-view"
import { DarkChessView } from "@/components/games/darkchess-view"
import { LuzhanqiView } from "@/components/games/luzhanqi-view"
import { MahjongView } from "@/components/games/mahjong-view"
import { ChessView } from "@/components/games/chess-view"
import { ChineseCheckersView } from "@/components/games/chinese-checkers-view"
import { LudoView } from "@/components/games/ludo-view"
import { SolitaireView } from "@/components/games/solitaire-view"
import { RummikubView } from "@/components/games/rummikub-view"
import { Connect4View } from "@/components/games/connect4-view"
import { RpsView } from "@/components/games/rps-view"
import { SlidingPuzzleView } from "@/components/games/sliding-puzzle-view"
import { NumberMergeView } from "@/components/games/number-merge-view"
import { MemoryMatchView } from "@/components/games/memory-match-view"
import { TexasHoldemView } from "@/components/games/texas-holdem-view"
import { BlackjackView } from "@/components/games/blackjack-view"
import { BaccaratView } from "@/components/games/baccarat-view"
import { WarView } from "@/components/games/war-view"
import { ThreeCardPokerView } from "@/components/games/three-card-poker-view"
import { KlotskiView } from "@/components/games/klotski-view"
import { TetrisView } from "@/components/games/tetris-view"
import { BubbleShooterView } from "@/components/games/bubble-shooter-view"
import { Match3View } from "@/components/games/match3-view"
import { HanoiView } from "@/components/games/hanoi-view"
import { WaterSortView } from "@/components/games/water-sort-view"
import { PipeConnectView } from "@/components/games/pipe-connect-view"
import { StackTowerView } from "@/components/games/stack-tower-view"
import { SequenceSortView } from "@/components/games/sequence-sort-view"
import { MiniSudokuView } from "@/components/games/mini-sudoku-view"
import { ShootingRangeView } from "@/components/games/shooting-range-view"
import { SpaceInvadersView } from "@/components/games/space-invaders-view"
import { TankBattleView } from "@/components/games/tank-battle-view"
import { BrickBreakerView } from "@/components/games/brick-breaker-view"
import { ZombieDefenseView } from "@/components/games/zombie-defense-view"
import { AirCombatView } from "@/components/games/air-combat-view"
import { DuelArenaView } from "@/components/games/duel-arena-view"
import { PenaltyKickView } from "@/components/games/penalty-kick-view"
import { RacingView } from "@/components/games/racing-view"
import { ParkingView } from "@/components/games/parking-view"
import { MotocrossView } from "@/components/games/motocross-view"
import { DriftRacingView } from "@/components/games/drift-racing-view"
import { TenHalfView } from "@/components/games/ten-half-view"
  import { SevenPkView } from "@/components/games/seven-pk-view"
  import { SevenPkView as SevenPkRealView } from "@/components/games/seven-pk-real-view"
  import { StudPokerView } from "@/components/games/stud-poker-view"
import { NiuniuView } from "@/components/games/niuniu-view"
import { ZhaJinhuaView } from "@/components/games/zha-jinhua-view"
import { ThirteenWaterView } from "@/components/games/thirteen-water-view"
import { BigTwoView } from "@/components/games/big-two-view"
import { BridgeView } from "@/components/games/bridge-view"
import { PickRedPointsView } from "@/components/games/pick-red-points-view"
 import { DouDizhuView } from "@/components/games/dou-dizhu-view"
 import { LittleMaryView } from "@/components/games/little-mary-view"
 import { LittleMary2View } from "@/components/games/little-mary-2-view"
 import { LittleMary3View } from "@/components/games/little-mary-3-view"
 import { LittleMary4View } from "@/components/games/little-mary-4-view"
import { LittleMary5View } from "@/components/games/little-mary-5-view"
 import { LittleMary6View } from "@/components/games/little-mary-6-view"
 import { LittleMary7View } from "@/components/games/little-mary-7-view"
 import { LittleMary8View } from "@/components/games/little-mary-8-view"
 import { FruitSlot1View } from "@/components/games/fruit-slot-1-view"
 import { FruitSlot2View } from "@/components/games/fruit-slot-2-view"

function ComingSoonView({
  game,
  name,
  subtitle,
  onBack,
}: {
  game: PuzzleGame
  name: string
  subtitle: string
  onBack: () => void
}) {
  const { lang } = useLuckyPi()
  const common = puzzleCommonText(lang)
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
      <p className="font-serif text-2xl font-bold text-primary">{name}</p>
      <p className="text-sm text-muted-foreground">{subtitle}</p>
      <p className="max-w-xs text-sm text-muted-foreground">{common.comingSoonText}</p>
      <button
        onClick={onBack}
        className="rounded-full bg-primary px-6 py-2 text-sm font-semibold text-primary-foreground transition active:scale-95"
      >
        {common.backToLobby}
      </button>
    </div>
  )
}

function GameBody({
  game,
  name,
  subtitle,
  onBack,
  onHome,
}: {
  game: PuzzleGame
  name: string
  subtitle: string
  onBack: () => void
  onHome: () => void
}) {
  switch (game.id) {
    case "ten-half":
      return <TenHalfView onHome={onHome} onLobby={onBack} />
  case "five-pk":
  return <SevenPkView onHome={onHome} onLobby={onBack} />
  case "seven-pk":
  return <SevenPkRealView onHome={onHome} onLobby={onBack} />
  case "stud-poker":
      return <StudPokerView onHome={onHome} onLobby={onBack} />
    case "niuniu":
      return <NiuniuView onHome={onHome} onLobby={onBack} />
 case "zha-jinhua":
 return <ZhaJinhuaView onHome={onHome} onLobby={onBack} />
      case "little-mary":
        return <LittleMaryView onHome={onHome} onLobby={onBack} />
 case "little-mary-2":
 return <LittleMary2View onHome={onHome} onLobby={onBack} />
 case "little-mary-3":
 return <LittleMary3View onHome={onHome} onLobby={onBack} />
    case "little-mary-4":
      return <LittleMary4View onHome={onHome} onLobby={onBack} />
    case "little-mary-5":
      return <LittleMary5View onHome={onHome} onLobby={onBack} />
 case "little-mary-6":
 return <LittleMary6View onHome={onHome} onLobby={onBack} />
 case "little-mary-7":
 return <LittleMary7View onHome={onHome} onLobby={onBack} />
 case "little-mary-8":
 return <LittleMary8View onHome={onHome} onLobby={onBack} />
 case "fruit-slot-1":
 return <FruitSlot1View onHome={onHome} onLobby={onBack} />
 case "fruit-slot-2":
 return <FruitSlot2View onHome={onHome} onLobby={onBack} />
    case "thirteen-water":
      return <ThirteenWaterView onHome={onHome} onLobby={onBack} />
    case "big-two":
      return <BigTwoView onHome={onHome} onLobby={onBack} />
    case "bridge":
      return <BridgeView onBack={onBack} />
    case "pick-red-points":
      return <PickRedPointsView onBack={onBack} />
    case "dou-dizhu":
      return <DouDizhuView onBack={onBack} />
    case "tictactoe":
      return <TicTacToeView onBack={onBack} />
    case "gomoku":
      return <GomokuView onBack={onBack} />
    case "othello":
      return <OthelloView onBack={onBack} />
    case "checkers":
      return <CheckersView onBack={onBack} />
    case "go":
      return <GoView onBack={onBack} />
    case "xiangqi":
      return <XiangqiView onBack={onBack} />
    case "darkchess-classic":
      return <DarkChessView onBack={onBack} variant="traditional" />
    case "darkchess-variant":
      return <DarkChessView onBack={onBack} variant="variant" />
    case "luzhanqi":
      return <LuzhanqiView onBack={onBack} />
    case "mahjong":
      return <MahjongView onBack={onBack} />
    case "connect4":
      return <Connect4View onBack={onBack} />
    case "rps-battle":
      return <RpsView onBack={onBack} />
    case "chess":
      return <ChessView onBack={onBack} />
    case "chinese-checkers":
      return <ChineseCheckersView onBack={onBack} />
    case "ludo":
      return <LudoView onBack={onBack} />
    case "solitaire":
      return <SolitaireView onBack={onBack} />
    case "rummikub":
      return <RummikubView onBack={onBack} />
    case "jigsaw":
      return <SlidingPuzzleView onBack={onBack} />
    case "number-merge":
      return <NumberMergeView onBack={onBack} />
    case "memory-match":
      return <MemoryMatchView onBack={onBack} />
    case "texas-holdem":
      return <TexasHoldemView onBack={onBack} />
    case "blackjack":
      return <BlackjackView onBack={onBack} />
    case "baccarat":
      return <BaccaratView onBack={onBack} />
    case "war":
      return <WarView onBack={onBack} />
    case "three-card-poker":
      return <ThreeCardPokerView onBack={onBack} />
    case "klotski":
      return <KlotskiView onBack={onBack} />
    case "tetris":
      return <TetrisView onBack={onBack} />
    case "bubble-shooter":
      return <BubbleShooterView onBack={onBack} />
    case "match3":
      return <Match3View onBack={onBack} />
    case "hanoi":
      return <HanoiView onBack={onBack} />
    case "water-sort":
      return <WaterSortView onBack={onBack} />
    case "pipe-connect":
      return <PipeConnectView onBack={onBack} />
    case "stack-tower":
      return <StackTowerView onBack={onBack} />
    case "sequence-sort":
      return <SequenceSortView onBack={onBack} />
    case "mini-sudoku":
      return <MiniSudokuView onBack={onBack} />
    case "shooting-range":
      return <ShootingRangeView onBack={onBack} />
    case "space-invaders":
      return <SpaceInvadersView onBack={onBack} />
    case "tank-battle":
      return <TankBattleView onBack={onBack} />
    case "brick-breaker":
      return <BrickBreakerView onBack={onBack} />
    case "zombie-defense":
      return <ZombieDefenseView onBack={onBack} />
    case "air-combat":
      return <AirCombatView onBack={onBack} />
    case "duel-arena":
      return <DuelArenaView onBack={onBack} />
    case "penalty-kick":
      return <PenaltyKickView onBack={onBack} />
    case "racing":
      return <RacingView onBack={onBack} />
    case "parking":
      return <ParkingView onBack={onBack} />
    case "motocross":
      return <MotocrossView onBack={onBack} />
    case "drift-racing":
      return <DriftRacingView onBack={onBack} />
    default:
      return <ComingSoonView game={game} name={name} subtitle={subtitle} onBack={onBack} />
  }
}

export function PuzzleGameScreen({
  game,
  onBack,
  onHome,
}: {
  game: PuzzleGame
  onBack: () => void
  onHome: () => void
}) {
  const { spendCoins, toast, lang } = useLuckyPi()
  const chargedForRef = useRef<string | null>(null)
  const text = puzzleGameText(lang, game.id)
  const common = puzzleCommonText(lang)
  const name = text?.name ?? game.name
  const subtitle = text?.subtitle ?? game.subtitle
  const rules = text?.rules ?? game.rules

  useEffect(() => {
    // 牌桌類遊戲每一局自己調整押注、贏了才拿彩金，不在進場時預扣固定費用。
    if (game.wagered) return
    if (chargedForRef.current === game.id) return
    chargedForRef.current = game.id
    const ok = spendCoins(game.cost)
    if (ok) {
      toast(common.costToastTemplate.replace("{cost}", String(game.cost)))
    }
    // Only charge once per time this screen is opened for this game.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game.id])

  if (game.wagered) {
    // 牌桌類遊戲有自己專屬的頂部功能列與押注列（CasinoTableShell），不套用益智小遊戲共用的外層標題列。
    return <GameBody game={game} name={name} subtitle={subtitle} onBack={onBack} onHome={onHome} />
  }

  return (
    <div className="flex min-h-dvh flex-col bg-background">
      <PuzzleHeader title={name} rules={rules} onHome={onHome} onLobby={onBack} />
      <GameBody game={game} name={name} subtitle={subtitle} onBack={onBack} onHome={onHome} />
    </div>
  )
}
