"use client"

import { useEffect } from "react"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { dictFor } from "@/lib/luckypi/i18n"

// 傳統水果盤「3BAR堆疊」圖騰：三條黑底白字BAR由上到下堆疊，取代🆎表情符號。
export function BarStackGlyph({ size = "lg" }: { size?: "lg" | "sm" }) {
  const barClass =
    size === "lg"
      ? "px-2 py-[2px] text-[0.62em] tracking-wider"
      : "px-1 py-px text-[0.6em] tracking-wide"
  return (
    <div className="flex flex-col items-center gap-[2px]" aria-label="BAR BAR BAR">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className={`rounded-[2px] bg-neutral-950 font-black leading-none text-white ${barClass}`}
          style={{ boxShadow: "inset 0 1px 0 oklch(1 0 0 / 0.2), 0 1px 1px oklch(0 0 0 / 0.5)" }}
        >
          BAR
        </span>
      ))}
    </div>
  )
}

// 傳統水果盤頭獎「7」：粗壯圓肥造型取代純文字數字，營造立體泡泡感。
export function SevenGlyph({ fontSize }: { fontSize: string }) {
  return (
    <span
      className="inline-block font-black"
      style={{
        fontSize,
        lineHeight: 1,
        color: "oklch(0.58 0.22 25)",
        transform: "scaleX(1.24) scaleY(1.16)",
        WebkitTextStroke: "3px oklch(0.32 0.2 22)",
        textShadow: "0 3px 0 oklch(0.4 0.2 22), 0 5px 8px oklch(0.15 0.08 20 / 0.6)",
      }}
    >
      7
    </span>
  )
}

export function WelcomeBanner({ text }: { text: string }) {
  return (
    <div className="overflow-hidden rounded-full border border-border bg-card/70 py-1.5">
      <div className="lp-marquee-track flex w-max items-center gap-16 whitespace-nowrap">
        <span className="text-xs font-medium text-primary">{text}</span>
        <span className="text-xs font-medium text-primary">{text}</span>
      </div>
    </div>
  )
}

export function LoadingScreen() {
  const { lang } = useLuckyPi()
  const t = dictFor(lang)
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-3 bg-background text-foreground">
      <div className="h-10 w-10 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      <p className="text-sm text-muted-foreground">{t.loadingLobbyLabel}</p>
    </div>
  )
}

export function StorageNotice() {
  const { storageTrouble, storageNoticeHosted, lang } = useLuckyPi()
  const t = dictFor(lang)
  // 若目前畫面已自行在特定位置顯示這個提示（見 InlineStorageNotice），
  // 這裡的全畫面置頂版本就先讓出，避免同一則訊息重複出現在兩個地方。
  if (!storageTrouble || storageNoticeHosted) return null
  return (
    <div className="fixed inset-x-0 top-2 z-40 flex justify-center px-4">
      <div className="rounded-full border border-border bg-card px-4 py-1.5 text-[11px] text-muted-foreground shadow-lg">
        {t.syncingAccountLabel}
      </div>
    </div>
  )
}

/**
 * 可以嵌在畫面任意位置顯示的同步提示版本（非浮動置頂）。
 * 掛載期間會通知全畫面版本讓出，避免重複顯示；卸載時自動還原。
 */
export function InlineStorageNotice({ className = "" }: { className?: string }) {
  const { storageTrouble, setStorageNoticeHosted, lang } = useLuckyPi()
  const t = dictFor(lang)

  useEffect(() => {
    setStorageNoticeHosted(true)
    return () => setStorageNoticeHosted(false)
  }, [setStorageNoticeHosted])

  if (!storageTrouble) return null
  return (
    <div className={`flex justify-center px-2 ${className}`}>
      <div className="rounded-full border border-border bg-card px-3 py-1 text-[10px] text-muted-foreground shadow-lg">
        {t.syncingAccountLabel}
      </div>
    </div>
  )
}

export function ToastHost() {
  const { toasts } = useLuckyPi()
  if (toasts.length === 0) return null
  return (
    <div className="pointer-events-none fixed inset-x-0 top-4 z-50 flex flex-col items-center gap-2 px-4">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="animate-in fade-in rounded-full border border-border bg-card px-4 py-2 text-sm text-foreground shadow-lg"
        >
          {t.message}
        </div>
      ))}
    </div>
  )
}
