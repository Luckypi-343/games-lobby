"use client"

import { useEffect, useRef, useState } from "react"
import { PuzzleShell } from "./puzzle-shell"
import {
  siNew,
  siMove,
  siShoot,
  siTick,
  SI_COLS,
  SI_ALIEN_ROWS,
  SI_GRID_ROWS,
  type SiState,
} from "@/lib/games/space-invaders"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playMoveSound, playCaptureSound, playWinSound, playLossSound } from "@/lib/games/game-audio"

export function SpaceInvadersView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<SiState>(() => siNew())
  const overRef = useRef(false)

  const restart = () => {
    setState(siNew())
    overRef.current = false
  }

  useEffect(() => {
    if (state.over && !overRef.current) {
      overRef.current = true
      if (soundOn) {
        if (state.won) playWinSound()
        else playLossSound()
      }
    }
  }, [state.over, state.won, soundOn])

  useEffect(() => {
    const id = setInterval(() => {
      setState((s) => siTick(s))
    }, 280)
    return () => clearInterval(id)
  }, [])

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") setState((s) => siMove(s, -1))
      else if (e.key === "ArrowRight") setState((s) => siMove(s, 1))
      else if (e.key === " ") shoot()
    }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const shoot = () => {
    setState((s) => {
      const next = siShoot(s)
      if (next.playerBullet && !s.playerBullet && soundOn) playCaptureSound()
      return next
    })
  }

  const cellSize = 26
  const gap = 3

  return (
    <PuzzleShell
      gameId="space-invaders"
      title="太空侵略者"
      subtitle="清光整編隊即獲勝"
      status={`分數：${state.score}　生命：${"❤".repeat(Math.max(0, state.lives))}`}
      rulesBrief="左右移動戰機閃避敵彈，發射砲彈擊落整編隊的外星戰艦，若編隊逼近或生命耗盡則挑戰失敗。"
      solved={state.over && state.won}
      cost={12}
      onBack={onBack}
      onRestart={restart}
    >
      <div
        className="relative touch-none rounded-2xl border border-border bg-card shadow-lg"
        style={{ width: SI_COLS * (cellSize + gap) - gap + 16, height: SI_GRID_ROWS * (cellSize + gap) - gap + 16, padding: 8 }}
      >
        {state.alive.map((row, r) =>
          row.map((isAlive, c) => {
            if (!isAlive) return null
            const top = (r + state.offsetRow) * (cellSize + gap) + state.colOffset * 4
            const left = c * (cellSize + gap) + state.colOffset * 4
            return (
              <div
                key={`${r}-${c}`}
                className="absolute rounded-md bg-[oklch(0.62_0.19_150)] shadow-[0_0_6px_oklch(0.62_0.19_150_/_0.6)]"
                style={{ width: cellSize, height: cellSize, top, left }}
              />
            )
          }),
        )}
        {state.playerBullet && (
          <div
            className="absolute rounded-full bg-[oklch(0.85_0.18_90)]"
            style={{
              width: 6,
              height: 14,
              left: state.playerBullet.col * (cellSize + gap) + cellSize / 2 - 3,
              top: state.playerBullet.row * (cellSize + gap),
            }}
          />
        )}
        {state.enemyBullets.map((b, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-destructive"
            style={{
              width: 6,
              height: 14,
              left: b.col * (cellSize + gap) + cellSize / 2 - 3,
              top: b.row * (cellSize + gap),
            }}
          />
        ))}
        <div
          className="absolute rounded-md bg-primary shadow-[0_0_8px_oklch(0.55_0.2_260_/_0.6)]"
          style={{
            width: cellSize,
            height: cellSize,
            left: state.playerCol * (cellSize + gap),
            top: (SI_GRID_ROWS - 1) * (cellSize + gap),
          }}
        />
      </div>
      {state.over && !state.won && (
        <p className="text-center text-xs font-semibold text-destructive">挑戰失敗，點「重新開始」再來一次！</p>
      )}
      <div className="grid grid-cols-3 gap-1.5">
        <button
          onClick={() => setState((s) => siMove(s, -1))}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-bold text-muted-foreground active:scale-90"
        >
          ←
        </button>
        <button
          onClick={shoot}
          className="flex h-10 w-14 items-center justify-center rounded-full bg-accent text-xs font-bold text-accent-foreground active:scale-90"
        >
          {soundOn ? "開火" : "開火"}
        </button>
        <button
          onClick={() => setState((s) => siMove(s, 1))}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-bold text-muted-foreground active:scale-90"
        >
          →
        </button>
      </div>
    </PuzzleShell>
  )
}
