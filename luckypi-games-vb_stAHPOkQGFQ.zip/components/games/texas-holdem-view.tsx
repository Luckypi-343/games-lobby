"use client"

import { useState } from "react"
import { BoardShell } from "./board-shell"
import { CardRow } from "./playing-card"
import { thInitial, thNewHand, thFold, thCall, type THState } from "@/lib/games/texas-holdem"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playMoveSound, playWinSound, playLossSound } from "@/lib/games/game-audio"

export function TexasHoldemView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<THState>(() => thInitial())

  const restart = () => setState(thInitial())

  function nextHand() {
    setState((s) => thNewHand(s))
  }

  function fold() {
    if (soundOn) playMoveSound()
    const next = thFold(state)
    setState(next)
    if (soundOn) playLossSound()
  }

  function call() {
    if (soundOn) playMoveSound()
    const next = thCall(state)
    setState(next)
    if (soundOn) {
      if (next.winner === 1) playWinSound()
      else if (next.winner === 2) playLossSound()
    }
  }

  const done = state.status === "showdown"
  const result = done ? (state.winner === 1 ? "win" : state.winner === 2 ? "loss" : "draw") : null

  const statusText = done
    ? state.winner === 1
      ? `您獲勝！${state.playerHandName ?? ""} 贏得底池 ${state.pot} 籌碼`
      : state.winner === 2
        ? `AI 獲勝${state.aiHandName ? `（${state.aiHandName}）` : ""}`
        : "平手，底池均分"
    : `第 ${state.hands} 手 · 底池 ${state.pot} 籌碼 · 請選擇跟注或棄牌`

  return (
    <BoardShell
      gameId="texas-holdem"
      title="德州撲克"
      subtitle="單挑 AI 簡化版"
      status={statusText}
      result={result}
      rulesBrief="您與 AI 各持 2 張手牌，加上桌面 5 張公共牌，選擇「跟注」開牌比大小（同花順＞四條＞葫蘆＞同花＞順子＞三條＞兩對＞一對＞高牌），或「棄牌」放棄本手。"
      onBack={onBack}
      onRestart={restart}
      mode="single"
    >
      <div className="flex w-[min(94vw,420px)] flex-col items-center gap-4">
        <div className="flex flex-col items-center gap-1.5">
          <p className="text-[10px] font-semibold text-muted-foreground">AI 手牌{state.aiHoleRevealed ? "" : "（隱藏）"}</p>
          <CardRow cards={state.aiHole} faceDown={!state.aiHoleRevealed} small />
        </div>

        <div className="flex flex-col items-center gap-1.5 rounded-xl border border-border bg-muted/30 p-3">
          <p className="text-[10px] font-semibold text-muted-foreground">公共牌</p>
          <CardRow cards={state.community} />
        </div>

        <div className="flex flex-col items-center gap-1.5">
          <p className="text-[10px] font-semibold text-muted-foreground">您的手牌</p>
          <CardRow cards={state.playerHole} />
        </div>

        <div className="flex w-full items-center justify-between text-[11px] text-muted-foreground">
          <span>您的籌碼：{state.playerChips}</span>
          <span>AI 籌碼：{state.aiChips}</span>
        </div>

        {!done ? (
          <div className="flex w-full gap-2">
            <button
              onClick={fold}
              className="flex-1 rounded-lg bg-muted py-2.5 text-sm font-bold text-foreground transition active:scale-95"
            >
              棄牌
            </button>
            <button
              onClick={call}
              className="flex-1 rounded-lg bg-primary py-2.5 text-sm font-bold text-primary-foreground transition active:scale-95"
            >
              跟注（{state.ante}）開牌
            </button>
          </div>
        ) : (
          <button
            onClick={nextHand}
            className="w-full rounded-lg bg-accent py-2.5 text-sm font-bold text-accent-foreground transition active:scale-95"
          >
            下一手
          </button>
        )}
      </div>
    </BoardShell>
  )
}
