"use client"

import { useMemo, useState } from "react"
import { BoardShell, type PuzzleOutcome } from "./board-shell"
import {
  dealDouDizhu,
  playCombo,
  passTurn,
  classifyCombo,
  comboBeats,
  ddzCardLabel,
  COMBO_TYPE_LABEL,
  DDZ_SEAT_LABEL,
  type DdzState,
  type DdzCard,
} from "@/lib/games/dou-dizhu"
import { playMoveSound, playCaptureSound } from "@/lib/games/game-audio"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { isRedSuit } from "@/lib/games/cards"

const GAME_ID = "dou-dizhu"

function DdzChip({ card, selected }: { card: DdzCard; selected: boolean }) {
  const isJoker = card.rank >= 16
  const red = !isJoker && isRedSuit(card.suit as 0 | 1 | 2 | 3)
  const color = isJoker ? "text-accent" : red ? "text-red-600" : "text-neutral-900"
  return (
    <div
      className={`flex h-14 w-9 shrink-0 items-center justify-center rounded-md border-2 bg-card text-[11px] font-bold shadow transition ${
        selected ? "-translate-y-2 border-primary" : "border-neutral-300"
      } ${color}`}
    >
      {ddzCardLabel(card)}
    </div>
  )
}

export function DouDizhuView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<DdzState>(() => dealDouDizhu())
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [message, setMessage] = useState<string | null>(null)

  const result: PuzzleOutcome = state.outcome === "win" ? "win" : state.outcome === "lose" ? "loss" : null
  const youAreLandlord = state.landlord === "you"

  const selectedCards = useMemo(
    () => state.hands.you.filter((c) => selected.has(c.id)),
    [state.hands.you, selected],
  )
  const previewCombo = useMemo(() => classifyCombo(selectedCards), [selectedCards])

  function toggle(cardId: string) {
    if (state.finished || state.turn !== "you") return
    setMessage(null)
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(cardId)) next.delete(cardId)
      else next.add(cardId)
      return next
    })
  }

  function handlePlay() {
    if (state.turn !== "you" || selectedCards.length === 0) return
    if (!previewCombo) {
      setMessage("這不是合法的牌組")
      return
    }
    const mustLead = !state.lastCombo || state.lastSeat === "you"
    if (!mustLead && !comboBeats(previewCombo, state.lastCombo)) {
      setMessage("牌組壓不過上家，換一組或按過牌")
      return
    }
    const next = playCombo(state, "you", selectedCards)
    setState(next)
    setSelected(new Set())
    setMessage(null)
    if (soundOn) (next.finished ? playCaptureSound : playMoveSound)()
  }

  function handlePass() {
    if (state.turn !== "you" || !state.lastCombo || state.lastSeat === "you") return
    setState(passTurn(state, "you"))
    setSelected(new Set())
    setMessage(null)
  }

  const status = state.finished
    ? state.outcome === "win"
      ? youAreLandlord
        ? "地主先出完，您獲勝！"
        : "農民先出完，您獲勝！"
      : youAreLandlord
        ? "農民先出完，地主落敗"
        : "地主先出完，農民落敗"
    : `地主：${DDZ_SEAT_LABEL[state.landlord]}${youAreLandlord ? "（您）" : ""} ・ 現在輪到：${DDZ_SEAT_LABEL[state.turn]}`

  return (
    <BoardShell
      gameId={GAME_ID}
      title="鬥地主"
      subtitle="地主對抗兩位農民"
      status={status}
      rulesBrief="發牌後系統依牌力自動指定一位地主（可能是您也可能是電腦），地主多拿3張底牌，其餘兩家結為農民聯手對抗地主。輪流出牌，須出比上家更大的同類型牌組（單張／對子／三張／三帶一或二／順子／連對／四帶二／炸彈／火箭），出不了就按過牌。地主先出完牌即地主獲勝，任一農民先出完牌則農民方獲勝。"
      result={result}
      onBack={onBack}
      onRestart={() => {
        setState(dealDouDizhu())
        setSelected(new Set())
        setMessage(null)
      }}
      mode="single"
    >
      <div className="flex w-full max-w-sm flex-col items-center gap-3">
        <div className="flex w-full items-center justify-around text-[11px] text-muted-foreground">
          {(["ai1", "ai2"] as const).map((seat) => (
            <div key={seat} className="flex flex-col items-center gap-1">
              <span className={state.landlord === seat ? "font-semibold text-accent" : ""}>
                {DDZ_SEAT_LABEL[seat]}
                {state.landlord === seat ? "（地主）" : ""}
              </span>
              <span className="lp-nums">手牌 {state.hands[seat].length}</span>
            </div>
          ))}
        </div>

        <div className="flex min-h-12 w-full flex-col items-center gap-1 rounded-xl border border-border bg-card/60 p-2">
          {state.lastCombo ? (
            <>
              <span className="text-[10px] text-muted-foreground">
                {state.lastSeat ? DDZ_SEAT_LABEL[state.lastSeat] : ""} 出了 {COMBO_TYPE_LABEL[state.lastCombo.type]}
              </span>
              <div className="flex gap-1">
                {state.lastCombo.cards.map((c) => (
                  <DdzChip key={c.id} card={c} selected={false} />
                ))}
              </div>
            </>
          ) : (
            <p className="text-[11px] text-muted-foreground">請自由出牌開局</p>
          )}
        </div>

        {message && <p className="text-[11px] font-semibold text-destructive">{message}</p>}

        <div className="flex flex-col items-center gap-2">
          <span className="text-[11px] font-semibold text-primary">
            您{youAreLandlord ? "（地主）" : "（農民）"} ・ 手牌 {state.hands.you.length}
          </span>
          <div className="flex max-w-[22rem] flex-wrap justify-center gap-1">
            {state.hands.you.map((card) => (
              <button key={card.id} onClick={() => toggle(card.id)} className="active:scale-95">
                <DdzChip card={card} selected={selected.has(card.id)} />
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <button
              onClick={handlePass}
              disabled={state.turn !== "you" || !state.lastCombo || state.lastSeat === "you" || state.finished}
              className="rounded-full bg-muted px-4 py-1.5 text-xs font-semibold text-foreground transition active:scale-95 disabled:opacity-40"
            >
              過牌
            </button>
            <button
              onClick={handlePlay}
              disabled={state.turn !== "you" || selectedCards.length === 0 || state.finished}
              className="rounded-full bg-primary px-5 py-1.5 text-xs font-semibold text-primary-foreground transition active:scale-95 disabled:opacity-40"
            >
              出牌
            </button>
          </div>
        </div>
      </div>
    </BoardShell>
  )
}
