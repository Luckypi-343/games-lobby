"use client"

import { useEffect, useRef, useState } from "react"
import { PuzzleShell } from "./puzzle-shell"
import { mxNew, mxJump, mxTick, MX_GOAL_DISTANCE, type MxState } from "@/lib/games/motocross"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playWinSound, playLossSound } from "@/lib/games/game-audio"

export function MotocrossView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<MxState>(() => mxNew())
  const overRef = useRef(false)

  const restart = () => {
    setState(mxNew())
    overRef.current = false
  }

  useEffect(() => {
    if (state.over && !overRef.current) {
      overRef.current = true
      if (soundOn) {
        if (state.won) playWinSound()
        else playLossSound()
      }
    }
  }, [state.over, state.won, soundOn])

  useEffect(() => {
    const id = setInterval(() => setState((s) => mxTick(s)), 90)
    return () => clearInterval(id)
  }, [])

  const jump = () => setState((s) => mxJump(s))

  return (
    <PuzzleShell
      gameId="motocross"
      title="越野摩托車"
      subtitle="抓準時機跳躍越過坑洞"
      status={`進度：${Math.round((state.distance / MX_GOAL_DISTANCE) * 100)}%　生命：${"❤".repeat(Math.max(0, state.lives))}`}
      rulesBrief="點擊「跳躍」讓摩托車起跳，抓準時機越過前方的坑洞障礙，抵達終點前生命耗盡則挑戰失敗。"
      solved={state.over && state.won}
      cost={12}
      onBack={onBack}
      onRestart={restart}
    >
      <div
        className="relative touch-none select-none overflow-hidden rounded-2xl border border-border bg-[oklch(0.75_0.08_60)] shadow-lg"
        style={{ width: 280, height: 140 }}
        onPointerDown={jump}
      >
        <div className="absolute inset-x-0 bottom-6 h-1 bg-[oklch(0.4_0.05_60)]" />
        {state.obstacles.map((o) => {
          const left = ((o.distance - state.distance) / 100) * 280 + 40
          if (left < -20 || left > 300) return null
          return (
            <div
              key={o.id}
              className="absolute bottom-6 rounded-t-sm bg-[oklch(0.45_0.03_60)]"
              style={{ left, width: 14, height: 20 }}
            />
          )
        })}
        <div
          className="absolute h-6 w-9 rounded-md bg-primary shadow-md transition-transform"
          style={{ left: 30, bottom: state.airborne ? 44 : 6 }}
        />
      </div>
      <button
        onClick={jump}
        disabled={state.over}
        className="rounded-full bg-primary px-8 py-2 text-xs font-bold text-primary-foreground transition disabled:opacity-40 active:scale-95"
      >
        跳躍
      </button>
    </PuzzleShell>
  )
}
