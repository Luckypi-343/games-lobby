"use client"

import { useState } from "react"
import { BoardShell } from "./board-shell"
import { CardRow } from "./playing-card"
import { tcpInitial, tcpNewHand, tcpFold, tcpCall, type TCPState } from "@/lib/games/three-card-poker"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playMoveSound, playWinSound, playLossSound, playDrawSound } from "@/lib/games/game-audio"

const RESULT_LABEL: Record<string, string> = { win: "您獲勝！", loss: "莊家獲勝", tie: "平手", fold: "已棄牌" }

export function ThreeCardPokerView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<TCPState>(() => tcpInitial())

  const restart = () => setState(tcpInitial())

  function fold() {
    if (soundOn) playMoveSound()
    const next = tcpFold(state)
    setState(next)
    if (soundOn) playLossSound()
  }

  function call() {
    if (soundOn) playMoveSound()
    const next = tcpCall(state)
    setState(next)
    if (soundOn) {
      if (next.result === "win") playWinSound()
      else if (next.result === "loss") playLossSound()
      else playDrawSound()
    }
  }

  function nextHand() {
    setState((s) => tcpNewHand(s))
  }

  const done = state.status === "over"
  const result = done ? (state.result === "win" ? "win" : state.result === "tie" ? "draw" : "loss") : null

  const statusText = done
    ? `${RESULT_LABEL[state.result ?? "loss"]}${
        state.playerHandName ? `（您：${state.playerHandName} vs 莊家：${state.dealerHandName}）` : ""
      }`
    : `第 ${state.hands} 局 · 請選擇跟注比大小或棄牌`

  return (
    <BoardShell
      gameId="three-card-poker"
      title="三張牌撲克"
      subtitle="對戰莊家"
      status={statusText}
      result={result}
      rulesBrief="您與莊家各拿 3 張牌，看牌後選擇「跟注」開牌比大小（同花順＞三條＞順子＞同花＞對子＞高牌），或「棄牌」放棄本局。"
      onBack={onBack}
      onRestart={restart}
      mode="single"
    >
      <div className="flex w-[min(94vw,420px)] flex-col items-center gap-4">
        <div className="flex flex-col items-center gap-1.5">
          <p className="text-[10px] font-semibold text-muted-foreground">莊家{done ? `（${state.dealerHandName}）` : ""}</p>
          <CardRow cards={state.dealer} faceDown={!done} />
        </div>

        <div className="flex flex-col items-center gap-1.5">
          <p className="text-[10px] font-semibold text-muted-foreground">您{done ? `（${state.playerHandName}）` : ""}</p>
          <CardRow cards={state.player} />
        </div>

        <div className="flex w-full items-center justify-between text-[11px] text-muted-foreground">
          <span>勝：{state.wins}</span>
          <span>第 {state.hands} 局</span>
          <span>負：{state.losses}</span>
        </div>

        {!done ? (
          <div className="flex w-full gap-2">
            <button
              onClick={fold}
              className="flex-1 rounded-lg bg-muted py-2.5 text-sm font-bold text-foreground transition active:scale-95"
            >
              棄牌
            </button>
            <button
              onClick={call}
              className="flex-1 rounded-lg bg-primary py-2.5 text-sm font-bold text-primary-foreground transition active:scale-95"
            >
              跟注開牌
            </button>
          </div>
        ) : (
          <button
            onClick={nextHand}
            className="w-full rounded-lg bg-accent py-2.5 text-sm font-bold text-accent-foreground transition active:scale-95"
          >
            下一局
          </button>
        )}
      </div>
    </BoardShell>
  )
}
