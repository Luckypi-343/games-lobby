"use client"

import { useState } from "react"
import { PuzzleShell } from "./puzzle-shell"
import { hnNew, hnMove, hnCanMove, hnMinMoves, HN_DISKS, type HnState } from "@/lib/games/hanoi"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playMoveSound, playLossSound } from "@/lib/games/game-audio"

const DISK_COLOR = ["bg-rose-500", "bg-orange-500", "bg-amber-500", "bg-emerald-500", "bg-sky-500", "bg-indigo-500"]

export function HanoiView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<HnState>(() => hnNew())
  const [selected, setSelected] = useState<number | null>(null)

  const restart = () => {
    setState(hnNew())
    setSelected(null)
  }

  const tapPeg = (idx: number) => {
    if (state.won) return
    if (selected === null) {
      if (state.pegs[idx].length > 0) setSelected(idx)
      return
    }
    if (selected === idx) {
      setSelected(null)
      return
    }
    if (hnCanMove(state, selected, idx)) {
      if (soundOn) playMoveSound()
      setState((s) => hnMove(s, selected, idx))
    } else if (soundOn) {
      playLossSound()
    }
    setSelected(null)
  }

  const minMoves = hnMinMoves(HN_DISKS)

  return (
    <PuzzleShell
      gameId="hanoi"
      title="河內塔"
      subtitle="把整疊圓盤移到最右邊"
      status={`步數：${state.moves}　最少步數：${minMoves}`}
      rulesBrief="點選一根柱子選取最上方的圓盤，再點選目標柱子即可移動。大圓盤不能疊在小圓盤上面，把所有圓盤移到最右邊柱子就過關。"
      solved={state.won}
      cost={12}
      onBack={onBack}
      onRestart={restart}
    >
      <div className="flex items-end justify-center gap-4 rounded-2xl border border-border bg-card p-4 shadow-lg" style={{ height: 180, width: 260 }}>
        {state.pegs.map((peg, idx) => (
          <button
            key={idx}
            onClick={() => tapPeg(idx)}
            className="relative flex h-full flex-1 flex-col items-center justify-end"
          >
            <div
              className={`absolute bottom-0 w-1.5 rounded-t-sm ${selected === idx ? "bg-primary" : "bg-border"}`}
              style={{ height: "90%" }}
            />
            <div className="relative z-10 flex flex-col-reverse items-center gap-0.5 pb-1">
              {peg.map((disk, i) => (
                <div
                  key={i}
                  className={`h-4 rounded-full ${DISK_COLOR[disk - 1] ?? "bg-muted"} ${
                    selected === idx && i === peg.length - 1 ? "ring-2 ring-foreground" : ""
                  }`}
                  style={{ width: `${20 + disk * 12}px` }}
                />
              ))}
            </div>
            <div className="absolute -bottom-4 h-1.5 w-full rounded-full bg-muted" />
          </button>
        ))}
      </div>
    </PuzzleShell>
  )
}
