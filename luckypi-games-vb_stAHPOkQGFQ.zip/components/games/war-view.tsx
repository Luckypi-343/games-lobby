"use client"

import { useState } from "react"
import { BoardShell } from "./board-shell"
import { CardRow } from "./playing-card"
import { warInitial, warFlip, type WarState } from "@/lib/games/war"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playMoveSound, playWinSound, playLossSound, playDrawSound } from "@/lib/games/game-audio"

export function WarView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<WarState>(() => warInitial())

  const restart = () => setState(warInitial())

  function flip() {
    if (state.status !== "playing") return
    if (soundOn) playMoveSound()
    const next = warFlip(state)
    setState(next)
    if (soundOn) {
      if (next.lastResult === "win") playWinSound()
      else if (next.lastResult === "loss") playLossSound()
      else if (next.lastResult === "tie") playDrawSound()
    }
  }

  const done = state.status === "over"
  const result = done ? (state.overallWinner === "player" ? "win" : state.overallWinner === "ai" ? "loss" : "draw") : null

  const statusText = done
    ? `牌局結束！您 ${state.playerDeck.length} 張 · AI ${state.aiDeck.length} 張 · ${
        state.overallWinner === "player" ? "您獲勝！" : state.overallWinner === "ai" ? "AI 獲勝" : "平手"
      }`
    : `第 ${state.round} 輪 · 您 ${state.playerDeck.length} 張 · AI ${state.aiDeck.length} 張`

  return (
    <BoardShell
      gameId="war"
      title="戰爭牌"
      subtitle="比大小對戰 AI"
      status={statusText}
      result={result}
      rulesBrief="牌堆平分兩半，每輪雙方各翻一張牌，數字較大者贏得整輪的牌；若平手則雙方燒一張牌後再翻牌比大小。手中牌全部用完的一方即告落敗，最終持牌較多者獲勝。"
      onBack={onBack}
      onRestart={restart}
      mode="single"
    >
      <div className="flex w-[min(94vw,420px)] flex-col items-center gap-4">
        <div className="flex flex-col items-center gap-1.5">
          <p className="text-[10px] font-semibold text-muted-foreground">AI 翻牌</p>
          <CardRow cards={state.aiFlip.length ? state.aiFlip : []} />
          {state.aiFlip.length === 0 && <div className="h-20 w-14 rounded-md border-2 border-dashed border-border" />}
        </div>

        <div className="flex flex-col items-center gap-1.5">
          <p className="text-[10px] font-semibold text-muted-foreground">您的翻牌</p>
          <CardRow cards={state.playerFlip.length ? state.playerFlip : []} />
          {state.playerFlip.length === 0 && <div className="h-20 w-14 rounded-md border-2 border-dashed border-border" />}
        </div>

        <div className="flex w-full items-center justify-between text-[11px] text-muted-foreground">
          <span>贏：{state.playerWins}</span>
          <span>平：{state.ties}</span>
          <span>輸：{state.aiWins}</span>
        </div>

        {!done ? (
          <button
            onClick={flip}
            className="w-full rounded-lg bg-primary py-2.5 text-sm font-bold text-primary-foreground transition active:scale-95"
          >
            翻牌
          </button>
        ) : (
          <button
            onClick={restart}
            className="w-full rounded-lg bg-accent py-2.5 text-sm font-bold text-accent-foreground transition active:scale-95"
          >
            再來一局
          </button>
        )}
      </div>
    </BoardShell>
  )
}
