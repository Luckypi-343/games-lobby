"use client"

import { useState } from "react"
import { CasinoTableShell } from "@/components/luckypi/casino-table-shell"
import { CardRow } from "./playing-card"
import {
  thirteenInitial,
  thirteenNewHand,
  thirteenPayoutMultiplier,
  SECTION_LABEL,
  type ThirteenState,
  type SectionResult,
} from "@/lib/games/thirteen-water"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playWinSound, playLossSound, playDrawSound } from "@/lib/games/game-audio"

const BET_MIN = 50
const BET_MAX = 2000
const BET_STEP = 50
const HUE = 265

const SECTION_LABEL_COLOR: Record<SectionResult, string> = {
  win: "text-emerald-300",
  loss: "text-rose-300",
  tie: "text-amber-200",
}
const SECTION_TEXT: Record<SectionResult, string> = { win: "贏", loss: "輸", tie: "平" }

export function ThirteenWaterView({ onHome, onLobby }: { onHome: () => void; onLobby: () => void }) {
  const { soundOn, spendCoins, creditWin } = useLuckyPi()
  const [state, setState] = useState<ThirteenState>(() => thirteenInitial())
  const [bet, setBet] = useState(100)
  const [phase, setPhase] = useState<"idle" | "over">("idle")

  function deal() {
    if (!spendCoins(bet)) return
    const next = thirteenNewHand(state)
    setState(next)
    setPhase("over")
    const multiplier = thirteenPayoutMultiplier(next)
    if (soundOn) {
      if (multiplier > 1) playWinSound()
      else if (multiplier === 1) playDrawSound()
      else playLossSound()
    }
    if (multiplier > 0) creditWin(Math.round(bet * multiplier))
  }

  const resultText =
    phase === "over" && state.sweep === "player"
      ? "三墩全垂！大獲全勝"
      : phase === "over" && state.sweep === "dealer"
        ? "莊家三墩全垂，本局落敗"
        : phase === "over" && state.sectionResults
          ? (() => {
              const wins = state.sectionResults.filter((r) => r === "win").length
              const losses = state.sectionResults.filter((r) => r === "loss").length
              if (wins > losses) return `贏 ${wins} 墩，獲勝！`
              if (wins < losses) return `輸 ${losses} 墩，落敗`
              return "三墩平分，退回押注"
            })()
          : null

  return (
    <CasinoTableShell
      title="十三水"
      rules="系統會自動幫玩家與莊家把各自的13張牌，排成頭道(3張)、中道(5張)、尾道(5張)三墩最強且不犯規的組合，三墩分別比大小。三墩全贏（全垂）得5倍彩金；淨勝2墩得2倍；淨勝1墩得1.5倍；平分退回押注；淨輸則不退。"
      hue={HUE}
      bet={bet}
      betMin={BET_MIN}
      betMax={BET_MAX}
      betStep={BET_STEP}
      betLocked={false}
      onBetChange={setBet}
      onHome={onHome}
      onLobby={onLobby}
    >
      <div className="flex h-full flex-col justify-between gap-2 overflow-y-auto px-3 py-3">
        <div className="flex flex-col gap-1.5">
          <p className="text-xs font-semibold text-violet-200/70">莊家</p>
          {state.dealer ? (
            <div className="flex flex-col gap-1">
              {(["front", "middle", "back"] as const).map((key, i) => (
                <div key={key} className="flex items-center gap-2">
                  <span className="w-8 shrink-0 text-[10px] text-violet-200/60">{SECTION_LABEL[i]}</span>
                  <CardRow cards={state.dealer![key]} faceDown={phase !== "over"} small />
                  {phase === "over" && state.sectionResults && (
                    <span className={`text-xs font-bold ${SECTION_LABEL_COLOR[state.sectionResults[i]]}`}>
                      {SECTION_TEXT[state.sectionResults[i]]}
                    </span>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-violet-100/40">尚未發牌</p>
          )}
        </div>

        <div className="flex items-center justify-center py-1">
          {resultText ? (
            <p
              className="rounded-full border px-5 py-2 text-center font-serif text-sm font-bold shadow-lg"
              style={{
                borderColor: "oklch(0.7 0.15 80 / 0.5)",
                background: "oklch(0.2 0.05 265 / 0.85)",
                color: "oklch(0.88 0.14 80)",
              }}
            >
              {resultText}
            </p>
          ) : (
            <p className="text-sm text-violet-100/60">調整押注金額，按「發牌」開始這一局</p>
          )}
        </div>

        <div className="flex flex-col gap-1.5">
          {state.player ? (
            <div className="flex flex-col gap-1">
              {(["front", "middle", "back"] as const).map((key, i) => (
                <div key={key} className="flex items-center gap-2">
                  <span className="w-8 shrink-0 text-[10px] text-violet-200/60">{SECTION_LABEL[i]}</span>
                  <CardRow cards={state.player![key]} small />
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-violet-100/40">尚未發牌</p>
          )}
          <p className="text-xs font-semibold text-violet-200/70">玩家</p>
        </div>

        <div className="mt-1 flex justify-center gap-3">
          <button
            onClick={deal}
            className="rounded-full bg-violet-500 px-10 py-3 text-sm font-bold text-neutral-900 shadow-lg transition active:scale-95"
          >
            {phase === "over" ? "再玩一局" : "發牌"}
          </button>
        </div>
      </div>
    </CasinoTableShell>
  )
}
