"use client"

import { useMemo, useState } from "react"
import { BoardShell, type PuzzleOutcome } from "./board-shell"
import { PlayingCard } from "./playing-card"
import {
  dealBridge,
  playCard,
  legalCards,
  suitSymbol,
  SEAT_LABEL,
  SEAT_ORDER,
  isYourTeam,
  type BridgeState,
  type Seat,
} from "@/lib/games/bridge"
import { playMoveSound, playCaptureSound } from "@/lib/games/game-audio"
import { useLuckyPi } from "@/contexts/luckypi-context"

const GAME_ID = "bridge"

export function BridgeView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<BridgeState>(() => dealBridge())

  const result: PuzzleOutcome = state.outcome === "win" ? "win" : state.outcome === "lose" ? "loss" : null

  const legal = useMemo(
    () => legalCards(state.hands.south, state.currentTrick.plays.length > 0 ? state.currentTrick.ledSuit : null),
    [state.hands.south, state.currentTrick],
  )

  function handlePlay(cardId: string) {
    if (state.finished || state.turn !== "south") return
    const card = state.hands.south.find((c) => c.id === cardId)
    if (!card) return
    if (!legal.some((c) => c.id === cardId)) return
    const wasTrickOver = state.currentTrick.plays.length === 3
    const next = playCard(state, "south", card)
    setState(next)
    if (soundOn) (wasTrickOver ? playCaptureSound : playMoveSound)()
  }

  const status = state.finished
    ? state.outcome === "win"
      ? "達成合約！您方獲勝"
      : "合約失敗，對方獲勝"
    : `王牌：${suitSymbol(state.trump)} ・ 現在輪到：${SEAT_LABEL[state.turn]}`

  return (
    <BoardShell
      gameId={GAME_ID}
      title="橋牌"
      subtitle="與夥伴組隊，對戰電腦兩家"
      status={status}
      rulesBrief="您與北家夥伴組隊，對戰西、東兩家電腦。每輪四人依序出牌，須跟牌（有同花色必須跟出），沒有時可打任意花色或王牌。同花色最大或王牌最大者贏得該輪，13輪出完後您方合計贏得7輪以上即獲勝。"
      result={result}
      onBack={onBack}
      onRestart={() => setState(dealBridge())}
      mode="single"
    >
      <div className="flex w-full max-w-sm flex-col items-center gap-3">
        <div className="flex w-full items-center justify-around text-[11px] text-muted-foreground">
          {SEAT_ORDER.filter((s) => s !== "south").map((seat) => (
            <div key={seat} className="flex flex-col items-center gap-1">
              <span className={isYourTeam(seat) ? "font-semibold text-primary" : ""}>{SEAT_LABEL[seat]}</span>
              <span className="lp-nums">手牌 {state.hands[seat].length}</span>
              <span className="lp-nums">贏 {state.tricksWon[seat]}</span>
            </div>
          ))}
        </div>

        <div className="flex min-h-20 w-full items-center justify-center gap-2 rounded-xl border border-border bg-card/60 p-2">
          {state.currentTrick.plays.length === 0 ? (
            <p className="text-[11px] text-muted-foreground">等待出牌…</p>
          ) : (
            state.currentTrick.plays.map(({ seat, card }) => (
              <div key={card.id} className="flex flex-col items-center gap-1">
                <span className="text-[9px] text-muted-foreground">{SEAT_LABEL[seat as Seat]}</span>
                <PlayingCard card={card} small />
              </div>
            ))
          )}
        </div>

        <div className="flex flex-col items-center gap-1">
          <span className="text-[11px] font-semibold text-primary">
            您 ・ 贏 {state.tricksWon.south} 輪
          </span>
          <div className="flex flex-wrap justify-center gap-1">
            {state.hands.south.map((card) => {
              const isLegal = legal.some((c) => c.id === card.id)
              return (
                <button
                  key={card.id}
                  onClick={() => handlePlay(card.id)}
                  disabled={!isLegal || state.turn !== "south" || state.finished}
                  className="transition active:scale-95 disabled:opacity-40"
                >
                  <PlayingCard card={card} small />
                </button>
              )
            })}
          </div>
        </div>
      </div>
    </BoardShell>
  )
}
