"use client"

import { useState } from "react"
import { CasinoTableShell } from "@/components/luckypi/casino-table-shell"
import { CardRow } from "./playing-card"
import { thInitial, thNewHand, thHit, thStand, thPoints, type TenHalfState } from "@/lib/games/ten-half"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playMoveSound, playWinSound, playLossSound, playDrawSound } from "@/lib/games/game-audio"

const BET_MIN = 50
const BET_MAX = 2000
const BET_STEP = 50
const HUE = 355

const RESULT_LABEL: Record<string, string> = {
  win: "獲勝！",
  loss: "莊家獲勝",
  push: "平手，已退回押注",
  bonus: "天生10點半！加倍獲勝",
}

export function TenHalfView({ onHome, onLobby }: { onHome: () => void; onLobby: () => void }) {
  const { soundOn, spendCoins, creditWin } = useLuckyPi()
  const [state, setState] = useState<TenHalfState>(() => thInitial())
  const [bet, setBet] = useState(100)
  const [phase, setPhase] = useState<"idle" | "playing" | "over">("idle")

  function settle(next: TenHalfState) {
    setState(next)
    if (next.status !== "over") {
      setPhase("playing")
      return
    }
    setPhase("over")
    if (soundOn) {
      if (next.result === "win" || next.result === "bonus") playWinSound()
      else if (next.result === "loss") playLossSound()
      else playDrawSound()
    }
    if (next.result === "win") creditWin(bet * 2)
    else if (next.result === "bonus") creditWin(bet * 3)
    else if (next.result === "push") creditWin(bet)
  }

  function startHand() {
    if (phase === "playing") return
    if (!spendCoins(bet)) return
    settle(thNewHand(state))
  }

  function hit() {
    if (phase !== "playing") return
    if (soundOn) playMoveSound()
    settle(thHit(state))
  }

  function stand() {
    if (phase !== "playing") return
    if (soundOn) playMoveSound()
    settle(thStand(state))
  }

  const dealerFaceDown = phase === "playing"

  return (
    <CasinoTableShell
      title="10點半"
      rules="開局各發2張牌，可選擇「補牌」或「停牌」，越接近10.5點越好，超過10.5點即爆牌。A算1點，J/Q/K各算0.5點，其餘照牌面點數計算。發牌就剛好10.5點稱為「天生半」，直接開牌且獲勝為3倍彩金；一般獲勝為2倍彩金，平手退回押注。"
      hue={HUE}
      bet={bet}
      betMin={BET_MIN}
      betMax={BET_MAX}
      betStep={BET_STEP}
      betLocked={phase === "playing"}
      onBetChange={setBet}
      onHome={onHome}
      onLobby={onLobby}
    >
      <div className="flex h-full flex-col justify-between px-4 py-3">
        <div className="flex min-h-[7.5rem] flex-col items-center gap-1.5">
          <p className="text-xs font-semibold text-amber-200/70">莊家</p>
          <CardRow cards={state.dealer} faceDown={dealerFaceDown && state.dealer.length > 0 ? false : false} />
          <p className="font-mono text-sm font-bold text-amber-100 tabular-nums">
            {phase === "idle" ? "—" : `${thPoints(state.dealer)} 點`}
          </p>
        </div>

        <div className="flex flex-1 items-center justify-center">
          {phase === "over" && state.result ? (
            <p
              className="rounded-full border px-5 py-2 text-center font-serif text-base font-bold shadow-lg"
              style={{
                borderColor: "oklch(0.7 0.15 80 / 0.5)",
                background: "oklch(0.2 0.05 355 / 0.85)",
                color: "oklch(0.88 0.14 80)",
              }}
            >
              {RESULT_LABEL[state.result]}
            </p>
          ) : phase === "idle" ? (
            <p className="text-sm text-amber-100/60">調整押注金額，按「發牌」開始這一局</p>
          ) : (
            <p className="text-sm text-amber-100/60">補牌越接近10.5點越好，別爆牌了</p>
          )}
        </div>

        <div className="flex min-h-[7.5rem] flex-col items-center gap-1.5">
          <p className="font-mono text-sm font-bold text-amber-100 tabular-nums">
            {phase === "idle" ? "—" : `${thPoints(state.player)} 點`}
          </p>
          <CardRow cards={state.player} />
          <p className="text-xs font-semibold text-amber-200/70">玩家</p>
        </div>

        <div className="mt-3 flex justify-center gap-3">
          {phase === "playing" ? (
            <>
              <button
                onClick={hit}
                className="rounded-full bg-amber-500 px-8 py-3 text-sm font-bold text-neutral-900 shadow-lg transition active:scale-95"
              >
                補牌
              </button>
              <button
                onClick={stand}
                className="rounded-full border-2 border-amber-400 bg-transparent px-8 py-3 text-sm font-bold text-amber-200 shadow-lg transition active:scale-95"
              >
                停牌
              </button>
            </>
          ) : (
            <button
              onClick={startHand}
              className="rounded-full bg-amber-500 px-10 py-3 text-sm font-bold text-neutral-900 shadow-lg transition active:scale-95"
            >
              {phase === "over" ? "再玩一局" : "發牌"}
            </button>
          )}
        </div>
      </div>
    </CasinoTableShell>
  )
}
