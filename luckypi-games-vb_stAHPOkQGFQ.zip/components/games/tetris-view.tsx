"use client"

import { useEffect, useRef, useState } from "react"
import { PuzzleShell } from "./puzzle-shell"
import {
  ttNew,
  ttMove,
  ttRotate,
  ttTick,
  ttHardDrop,
  ttGhostY,
  ttCellsFor,
  TT_COLS,
  TT_ROWS,
  TT_COLOR,
  type TtState,
} from "@/lib/games/tetris"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playMoveSound, playLossSound } from "@/lib/games/game-audio"

export function TetrisView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<TtState>(() => ttNew())
  const overRef = useRef(false)
  const touchRef = useRef<{ x: number; y: number } | null>(null)

  const restart = () => {
    setState(ttNew())
    overRef.current = false
  }

  useEffect(() => {
    if (state.over && !overRef.current) {
      overRef.current = true
      if (soundOn) playLossSound()
    }
  }, [state.over, soundOn])

  useEffect(() => {
    const speed = Math.max(320, 780 - state.lines * 40)
    const id = setInterval(() => {
      setState((s) => (s.over ? s : ttTick(s)))
    }, speed)
    return () => clearInterval(id)
  }, [state.lines])

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") setState((s) => ttMove(s, -1))
      else if (e.key === "ArrowRight") setState((s) => ttMove(s, 1))
      else if (e.key === "ArrowUp") setState((s) => ttRotate(s))
      else if (e.key === "ArrowDown") setState((s) => ttHardDrop(s))
    }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
  }, [])

  const onTouchStart = (e: React.TouchEvent) => {
    const t = e.touches[0]
    touchRef.current = { x: t.clientX, y: t.clientY }
  }
  const onTouchEnd = (e: React.TouchEvent) => {
    const start = touchRef.current
    if (!start) return
    const t = e.changedTouches[0]
    const dx = t.clientX - start.x
    const dy = t.clientY - start.y
    if (Math.abs(dx) < 20 && Math.abs(dy) < 20) {
      setState((s) => ttRotate(s))
    } else if (Math.abs(dx) > Math.abs(dy)) {
      if (soundOn) playMoveSound()
      setState((s) => ttMove(s, dx > 0 ? 1 : -1))
    } else if (dy > 20) {
      setState((s) => ttHardDrop(s))
    }
    touchRef.current = null
  }

  const displayBoard = state.board.map((row) => [...row])
  if (state.current) {
    const ghostY = ttGhostY(state)
    for (const [r, c] of ttCellsFor(state.current)) {
      const y = ghostY + r
      const x = state.current.x + c
      if (y >= 0 && y < TT_ROWS && !displayBoard[y][x]) displayBoard[y][x] = "ghost" as never
    }
    for (const [r, c] of ttCellsFor(state.current)) {
      const y = state.current.y + r
      const x = state.current.x + c
      if (y >= 0 && y < TT_ROWS) displayBoard[y][x] = state.current.type
    }
  }

  return (
    <PuzzleShell
      gameId="tetris"
      title="俄羅斯方塊"
      subtitle="消行越多分數越高"
      status={`分數：${state.score}　消行：${state.lines}`}
      rulesBrief="左右滑動移動方塊，輕點旋轉，向下滑動快速落下。填滿一整行即可消除得分，堆到頂端遊戲結束。"
      solved={false}
      cost={15}
      onBack={onBack}
      onRestart={restart}
    >
      <div
        className="grid touch-none gap-[2px] rounded-2xl border border-border bg-card p-2 shadow-lg"
        style={{ gridTemplateColumns: `repeat(${TT_COLS}, minmax(0, 1fr))`, width: 220 }}
        onTouchStart={onTouchStart}
        onTouchEnd={onTouchEnd}
      >
        {displayBoard.flat().map((cell, i) => (
          <div
            key={i}
            className={`aspect-square rounded-[2px] ${
              cell === "ghost"
                ? "bg-muted/40"
                : cell
                  ? `${TT_COLOR[cell as keyof typeof TT_COLOR]}`
                  : "bg-muted/15"
            }`}
          />
        ))}
      </div>
      {state.over && (
        <p className="text-center text-xs font-semibold text-destructive">遊戲結束，點擊「重新開始」再挑戰一次！</p>
      )}
      <div className="grid grid-cols-3 gap-1.5">
        <button
          onClick={() => setState((s) => ttMove(s, -1))}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-bold text-muted-foreground active:scale-90"
        >
          ←
        </button>
        <button
          onClick={() => setState((s) => ttRotate(s))}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-accent text-sm font-bold text-accent-foreground active:scale-90"
        >
          ⟳
        </button>
        <button
          onClick={() => setState((s) => ttMove(s, 1))}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-bold text-muted-foreground active:scale-90"
        >
          →
        </button>
        <div />
        <button
          onClick={() => setState((s) => ttHardDrop(s))}
          className="flex h-10 w-16 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground active:scale-90"
        >
          落下
        </button>
        <div />
      </div>
    </PuzzleShell>
  )
}
