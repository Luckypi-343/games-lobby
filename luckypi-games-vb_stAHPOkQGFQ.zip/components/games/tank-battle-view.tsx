"use client"

import { useEffect, useRef, useState } from "react"
import { PuzzleShell } from "./puzzle-shell"
import { tbNew, tbMove, tbShoot, tbTick, TB_COLS, TB_ROWS, TB_WIN_HITS, type TbState } from "@/lib/games/tank-battle"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playCaptureSound, playWinSound, playLossSound } from "@/lib/games/game-audio"

export function TankBattleView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<TbState>(() => tbNew())
  const overRef = useRef(false)

  const restart = () => {
    setState(tbNew())
    overRef.current = false
  }

  useEffect(() => {
    if (state.over && !overRef.current) {
      overRef.current = true
      if (soundOn) {
        if (state.won) playWinSound()
        else playLossSound()
      }
    }
  }, [state.over, state.won, soundOn])

  useEffect(() => {
    const id = setInterval(() => {
      setState((s) => {
        const before = s.playerScore + s.enemyScore
        const next = tbTick(s)
        if (next.playerScore + next.enemyScore > before && soundOn) playCaptureSound()
        return next
      })
    }, 260)
    return () => clearInterval(id)
  }, [soundOn])

  const cellSize = 26
  const gap = 3

  return (
    <PuzzleShell
      gameId="tank-battle"
      title="坦克大戰"
      subtitle="率先命中對方 3 次獲勝"
      status={`您：${state.playerScore} 分　對手：${state.enemyScore} 分（先達 ${TB_WIN_HITS} 分獲勝）`}
      rulesBrief="左右移動戰車並發射砲彈，砲彈命中對方所在直線即得分，率先命中對方 3 次者獲勝。"
      solved={state.over && state.won}
      cost={12}
      onBack={onBack}
      onRestart={restart}
    >
      <div
        className="relative touch-none rounded-2xl border border-border bg-card shadow-lg"
        style={{ width: TB_COLS * (cellSize + gap) - gap + 16, height: TB_ROWS * (cellSize + gap) - gap + 16, padding: 8 }}
      >
        <div
          className="absolute rounded-md bg-destructive shadow-[0_0_8px_oklch(0.6_0.22_25_/_0.6)]"
          style={{ width: cellSize, height: cellSize, left: state.enemyCol * (cellSize + gap), top: 0 }}
        />
        <div
          className="absolute rounded-md bg-primary shadow-[0_0_8px_oklch(0.55_0.2_260_/_0.6)]"
          style={{
            width: cellSize,
            height: cellSize,
            left: state.playerCol * (cellSize + gap),
            top: (TB_ROWS - 1) * (cellSize + gap),
          }}
        />
        {state.playerBullets.map((b, i) => (
          <div
            key={`p${i}`}
            className="absolute rounded-full bg-[oklch(0.85_0.18_90)]"
            style={{ width: 6, height: 12, left: b.col * (cellSize + gap) + cellSize / 2 - 3, top: b.row * (cellSize + gap) }}
          />
        ))}
        {state.enemyBullets.map((b, i) => (
          <div
            key={`e${i}`}
            className="absolute rounded-full bg-destructive"
            style={{ width: 6, height: 12, left: b.col * (cellSize + gap) + cellSize / 2 - 3, top: b.row * (cellSize + gap) }}
          />
        ))}
      </div>
      {state.over && (
        <p className={`text-center text-xs font-semibold ${state.won ? "text-primary" : "text-destructive"}`}>
          {state.won ? "恭喜獲勝！" : "挑戰失敗，點「重新開始」再來一次！"}
        </p>
      )}
      <div className="grid grid-cols-3 gap-1.5">
        <button
          onClick={() => setState((s) => tbMove(s, -1))}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-bold text-muted-foreground active:scale-90"
        >
          ←
        </button>
        <button
          onClick={() => setState((s) => tbShoot(s))}
          className="flex h-10 w-14 items-center justify-center rounded-full bg-accent text-xs font-bold text-accent-foreground active:scale-90"
        >
          開火
        </button>
        <button
          onClick={() => setState((s) => tbMove(s, 1))}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-bold text-muted-foreground active:scale-90"
        >
          →
        </button>
      </div>
    </PuzzleShell>
  )
}
