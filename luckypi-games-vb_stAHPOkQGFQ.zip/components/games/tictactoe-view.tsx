"use client"

import { useEffect, useState } from "react"
import { BoardShell } from "./board-shell"
import { ttEmpty, ttMove, ttAiMove, type TTState } from "@/lib/games/tictactoe"
import { applyDifficulty } from "@/lib/games/difficulty"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playMoveSound } from "@/lib/games/game-audio"

export function TicTacToeView({ onBack }: { onBack: () => void }) {
  const { difficulty, soundOn } = useLuckyPi()
  const [mode, setMode] = useState<"ai" | "two">("ai")
  const [state, setState] = useState<TTState>(ttEmpty())

  useEffect(() => {
    if (mode === "ai" && state.turn === 2 && state.status === "playing") {
      const t = setTimeout(() => {
        const best = ttAiMove(state)
        const empties = state.board.map((c, i) => (c === 0 ? i : -1)).filter((i) => i >= 0)
        const move = applyDifficulty(difficulty, best, empties)!
        if (soundOn) playMoveSound()
        setState((s) => ttMove(s, move))
      }, 500)
      return () => clearTimeout(t)
    }
  }, [mode, state, difficulty])

  const restart = () => setState(ttEmpty())

  const result = state.status === "win" ? (state.winner === 1 ? "win" : "loss") : state.status === "draw" ? "draw" : null

  const statusText =
    state.status === "win"
      ? state.winner === 1
        ? "您獲勝了！"
        : mode === "ai"
          ? "AI 獲勝"
          : "玩家二獲勝"
      : state.status === "draw"
        ? "平手"
        : state.turn === 1
          ? mode === "ai"
            ? "您的回合"
            : "玩家一回合"
          : mode === "ai"
            ? "AI 思考中…"
            : "玩家二回合"

  return (
    <BoardShell
      gameId="tictactoe"
      title="井字棋"
      subtitle="3×3 放大格式"
      status={statusText}
      result={result}
      rulesBrief="輪流在 3×3 棋盤放置棋子，率先橫、豎或斜連成一線者獲勝，九格填滿仍無連線則平手。"
      onBack={onBack}
      onRestart={restart}
      mode={mode}
      onModeChange={(m) => {
        setMode(m)
        setState(ttEmpty())
      }}
    >
      <div className="grid w-[264px] shrink-0 grid-cols-3 gap-2 rounded-2xl border border-border bg-card p-3 shadow-lg">
        {state.board.map((cell, i) => (
          <button
            key={i}
            onClick={() => {
              if (state.status !== "playing") return
              if (mode === "ai" && state.turn === 2) return
              if (soundOn) playMoveSound()
              setState((s) => ttMove(s, i))
            }}
            className={`flex h-20 w-20 items-center justify-center rounded-xl text-4xl font-bold transition active:scale-95 ${
              state.line?.includes(i) ? "bg-primary/20 text-primary" : "bg-muted text-foreground"
            }`}
          >
            {cell === 1 ? "✕" : cell === 2 ? "○" : ""}
          </button>
        ))}
      </div>
    </BoardShell>
  )
}
