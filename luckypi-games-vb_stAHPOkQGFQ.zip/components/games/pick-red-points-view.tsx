"use client"

import { useState } from "react"
import { BoardShell, type PuzzleOutcome } from "./board-shell"
import { PlayingCard } from "./playing-card"
import { dealPickRedPoints, playPrpCard, totalPoints, type PickRedPointsState } from "@/lib/games/pick-red-points"
import { playMoveSound, playCaptureSound } from "@/lib/games/game-audio"
import { useLuckyPi } from "@/contexts/luckypi-context"

const GAME_ID = "pick-red-points"

export function PickRedPointsView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<PickRedPointsState>(() => dealPickRedPoints())

  const result: PuzzleOutcome = state.outcome === "win" ? "win" : state.outcome === "lose" ? "loss" : state.outcome === "draw" ? "draw" : null

  function handlePlay(cardId: string) {
    if (state.finished || state.turn !== "you") return
    const card = state.hand.you.find((c) => c.id === cardId)
    if (!card) return
    const willCapture = state.table.some((c) => c.rank === card.rank)
    const next = playPrpCard(state, "you", card)
    setState(next)
    if (soundOn) (willCapture ? playCaptureSound : playMoveSound)()
  }

  const yourPoints = totalPoints(state.captured.you)
  const aiPoints = totalPoints(state.captured.ai)

  const status = state.finished
    ? `終局比分 您 ${yourPoints} ： 電腦 ${aiPoints}`
    : `目前比分 您 ${yourPoints} ： 電腦 ${aiPoints}`

  return (
    <BoardShell
      gameId={GAME_ID}
      title="撿紅點"
      subtitle="出牌配對桌面同點數的牌"
      status={status}
      rulesBrief="輪流出一張牌：若手上出的牌點數跟桌面上的牌相同，就能把桌面上所有同點數的牌連同這張牌一起撿走得分；沒有相同點數則留在桌面上。整副牌出完後比較雙方撿到的紅心／方塊點數：一般紅牌 1 分，紅色 10、J、Q、K 各算 10 分，總分較高者獲勝。"
      result={result}
      onBack={onBack}
      onRestart={() => setState(dealPickRedPoints())}
      mode="single"
    >
      <div className="flex w-full max-w-sm flex-col items-center gap-3">
        <div className="flex flex-col items-center gap-1">
          <span className="text-[11px] text-muted-foreground">電腦 ・ 手牌 {state.hand.ai.length} ・ 已撿 {aiPoints} 分</span>
          <div className="flex gap-1">
            {state.hand.ai.map((c) => (
              <PlayingCard key={c.id} card={c} faceDown small />
            ))}
          </div>
        </div>

        <div className="flex min-h-24 w-full flex-wrap items-center justify-center gap-1.5 rounded-xl border border-border bg-card/60 p-2">
          {state.table.length === 0 ? (
            <p className="text-[11px] text-muted-foreground">桌面已清空</p>
          ) : (
            state.table.map((c) => <PlayingCard key={c.id} card={c} small />)
          )}
        </div>

        <div className="flex flex-col items-center gap-1">
          <span className="text-[11px] font-semibold text-primary">您 ・ 已撿 {yourPoints} 分</span>
          <div className="flex flex-wrap justify-center gap-1">
            {state.hand.you.map((card) => (
              <button
                key={card.id}
                onClick={() => handlePlay(card.id)}
                disabled={state.turn !== "you" || state.finished}
                className="transition active:scale-95 disabled:opacity-40"
              >
                <PlayingCard card={card} small />
              </button>
            ))}
          </div>
        </div>
      </div>
    </BoardShell>
  )
}
