import type { LangId } from "./i18n"
import type { PuzzleGameId } from "./data"

export interface PuzzleGameText {
  name: string
  subtitle: string
  rules: string
}

export interface PuzzleCommonText {
  mahjongWall: string
  mahjongTotalRounds: string
  mahjongWinCount: string
  mahjongWinRate: string
  mahjongYourDiscards: string
  mahjongEatPongKong: string
  mahjongTingWinDraw: string
  checkersKing: string
  comingSoonText: string
  backToLobby: string
  costToastTemplate: string
}

// Partial so each language file only needs to supply entries for the games it has
// translated so far; puzzle-game-screen.tsx falls back to the Chinese base copy
// (from lib/luckypi/data.ts) for any game id a language table hasn't covered yet.
type GameTable = Partial<Record<PuzzleGameId, PuzzleGameText>>

const zhTW: GameTable = {
  xiangqi: {
    name: "中國象棋",
    subtitle: "AI單人／雙人",
    rules:
      "雙方輪流移動棋子，率先將對方主帥（將）逼入無路可走者獲勝。走法依傳統象棋規則：車直走、馬走日字、象走田字、士走斜線，兵過河後可橫向移動。",
  },
  "darkchess-classic": {
    name: "暗棋（傳統）",
    subtitle: "AI單人／雙人",
    rules: "所有棋子背面朝上扣置盤面，翻開後依傳統大小順序互相吃子，吃光對方棋子或使對方無棋可走者獲勝。",
  },
  "darkchess-variant": {
    name: "暗棋（變異）",
    subtitle: "AI單人／雙人",
    rules: "玩法與傳統暗棋相同，但砲的攻擊與跳吃方式採用變異規則，增添更多戰術變化，適合喜歡挑戰新玩法的玩家。",
  },
  go: {
    name: "中國圍棋",
    subtitle: "19×19",
    rules: "雙方輪流在 19×19 棋盤的交叉點上放置黑白棋子，圍地面積較多者獲勝；被完全包圍、沒有氣的棋子會被提走。",
  },
  gomoku: { name: "五子棋", subtitle: "17×17", rules: "雙方輪流在棋盤上放置棋子，率先在橫、豎或斜方向連成五子者獲勝。" },
  othello: {
    name: "黑白棋",
    subtitle: "標準規格",
    rules: "雙方輪流放置棋子，只要能夾住對方棋子即可翻轉為己方顏色，終局時棋盤上己方棋子數量較多者獲勝。",
  },
  mahjong: {
    name: "中國麻將",
    subtitle: "AI單人（三家電腦）",
    rules: "與三位電腦對手同桌，輪流摸牌、打牌，可吃、碰、槓其他玩家棄牌，率先湊成合法胡牌牌型者胡牌獲勝。",
  },
  luzhanqi: {
    name: "陸軍棋",
    subtitle: "AI單人／雙人",
    rules: "雙方棋子軍階保密，對方只能看到背面。交戰時依軍階大小決定勝負，率先奪取對方軍旗或使對方無棋可走者獲勝。",
  },
  checkers: {
    name: "跳棋",
    subtitle: "標準規格",
    rules: "雙方輪流斜線移動棋子，可跳過並吃掉對方棋子，吃光對方棋子或使對方無棋可走者獲勝。",
  },
  tictactoe: {
    name: "井字棋",
    subtitle: "3×3放大格式",
    rules: "雙方輪流在 3×3 棋盤上放置符號，率先在橫、豎或斜方向連成三子者獲勝。",
  },
}

const zhCN: GameTable = {
  xiangqi: {
    name: "中国象棋",
    subtitle: "AI单人／双人",
    rules:
      "双方轮流移动棋子，率先将对方主帅（将）逼入无路可走者获胜。走法依传统象棋规则：车直走、马走日字、象走田字、士走斜线，兵过河后可横向移动。",
  },
  "darkchess-classic": {
    name: "暗棋（传统）",
    subtitle: "AI单人／双人",
    rules: "所有棋子背面朝上扣置盘面，翻开后依传统大小顺序互相吃子，吃光对方棋子或使对方无棋可走者获胜。",
  },
  "darkchess-variant": {
    name: "暗棋（变异）",
    subtitle: "AI单人／双人",
    rules: "玩法与传统暗棋相同，但炮的攻击与跳吃方式采用变异规则，增添更多战术变化，适合喜欢挑战新玩法的玩家。",
  },
  go: {
    name: "中国围棋",
    subtitle: "19×19",
    rules: "双方轮流在 19×19 棋盘的交叉点上放置黑白棋子，围地面积较多者获胜；被完全包围、没有气的棋子会被提走。",
  },
  gomoku: { name: "五子棋", subtitle: "17×17", rules: "双方轮流在棋盘上放置棋子，率先在横、竖或斜方向连成五子者获胜。" },
  othello: {
    name: "黑白棋",
    subtitle: "标准规格",
    rules: "双方轮流放置棋子，只要能夹住对方棋子即可翻转为己方颜色，终局时棋盘上己方棋子数量较多者获胜。",
  },
  mahjong: {
    name: "中国麻将",
    subtitle: "AI单人（三家电脑）",
    rules: "与三位电脑对手同桌，轮流摸牌、打牌，可吃、碰、杠其他玩家弃牌，率先凑成合法胡牌牌型者胡牌获胜。",
  },
  luzhanqi: {
    name: "陆军棋",
    subtitle: "AI单人／双人",
    rules: "双方棋子军阶保密，对方只能看到背面。交战时依军阶大小决定胜负，率先夺取对方军旗或使对方无棋可走者获胜。",
  },
  checkers: {
    name: "跳棋",
    subtitle: "标准规格",
    rules: "双方轮流斜线移动棋子，可跳过并吃掉对方棋子，吃光对方棋子或使对方无棋可走者获胜。",
  },
  tictactoe: {
    name: "井字棋",
    subtitle: "3×3放大格式",
    rules: "双方轮流在 3×3 棋盘上放置符号，率先在横、竖或斜方向连成三子者获胜。",
  },
}

const en: GameTable = {
  xiangqi: {
    name: "Chinese Chess",
    subtitle: "AI Solo / 2 Players",
    rules:
      "Take turns moving pieces; be the first to trap the opponent's general with no escape. Follows classic Xiangqi rules: the chariot moves straight, the horse in an L-shape, the elephant diagonally within its own side, the guard diagonally near the palace, and soldiers may move sideways after crossing the river.",
  },
  "darkchess-classic": {
    name: "Dark Chess (Classic)",
    subtitle: "AI Solo / 2 Players",
    rules:
      "All pieces start face-down. Flip a piece to reveal it, then capture using the traditional rank order. Capture all opposing pieces or leave the opponent with no legal move to win.",
  },
  "darkchess-variant": {
    name: "Dark Chess (Variant)",
    subtitle: "AI Solo / 2 Players",
    rules:
      "Same as Classic Dark Chess, but the cannon's attack and jump-capture follow variant rules, adding extra tactics for players who enjoy a fresh twist.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules:
      "Take turns placing black and white stones on the intersections of a 19×19 board. Whoever encloses more territory wins; stones fully surrounded with no liberties are captured.",
  },
  gomoku: {
    name: "Gomoku",
    subtitle: "17×17",
    rules: "Take turns placing stones. Be the first to connect five in a row — horizontally, vertically, or diagonally — to win.",
  },
  othello: {
    name: "Othello",
    subtitle: "Standard",
    rules:
      "Take turns placing discs; any opposing discs sandwiched between yours are flipped to your color. Whoever has more discs on the board at the end wins.",
  },
  mahjong: {
    name: "Chinese Mahjong",
    subtitle: "AI Solo (3 Computer Players)",
    rules:
      "Play at a table with three computer opponents. Draw and discard tiles, claim other players' discards with Chow/Pong/Kong, and be the first to complete a valid winning hand to win.",
  },
  luzhanqi: {
    name: "Luzhanqi (Army Chess)",
    subtitle: "AI Solo / 2 Players",
    rules:
      "Each side's piece ranks are hidden from the opponent, who only sees the back. Battles are settled by rank; be the first to capture the opponent's flag or leave them with no legal move to win.",
  },
  checkers: {
    name: "Checkers",
    subtitle: "Standard",
    rules:
      "Take turns moving pieces diagonally, jumping over to capture opposing pieces. Capture all opposing pieces or leave the opponent with no legal move to win.",
  },
  tictactoe: {
    name: "Tic-Tac-Toe",
    subtitle: "Large 3×3 Format",
    rules: "Take turns placing your symbol. Be the first to connect three in a row — horizontally, vertically, or diagonally — to win.",
  },
  chess: {
    name: "Chess",
    subtitle: "AI Solo / 2 Players",
    rules:
      "Take turns moving pieces; be the first to checkmate the opponent's king to win. Follows standard chess rules for how the pawn, rook, knight, bishop, queen, and king move.",
  },
  connect4: {
    name: "Connect Four",
    subtitle: "AI Solo / 2 Players",
    rules: "Take turns dropping pieces into the upright grid. Be the first to connect four in a row — horizontally, vertically, or diagonally — to win.",
  },
  "chinese-checkers": {
    name: "Chinese Checkers",
    subtitle: "Star Board",
    rules:
      "On a six-pointed star board, be the first to move all of your pieces into the opposite corner. Pieces may step or chain-jump over other pieces to advance.",
  },
  jigsaw: {
    name: "Sliding Puzzle",
    subtitle: "Numbered Tiles",
    rules: "Tap a tile next to the empty space to slide it in. Arrange the tiles from 1 to 15 in order to complete the challenge.",
  },
  "number-merge": {
    name: "Number Merge",
    subtitle: "2048 Style",
    rules: "Swipe or use the arrow keys. Matching tiles merge and double in value when they collide; reach 2048 to win.",
  },
  "memory-match": {
    name: "Memory Match",
    subtitle: "Pairing Challenge",
    rules: "Flip two cards at a time; matching pairs stay face-up. Match every pair using as few flips as possible to win.",
  },
  ludo: {
    name: "Ludo",
    subtitle: "2 Players",
    rules:
      "Roll the dice to move your pieces around the board and home. Landing on an opponent's piece sends it back to start.",
  },
  solitaire: {
    name: "Solitaire",
    subtitle: "Classic Single Player",
    rules: "Sort every card into the four foundation piles by suit and ascending rank to clear the board and win.",
  },
  rummikub: {
    name: "Rummikub",
    subtitle: "Tile Rummy vs AI",
    rules: "Use your numbered tiles to form runs or same-number sets and lay them on the table. Be the first to play all your tiles to win.",
  },
  "rps-battle": {
    name: "Rock Paper Scissors",
    subtitle: "vs AI",
    rules: "Throw rock, paper, or scissors against the computer at the same time. Whoever leads in rounds won takes the match.",
  },
  "texas-holdem": {
    name: "Texas Hold'em",
    subtitle: "Heads-up vs AI (Simplified)",
    rules:
      "You and the AI each hold 2 cards, plus 5 shared community cards. Choose to Call and reveal hands, or Fold to give up the hand — the higher-ranked hand wins the pot.",
  },
  blackjack: {
    name: "Blackjack",
    subtitle: "21 vs the Dealer",
    rules:
      "Get as close to 21 as possible without going over. Aces count as 1 or 11, face cards count as 10. Hit or Stand — the dealer must keep drawing until reaching 17 or more.",
  },
  baccarat: {
    name: "Baccarat",
    subtitle: "Player / Banker / Tie",
    rules:
      "Bet on Player, Banker, or Tie before the cards are dealt. Hand totals use the last digit of the sum; the higher total wins. Extra cards are drawn automatically per standard baccarat rules.",
  },
  war: {
    name: "War",
    subtitle: "High Card vs AI",
    rules:
      "The deck is split evenly. Each round both sides flip a card — the higher card wins the round. Ties trigger a burn-and-battle; whoever holds more cards at the end wins.",
  },
  "three-card-poker": {
    name: "Three Card Poker",
    subtitle: "vs the Dealer",
    rules:
      "You and the dealer are each dealt 3 cards. After viewing your hand, Call to reveal and compare, or Fold to give up the round — the higher-ranked hand wins.",
  },
  klotski: {
    name: "Klotski",
    subtitle: "Sliding Block Puzzle",
    rules: "Slide the differently sized blocks within the limited board space. Move the largest block to the exit at the bottom to win.",
  },
  tetris: {
    name: "Tetris",
    subtitle: "Stack & Clear Lines",
    rules:
      "Swipe left or right to move the falling piece, tap to rotate, swipe down to drop fast. Fill an entire row to clear it and score; the game ends if the stack reaches the top.",
  },
  "bubble-shooter": {
    name: "Bubble Shooter",
    subtitle: "Match Colors to Clear",
    rules: "Tap a lane to fire the current bubble. Three or more matching bubbles connected together are cleared for points; the game ends if the bubbles reach the top.",
  },
  match3: {
    name: "Match-3 Blast",
    subtitle: "Swap to Match",
    rules:
      "Tap a tile, then tap a neighboring tile to swap them. Matching 3 or more of the same color clears them and refills from above, which can chain into more matches.",
  },
  hanoi: {
    name: "Tower of Hanoi",
    subtitle: "Move the Discs",
    rules:
      "Tap a peg to pick up its top disc, then tap another peg to move it there. A larger disc can never sit on a smaller one — move the whole stack to the rightmost peg to win.",
  },
  "water-sort": {
    name: "Water Sort Puzzle",
    subtitle: "Pour to Sort Colors",
    rules:
      "Tap a tube to pick up its top color, then tap another tube to pour it in — only into an empty tube or one topped with the same color. Sort every tube into a single color to win.",
  },
  "pipe-connect": {
    name: "Pipe Connect",
    subtitle: "Rotate to Link Up",
    rules: "Tap a pipe tile to rotate it 90°. Connect the water source in the top-left all the way to the exit in the bottom-right to win.",
  },
  "stack-tower": {
    name: "Stack Tower",
    subtitle: "Time Your Drop",
    rules:
      "The block above swings left and right; tap to drop it onto the stack below. The less it overlaps, the narrower it gets — miss the stack entirely and the game ends.",
  },
  "sequence-sort": {
    name: "Sort Master",
    subtitle: "Swap to Order",
    rules: "Tap two number tiles to swap their positions. Arrange every number from smallest to largest using as few swaps as possible to win.",
  },
  "mini-sudoku": {
    name: "Mini Sudoku",
    subtitle: "6×6 Grid",
    rules:
      "Every row, column, and 2×3 box must contain the numbers 1 through 6 with no repeats. Fill the entire grid with no conflicts to win.",
  },
  "shooting-range": {
    name: "Shooting Range",
    subtitle: "Fast Reflex Targets",
    rules: "Targets light up randomly across the grid — tap them as fast as you can to score. Reach the target score before time runs out to win.",
  },
  "space-invaders": {
    name: "Space Invaders",
    subtitle: "Clear the Fleet to Win",
    rules:
      "Move left and right to dodge enemy fire and shoot down the entire alien fleet. The challenge fails if the fleet closes in or your lives run out.",
  },
  "tank-battle": {
    name: "Tank Battle",
    subtitle: "First to 3 Hits Wins",
    rules: "Move your tank left and right and fire shells. Hitting the opponent's lane scores a point — be the first to land 3 hits to win.",
  },
  "brick-breaker": {
    name: "Brick Breaker",
    subtitle: "Clear Every Brick to Win",
    rules:
      "Drag the paddle left and right to bounce the ball and break all the bricks to win. Letting the ball fall off the bottom costs a life; the challenge fails if your lives run out.",
  },
  "zombie-defense": {
    name: "Zombie Defense",
    subtitle: "Survive Every Wave to Win",
    rules:
      "Zombies advance along the lane from the right; tap them to destroy them (some take two hits). Letting one reach the left edge costs health — survive every wave to win.",
  },
  "air-combat": {
    name: "Air Combat",
    subtitle: "Survive & Reach the Target Score",
    rules:
      "Your fighter fires automatically; move left and right to dodge enemy planes and clear them. Survive the time limit while reaching the target score to win; running out of lives fails the challenge.",
  },
  billiards: {
    name: "Billiards",
    subtitle: "Drag to Aim, Clear All Balls",
    rules:
      "Drag backward from the cue ball to aim, then release to strike. Pocket every colored ball before you run out of shots to win.",
  },
  bowling: {
    name: "Bowling",
    subtitle: "Reach the Pin Target in 3 Frames",
    rules: "Drag the slider to set your throw angle, then release to bowl. Reach the target total pins knocked down within 3 frames to win.",
  },
  "basketball-shoot": {
    name: "Basketball Shootout",
    subtitle: "Time Your Shot",
    rules: "The power meter swings back and forth automatically — tap to shoot when it's near the center to score. Make enough baskets to win.",
  },
  "penalty-kick": {
    name: "Penalty Kick",
    subtitle: "Pick a Side vs the Keeper",
    rules: "Choose left, center, or right to shoot against a keeper who dives randomly. Score enough goals within 5 rounds to win.",
  },
  racing: {
    name: "Racing Rush",
    subtitle: "Switch Lanes to Dodge Traffic",
    rules: "Switch lanes left and right to dodge oncoming traffic. The challenge fails if you run out of lives before reaching the finish distance.",
  },
  parking: {
    name: "Parking Challenge",
    subtitle: "Park Within Your Moves",
    rules: "Use the steering and forward controls to park exactly in the marked spot before you run out of moves or collisions to win.",
  },
  motocross: {
    name: "Motocross Jump",
    subtitle: "Jump the Pits to the Finish",
    rules: "Tap to jump your bike and clear the pits ahead with good timing. The challenge fails if your lives run out before reaching the finish.",
  },
  "drift-racing": {
    name: "Drift Racing",
    subtitle: "Steer with the Track to Score",
    rules: "Steer with the track's curves to stay on course while racking up drift points. Reach the finish with enough points to win.",
  },
  "duel-arena": {
    name: "Duel Arena",
    subtitle: "Turn-Based, First KO Wins",
    rules:
      "Choose Attack to build your special meter, Guard to halve the next hit, or unleash your Finisher once your meter is full. Be the first to reduce your opponent's health to zero to win.",
  },
}

const ja: GameTable = {
  xiangqi: {
    name: "中国将棋（シャンチー）",
    subtitle: "AIソロ／2人対戦",
    rules:
      "交互に駒を動かし、相手の将（帥）を先に詰ませた方が勝利。伝統的なシャンチーの規則に従う：車は直進、馬はL字型、象は自陣内で斜め、士は宮殿付近を斜めに移動、兵は川を渡ると横移動が可能。",
  },
  "darkchess-classic": {
    name: "暗棋（クラシック）",
    subtitle: "AIソロ／2人対戦",
    rules: "すべての駒は裏向きで配置され、めくって表向きにした後は伝統的な階級順で相手の駒を取る。相手の駒を全て取るか、動けなくした方が勝利。",
  },
  "darkchess-variant": {
    name: "暗棋（バリアント）",
    subtitle: "AIソロ／2人対戦",
    rules: "クラシック暗棋と同じルールだが、砲の攻撃とジャンプ捕獲に特別ルールを採用し、新しい戦術を楽しめる。",
  },
  go: {
    name: "囲碁",
    subtitle: "19×19",
    rules: "交互に19×19の交点に黒白の石を置き、より多くの領地を囲んだ方が勝利。完全に囲まれ「気」を失った石は取られる。",
  },
  gomoku: { name: "五子棋（連珠）", subtitle: "17×17", rules: "交互に石を置き、縦・横・斜めのいずれかで先に五つ並べた方が勝利。" },
  othello: {
    name: "オセロ",
    subtitle: "標準",
    rules: "交互に石を置き、相手の石を挟むと自分の色にひっくり返せる。終局時に石が多い方が勝利。",
  },
  mahjong: {
    name: "中国麻雀",
    subtitle: "AIソロ（コンピュータ3人）",
    rules: "コンピュータ3人と卓を囲み、ツモと打牌を繰り返し、他家の捨て牌をチー・ポン・カンで取れる。先に和了した方が勝利。",
  },
  luzhanqi: {
    name: "陸軍棋",
    subtitle: "AIソロ／2人対戦",
    rules: "双方の駒の階級は非公開で、相手には裏面しか見えない。階級の大小で勝敗が決まり、先に相手の軍旗を奪うか動けなくした方が勝利。",
  },
  checkers: {
    name: "チェッカー",
    subtitle: "標準",
    rules: "交互に駒を斜めに動かし、相手の駒を飛び越えて取る。相手の駒を全て取るか動けなくした方が勝利。",
  },
  tictactoe: {
    name: "三目並べ",
    subtitle: "拡大版3×3",
    rules: "交互に印を置き、縦・横・斜めのいずれかで先に三つ並べた方が勝利。",
  },
}

const ko: GameTable = {
  xiangqi: {
    name: "중국 장기",
    subtitle: "AI 솔로／2인 대전",
    rules:
      "교대로 기물을 움직여 상대의 장(將)을 먼저 궁지에 몰면 승리합니다. 전통 장기 규칙: 차는 직선, 마는 L자, 상은 자기 진영에서 대각선, 사는 궁 주변 대각선, 병은 강을 건너면 좌우 이동이 가능합니다.",
  },
  "darkchess-classic": {
    name: "암기(전통)",
    subtitle: "AI 솔로／2인 대전",
    rules: "모든 기물은 뒤집혀 배치되며, 뒤집은 후 전통적인 서열 순서로 상대 기물을 잡습니다. 상대 기물을 모두 잡거나 움직일 수 없게 만들면 승리합니다.",
  },
  "darkchess-variant": {
    name: "암기(변형)",
    subtitle: "AI 솔로／2인 대전",
    rules: "전통 암기와 동일하지만 포의 공격과 뛰어넘는 방식에 변형 규칙을 적용해 더 다양한 전술을 즐길 수 있습니다.",
  },
  go: {
    name: "바둑",
    subtitle: "19×19",
    rules: "교대로 19×19 바둑판의 교차점에 흑백 돌을 놓아 더 많은 영역을 차지하면 승리합니다. 완전히 포위되어 활로가 없는 돌은 잡힙니다.",
  },
  gomoku: { name: "오목", subtitle: "17×17", rules: "교대로 돌을 놓아 가로, 세로, 대각선 중 하나로 먼저 다섯 개를 연결하면 승리합니다." },
  othello: {
    name: "오델로",
    subtitle: "표준",
    rules: "교대로 돌을 놓아 상대 돌을 사이에 끼우면 자신의 색으로 뒤집습니다. 종료 시 돌이 더 많은 쪽이 승리합니다.",
  },
  mahjong: {
    name: "중국 마작",
    subtitle: "AI 솔로(컴퓨터 3인)",
    rules: "컴퓨터 3명과 함께 패를 뽑고 버리며, 다른 사람의 버린 패로 치・펑・깡을 할 수 있습니다. 먼저 정식 승패 조합을 완성하면 승리합니다.",
  },
  luzhanqi: {
    name: "육전기(군대 장기)",
    subtitle: "AI 솔로／2인 대전",
    rules: "양측 기물의 계급은 비공개이며 상대는 뒷면만 볼 수 있습니다. 계급의 높낮이로 승부가 결정되며, 먼저 상대의 군기를 빼앗거나 움직일 수 없게 만들면 승리합니다.",
  },
  checkers: {
    name: "체커",
    subtitle: "표준",
    rules: "교대로 기물을 대각선으로 움직이며 상대 기물을 뛰어넘어 잡습니다. 상대 기물을 모두 잡거나 움직일 수 없게 만들면 승리합니다.",
  },
  tictactoe: {
    name: "틱택토",
    subtitle: "확대판 3×3",
    rules: "교대로 기호를 놓아 가로, 세로, 대각선 중 하나로 먼저 세 개를 연결하면 승리합니다.",
  },
}

const vi: GameTable = {
  xiangqi: {
    name: "Cờ Tướng Trung Quốc",
    subtitle: "AI đơn／2 người",
    rules:
      "Hai bên lần lượt di chuyển quân cờ, ai dồn được Tướng đối phương vào đường cùng trước sẽ thắng. Theo luật cờ tướng truyền thống: Xe đi thẳng, Mã đi chữ L, Tượng đi chéo trong phần sân nhà, Sĩ đi chéo quanh cung, Binh sau khi qua sông có thể đi ngang.",
  },
  "darkchess-classic": {
    name: "Cờ Úp (Cổ điển)",
    subtitle: "AI đơn／2 người",
    rules: "Tất cả quân cờ đặt mặt úp xuống, sau khi lật lên sẽ ăn quân theo thứ tự cấp bậc truyền thống. Ăn hết quân đối phương hoặc khiến đối phương không còn nước đi sẽ thắng.",
  },
  "darkchess-variant": {
    name: "Cờ Úp (Biến thể)",
    subtitle: "AI đơn／2 người",
    rules: "Giống cờ Úp cổ điển nhưng cách Pháo tấn công và nhảy ăn quân áp dụng quy tắc biến thể, mang lại nhiều chiến thuật mới.",
  },
  go: {
    name: "Cờ Vây",
    subtitle: "19×19",
    rules: "Hai bên lần lượt đặt quân đen trắng tại các giao điểm trên bàn 19×19, ai chiếm được nhiều lãnh địa hơn sẽ thắng; quân bị bao vây hoàn toàn và hết khí sẽ bị bắt.",
  },
  gomoku: { name: "Cờ Caro", subtitle: "17×17", rules: "Hai bên lần lượt đặt quân, ai nối được năm quân liên tiếp theo hàng ngang, hàng dọc hoặc đường chéo trước sẽ thắng." },
  othello: {
    name: "Cờ Lật (Othello)",
    subtitle: "Tiêu chuẩn",
    rules: "Hai bên lần lượt đặt quân, kẹp quân đối phương giữa hai quân của mình để lật thành màu của mình. Kết thúc ai có nhiều quân hơn sẽ thắng.",
  },
  mahjong: {
    name: "Mạt Chược Trung Quốc",
    subtitle: "AI đơn (3 đối thủ máy)",
    rules: "Chơi cùng bàn với 3 đối thủ máy, lần lượt rút và đánh bài, có thể Ăn／Bắt Cạ／Bắt Khàn bài đối thủ đánh ra. Ai hoàn thành bộ bài thắng hợp lệ trước sẽ thắng.",
  },
  luzhanqi: {
    name: "Cờ Lục Quân",
    subtitle: "AI đơn／2 người",
    rules: "Cấp bậc quân cờ hai bên được giữ bí mật, đối phương chỉ thấy mặt sau. Khi giao chiến, cấp bậc cao hơn sẽ thắng; ai chiếm được cờ hiệu đối phương hoặc khiến đối phương hết nước đi trước sẽ thắng.",
  },
  checkers: {
    name: "Cờ Đam",
    subtitle: "Tiêu chuẩn",
    rules: "Hai bên lần lượt di chuyển quân theo đường chéo, có thể nhảy qua để ăn quân đối phương. Ăn hết quân đối phương hoặc khiến đối phương hết nước đi sẽ thắng.",
  },
  tictactoe: {
    name: "Cờ Caro 3x3",
    subtitle: "Bản mở rộng 3×3",
    rules: "Hai bên lần lượt đặt ký hiệu, ai nối được ba ký hiệu liên tiếp theo hàng ngang, hàng dọc hoặc đường chéo trước sẽ thắng.",
  },
}

const th: GameTable = {
  xiangqi: {
    name: "หมากรุกจีน",
    subtitle: "AI เดี่ยว／2 คน",
    rules:
      "สลับกันเดินหมาก ผู้ที่บีบให้ขุนพลฝ่ายตรงข้ามจนมุมก่อนเป็นผู้ชนะ ตามกฎหมากรุกจีนดั้งเดิม: เรือเดินตรง ม้าเดินรูปตัว L ช้างเดินทแยงในฝั่งตน ที่ปรึกษาเดินทแยงรอบวัง ทหารข้ามแม่น้ำแล้วเดินด้านข้างได้",
  },
  "darkchess-classic": {
    name: "หมากรุกซ่อน (คลาสสิก)",
    subtitle: "AI เดี่ยว／2 คน",
    rules: "หมากทั้งหมดวางหน้าลง เมื่อเปิดแล้วจะกินกันตามลำดับยศดั้งเดิม กินหมากฝ่ายตรงข้ามหมดหรือทำให้เดินไม่ได้คือชนะ",
  },
  "darkchess-variant": {
    name: "หมากรุกซ่อน (แบบพิเศษ)",
    subtitle: "AI เดี่ยว／2 คน",
    rules: "เหมือนแบบคลาสสิกแต่ปืนใช้กฎการโจมตีและกระโดดกินแบบพิเศษ เพิ่มกลยุทธ์ใหม่ๆ",
  },
  go: {
    name: "หมากล้อม (โกะ)",
    subtitle: "19×19",
    rules: "สลับกันวางหมากดำขาวบนจุดตัดกระดาน 19×19 ผู้ที่ล้อมพื้นที่ได้มากกว่าชนะ หมากที่ถูกล้อมจนไม่มีลมหายใจจะถูกจับ",
  },
  gomoku: { name: "หมากห้าตา", subtitle: "17×17", rules: "สลับกันวางหมาก ผู้ที่เรียงห้าตัวติดกันตามแนวนอน แนวตั้ง หรือทแยงก่อนคือชนะ" },
  othello: {
    name: "ออกแซโล่",
    subtitle: "มาตรฐาน",
    rules: "สลับกันวางหมาก หากประกบหมากฝ่ายตรงข้ามได้จะพลิกเป็นสีของตน จบเกมผู้ที่มีหมากมากกว่าชนะ",
  },
  mahjong: {
    name: "นกกระจอกจีน",
    subtitle: "AI เดี่ยว (คอมพิวเตอร์ 3 คน)",
    rules: "เล่นร่วมโต๊ะกับคอมพิวเตอร์ 3 คน สลับกันจั่วและทิ้งไพ่ สามารถกิน／ป๊อง／กงไพ่ที่ทิ้งได้ ผู้ที่ครบมือชนะก่อนคือผู้ชนะ",
  },
  luzhanqi: {
    name: "หมากรุกกองทัพ",
    subtitle: "AI เดี่ยว／2 คน",
    rules: "ยศของหมากทั้งสองฝ่ายเป็นความลับ ฝ่ายตรงข้ามเห็นแค่ด้านหลัง การต่อสู้ตัดสินด้วยยศ ผู้ที่ยึดธงฝ่ายตรงข้ามหรือทำให้เดินไม่ได้ก่อนคือชนะ",
  },
  checkers: {
    name: "หมากฮอส",
    subtitle: "มาตรฐาน",
    rules: "สลับกันเดินหมากทางทแยง กระโดดข้ามเพื่อกินหมากฝ่ายตรงข้ามได้ กินหมดหรือทำให้เดินไม่ได้คือชนะ",
  },
  tictactoe: {
    name: "เกม OX",
    subtitle: "ขนาดขยาย 3×3",
    rules: "สลับกันวางสัญลักษณ์ ผู้ที่เรียงสามตัวติดกันตามแนวนอน แนวตั้ง หรือทแยงก่อนคือชนะ",
  },
}

const id: GameTable = {
  xiangqi: {
    name: "Catur Cina",
    subtitle: "AI Solo／2 Pemain",
    rules:
      "Bergiliran menggerakkan bidak, siapa yang lebih dulu memojokkan jenderal lawan hingga tak bisa bergerak akan menang. Mengikuti aturan Xiangqi tradisional: Kereta bergerak lurus, Kuda bergerak bentuk L, Gajah bergerak diagonal di wilayah sendiri, Penasihat bergerak diagonal dekat istana, Prajurit bisa bergerak menyamping setelah menyeberangi sungai.",
  },
  "darkchess-classic": {
    name: "Catur Gelap (Klasik)",
    subtitle: "AI Solo／2 Pemain",
    rules: "Semua bidak diletakkan terbalik, setelah dibuka akan memakan sesuai urutan pangkat tradisional. Memakan semua bidak lawan atau membuat lawan tak bisa bergerak akan menang.",
  },
  "darkchess-variant": {
    name: "Catur Gelap (Varian)",
    subtitle: "AI Solo／2 Pemain",
    rules: "Sama seperti Catur Gelap Klasik, tetapi serangan dan lompatan meriam menggunakan aturan varian, menambah taktik baru bagi yang suka tantangan.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules: "Bergiliran menaruh batu hitam-putih di titik pertemuan papan 19×19, siapa yang menguasai wilayah lebih luas akan menang; batu yang terkepung penuh tanpa napas akan ditangkap.",
  },
  gomoku: { name: "Gomoku", subtitle: "17×17", rules: "Bergiliran menaruh batu, siapa yang lebih dulu menyusun lima berturut-turut secara horizontal, vertikal, atau diagonal akan menang." },
  othello: {
    name: "Othello",
    subtitle: "Standar",
    rules: "Bergiliran menaruh keping, keping lawan yang terjepit akan berbalik menjadi warna Anda. Di akhir permainan, siapa yang keping lebih banyak akan menang.",
  },
  mahjong: {
    name: "Mahjong Cina",
    subtitle: "AI Solo (3 Komputer)",
    rules: "Bermain bersama tiga lawan komputer, bergiliran mengambil dan membuang kartu, bisa Chow／Pong／Kong kartu buangan pemain lain. Siapa yang lebih dulu menyelesaikan kombinasi menang sah akan menang.",
  },
  luzhanqi: {
    name: "Catur Angkatan Darat",
    subtitle: "AI Solo／2 Pemain",
    rules: "Pangkat bidak kedua pihak dirahasiakan, lawan hanya melihat bagian belakang. Pertarungan ditentukan oleh pangkat; siapa yang lebih dulu merebut bendera lawan atau membuat lawan tak bisa bergerak akan menang.",
  },
  checkers: {
    name: "Dam",
    subtitle: "Standar",
    rules: "Bergiliran menggerakkan bidak secara diagonal, bisa melompati dan memakan bidak lawan. Memakan semua bidak lawan atau membuat lawan tak bisa bergerak akan menang.",
  },
  tictactoe: {
    name: "Tic-Tac-Toe",
    subtitle: "Format Perbesar 3×3",
    rules: "Bergiliran menaruh simbol, siapa yang lebih dulu menyusun tiga berturut-turut secara horizontal, vertikal, atau diagonal akan menang.",
  },
}

const ms: GameTable = {
  xiangqi: {
    name: "Catur Cina",
    subtitle: "AI Solo／2 Pemain",
    rules:
      "Bergilir menggerakkan buah catur, sesiapa yang lebih dahulu memojokkan jeneral lawan hingga tidak boleh bergerak akan menang. Mengikut peraturan Xiangqi tradisional: Kereta bergerak lurus, Kuda bergerak bentuk L, Gajah bergerak menyerong di kawasan sendiri, Penasihat bergerak menyerong berhampiran istana, Askar boleh bergerak ke tepi selepas menyeberangi sungai.",
  },
  "darkchess-classic": {
    name: "Catur Gelap (Klasik)",
    subtitle: "AI Solo／2 Pemain",
    rules: "Semua buah diletakkan terbalik, selepas dibuka akan makan mengikut susunan pangkat tradisional. Memakan semua buah lawan atau menjadikan lawan tidak boleh bergerak akan menang.",
  },
  "darkchess-variant": {
    name: "Catur Gelap (Varian)",
    subtitle: "AI Solo／2 Pemain",
    rules: "Sama seperti versi klasik, tetapi serangan dan lompatan meriam menggunakan peraturan varian, menambah taktik baharu.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules: "Bergilir meletakkan batu hitam-putih pada titik silang papan 19×19, sesiapa yang menguasai kawasan lebih luas akan menang; batu yang terkepung sepenuhnya tanpa nafas akan ditawan.",
  },
  gomoku: { name: "Gomoku", subtitle: "17×17", rules: "Bergilir meletakkan batu, sesiapa yang lebih dahulu menyusun lima secara mendatar, menegak, atau serong akan menang." },
  othello: {
    name: "Othello",
    subtitle: "Standard",
    rules: "Bergilir meletakkan cakera, cakera lawan yang terapit akan bertukar menjadi warna anda. Di penghujung permainan, sesiapa yang mempunyai cakera lebih banyak akan menang.",
  },
  mahjong: {
    name: "Mahjong Cina",
    subtitle: "AI Solo (3 Komputer)",
    rules: "Bermain bersama tiga lawan komputer, bergilir mengambil dan membuang jubin, boleh Chow／Pong／Kong jubin buangan pemain lain. Sesiapa yang lebih dahulu menyempurnakan kombinasi menang sah akan menang.",
  },
  luzhanqi: {
    name: "Catur Tentera Darat",
    subtitle: "AI Solo／2 Pemain",
    rules: "Pangkat buah kedua-dua pihak dirahsiakan, lawan hanya nampak bahagian belakang. Pertempuran ditentukan oleh pangkat; sesiapa yang merampas bendera lawan atau menjadikan lawan tidak boleh bergerak akan menang.",
  },
  checkers: {
    name: "Dam",
    subtitle: "Standard",
    rules: "Bergilir menggerakkan buah secara menyerong, boleh melompat untuk menawan buah lawan. Menawan semua buah lawan atau menjadikan lawan tidak boleh bergerak akan menang.",
  },
  tictactoe: {
    name: "Tic-Tac-Toe",
    subtitle: "Format Diperbesar 3×3",
    rules: "Bergilir meletakkan simbol, sesiapa yang lebih dahulu menyusun tiga secara mendatar, menegak, atau serong akan menang.",
  },
}

const fil: GameTable = {
  xiangqi: {
    name: "Chinese Chess",
    subtitle: "AI Solo／2 Manlalaro",
    rules:
      "Palitan ang paggalaw ng piraso; ang unang makapagkorner sa heneral ng kalaban na walang malayuang lugar ang mananalo. Sumusunod sa tradisyonal na patakaran ng Xiangqi: dumadaloy ang Chariot, gumagalaw ang Horse sa hugis L, ang Elephant sa diagonal sa sariling bahagi, ang Guard sa diagonal malapit sa palasyo, at ang Soldier ay makakagalaw pasalungat pagkatapos tumawid sa ilog.",
  },
  "darkchess-classic": {
    name: "Dark Chess (Klasiko)",
    subtitle: "AI Solo／2 Manlalaro",
    rules: "Lahat ng piraso ay nakadapa; kapag na-flip, kumakain ayon sa tradisyonal na ranggo. Ang unang kumain ng lahat ng piraso ng kalaban o hindi na sila makagalaw ay mananalo.",
  },
  "darkchess-variant": {
    name: "Dark Chess (Variant)",
    subtitle: "AI Solo／2 Manlalaro",
    rules: "Kapareho ng Klasiko ngunit may pagbabago sa pag-atake at jump-capture ng kanyon, may dagdag na taktika para sa mas mapaghamong laro.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules: "Palitan ang paglalagay ng itim at puting bato sa mga interseksyon ng 19×19 board; ang mas maraming teritoryo ang mananalo. Ang mga bato na napalibutan nang walang hininga ay makukuha.",
  },
  gomoku: { name: "Gomoku", subtitle: "17×17", rules: "Palitan ang paglalagay ng bato; ang unang makapagsama ng lima nang tuluy-tuloy nang pahalang, patayo, o pahilis ang mananalo." },
  othello: {
    name: "Othello",
    subtitle: "Standard",
    rules: "Palitan ang paglalagay ng disc; ang mga disc ng kalaban na na-sandwich ay babaligtad sa iyong kulay. Sa dulo, ang may mas maraming disc ang mananalo.",
  },
  mahjong: {
    name: "Chinese Mahjong",
    subtitle: "AI Solo (3 Computer)",
    rules: "Maglaro kasama ang tatlong computer na kalaban, palitan ang pagkuha at pagtapon ng tile, maaaring Chow／Pong／Kong ng itinapon ng iba. Ang unang makumpleto ang balidong winning hand ang mananalo.",
  },
  luzhanqi: {
    name: "Luzhanqi (Army Chess)",
    subtitle: "AI Solo／2 Manlalaro",
    rules: "Nakatago ang ranggo ng mga piraso ng bawat panig; nakikita lang ng kalaban ang likod. Ang ranggo ang nagpasya sa labanan; ang unang makuha ang bandila ng kalaban o walang magalaw ang mananalo.",
  },
  checkers: {
    name: "Checkers",
    subtitle: "Standard",
    rules: "Palitan ang diagonal na paggalaw ng piraso; maaaring lumundag para kunin ang piraso ng kalaban. Ang unang makuha ang lahat ng piraso ng kalaban ang mananalo.",
  },
  tictactoe: {
    name: "Tic-Tac-Toe",
    subtitle: "Pinalaking 3×3",
    rules: "Palitan ang paglalagay ng simbolo; ang unang makapagsama ng tatlo nang tuluy-tuloy nang pahalang, patayo, o pahilis ang mananalo.",
  },
}

const es: GameTable = {
  xiangqi: {
    name: "Ajedrez Chino",
    subtitle: "IA Individual／2 Jugadores",
    rules:
      "Muevan las piezas por turnos; el primero en acorralar al general contrario sin escapatoria gana. Sigue las reglas tradicionales del Xiangqi: la carroza avanza recto, el caballo en forma de L, el elefante en diagonal dentro de su territorio, el consejero en diagonal junto al palacio, y el soldado puede moverse lateralmente tras cruzar el río.",
  },
  "darkchess-classic": {
    name: "Ajedrez Oculto (Clásico)",
    subtitle: "IA Individual／2 Jugadores",
    rules: "Todas las piezas empiezan boca abajo. Al voltearlas se capturan según el orden jerárquico tradicional. Capturar todas las piezas rivales o dejarlas sin movimientos gana.",
  },
  "darkchess-variant": {
    name: "Ajedrez Oculto (Variante)",
    subtitle: "IA Individual／2 Jugadores",
    rules: "Igual que el clásico, pero el ataque y captura por salto del cañón siguen reglas variantes, añadiendo nuevas tácticas.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules: "Coloquen piedras negras y blancas por turnos en las intersecciones de un tablero de 19×19; quien controle más territorio gana. Las piedras totalmente rodeadas sin libertades son capturadas.",
  },
  gomoku: { name: "Gomoku", subtitle: "17×17", rules: "Coloquen piedras por turnos; el primero en alinear cinco en fila horizontal, vertical o diagonal gana." },
  othello: {
    name: "Otelo",
    subtitle: "Estándar",
    rules: "Coloquen fichas por turnos; las fichas rivales atrapadas entre las suyas se voltean a su color. Al final, quien tenga más fichas gana.",
  },
  mahjong: {
    name: "Mahjong Chino",
    subtitle: "IA Individual (3 Computadoras)",
    rules: "Juega en una mesa con tres oponentes controlados por IA, roba y descarta fichas por turnos, puedes reclamar descartes con Chow／Pong／Kong. El primero en completar una mano válida gana.",
  },
  luzhanqi: {
    name: "Luzhanqi (Ajedrez Militar)",
    subtitle: "IA Individual／2 Jugadores",
    rules: "El rango de las piezas de ambos bandos es secreto; el rival solo ve el reverso. Las batallas se deciden por rango; el primero en capturar la bandera enemiga o dejarlo sin movimientos gana.",
  },
  checkers: {
    name: "Damas",
    subtitle: "Estándar",
    rules: "Muevan piezas en diagonal por turnos; pueden saltar para capturar piezas rivales. Capturar todas las piezas rivales o dejarlas sin movimientos gana.",
  },
  tictactoe: {
    name: "Tres en Raya",
    subtitle: "Formato Ampliado 3×3",
    rules: "Coloquen símbolos por turnos; el primero en alinear tres en fila horizontal, vertical o diagonal gana.",
  },
}

const pt: GameTable = {
  xiangqi: {
    name: "Xadrez Chinês",
    subtitle: "IA Solo／2 Jogadores",
    rules:
      "Movam as peças por turnos; o primeiro a encurralar o general adversário sem escapatória vence. Segue as regras tradicionais do Xiangqi: a carruagem move-se em linha reta, o cavalo em L, o elefante na diagonal dentro do seu território, o conselheiro na diagonal junto ao palácio, e o soldado pode mover-se lateralmente após cruzar o rio.",
  },
  "darkchess-classic": {
    name: "Xadrez Oculto (Clássico)",
    subtitle: "IA Solo／2 Jogadores",
    rules: "Todas as peças começam viradas para baixo. Ao revelá-las, capturam-se pela ordem hierárquica tradicional. Capturar todas as peças do adversário ou deixá-lo sem jogadas vence.",
  },
  "darkchess-variant": {
    name: "Xadrez Oculto (Variante)",
    subtitle: "IA Solo／2 Jogadores",
    rules: "Igual ao clássico, mas o ataque e a captura por salto do canhão seguem regras variantes, adicionando novas táticas.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules: "Coloquem pedras pretas e brancas por turnos nas interseções de um tabuleiro 19×19; quem controlar mais território vence. Pedras totalmente rodeadas sem liberdades são capturadas.",
  },
  gomoku: { name: "Gomoku", subtitle: "17×17", rules: "Coloquem pedras por turnos; o primeiro a alinhar cinco em linha horizontal, vertical ou diagonal vence." },
  othello: {
    name: "Otelo",
    subtitle: "Padrão",
    rules: "Coloquem peças por turnos; peças do adversário encaixadas entre as suas viram para sua cor. No final, quem tiver mais peças vence.",
  },
  mahjong: {
    name: "Mahjong Chinês",
    subtitle: "IA Solo (3 Computadores)",
    rules: "Jogue numa mesa com três oponentes controlados por IA, compre e descarte peças por turnos, pode reivindicar descartes com Chow／Pong／Kong. O primeiro a completar uma mão válida vence.",
  },
  luzhanqi: {
    name: "Luzhanqi (Xadrez Militar)",
    subtitle: "IA Solo／2 Jogadores",
    rules: "A patente das peças de ambos os lados é secreta; o adversário só vê o verso. As batalhas são decididas pela patente; o primeiro a capturar a bandeira inimiga ou deixá-lo sem jogadas vence.",
  },
  checkers: {
    name: "Damas",
    subtitle: "Padrão",
    rules: "Movam peças na diagonal por turnos; podem saltar para capturar peças do adversário. Capturar todas as peças do adversário ou deixá-lo sem jogadas vence.",
  },
  tictactoe: {
    name: "Jogo do Galo",
    subtitle: "Formato Ampliado 3×3",
    rules: "Coloquem símbolos por turnos; o primeiro a alinhar três em linha horizontal, vertical ou diagonal vence.",
  },
}

const fr: GameTable = {
  xiangqi: {
    name: "Échecs Chinois",
    subtitle: "IA Solo／2 Joueurs",
    rules:
      "Déplacez les pièces à tour de rôle ; le premier à acculer le général adverse sans échappatoire gagne. Suit les règles traditionnelles du Xiangqi : le chariot avance tout droit, le cheval en L, l'éléphant en diagonale dans son propre camp, le conseiller en diagonale près du palais, et le soldat peut se déplacer latéralement après avoir traversé la rivière.",
  },
  "darkchess-classic": {
    name: "Échecs Cachés (Classique)",
    subtitle: "IA Solo／2 Joueurs",
    rules: "Toutes les pièces commencent face cachée. En les révélant, on capture selon l'ordre hiérarchique traditionnel. Capturer toutes les pièces adverses ou les priver de mouvement fait gagner.",
  },
  "darkchess-variant": {
    name: "Échecs Cachés (Variante)",
    subtitle: "IA Solo／2 Joueurs",
    rules: "Identique à la version classique, mais l'attaque et la capture par saut du canon suivent des règles variantes, ajoutant de nouvelles tactiques.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules: "Placez des pierres noires et blanches à tour de rôle aux intersections d'un plateau 19×19 ; celui qui contrôle le plus de territoire gagne. Les pierres totalement encerclées sans liberté sont capturées.",
  },
  gomoku: { name: "Gomoku", subtitle: "17×17", rules: "Placez des pierres à tour de rôle ; le premier à aligner cinq pierres horizontalement, verticalement ou en diagonale gagne." },
  othello: {
    name: "Othello",
    subtitle: "Standard",
    rules: "Placez des pions à tour de rôle ; les pions adverses encadrés se retournent à votre couleur. À la fin, celui qui a le plus de pions gagne.",
  },
  mahjong: {
    name: "Mahjong Chinois",
    subtitle: "IA Solo (3 Ordinateurs)",
    rules: "Jouez à une table avec trois adversaires contrôlés par l'IA, piochez et défaussez des tuiles à tour de rôle, réclamez les défausses avec Chow／Pong／Kong. Le premier à compléter une main gagnante valide gagne.",
  },
  luzhanqi: {
    name: "Luzhanqi (Échecs Militaires)",
    subtitle: "IA Solo／2 Joueurs",
    rules: "Le rang des pièces de chaque camp est secret ; l'adversaire ne voit que le dos. Les batailles se règlent par rang ; le premier à capturer le drapeau ennemi ou à le priver de mouvement gagne.",
  },
  checkers: {
    name: "Dames",
    subtitle: "Standard",
    rules: "Déplacez les pièces en diagonale à tour de rôle ; sautez pour capturer les pièces adverses. Capturer toutes les pièces adverses ou les priver de mouvement fait gagner.",
  },
  tictactoe: {
    name: "Morpion",
    subtitle: "Format Agrandi 3×3",
    rules: "Placez des symboles à tour de rôle ; le premier à aligner trois symboles horizontalement, verticalement ou en diagonale gagne.",
  },
}

const de: GameTable = {
  xiangqi: {
    name: "Chinesisches Schach",
    subtitle: "KI Solo／2 Spieler",
    rules:
      "Bewegt abwechselnd Figuren; wer den gegnerischen General zuerst in die Falle treibt, gewinnt. Folgt den traditionellen Xiangqi-Regeln: Wagen zieht geradeaus, Pferd im L, Elefant diagonal im eigenen Bereich, Berater diagonal nahe dem Palast, Soldat darf nach Überqueren des Flusses seitwärts ziehen.",
  },
  "darkchess-classic": {
    name: "Verdecktes Schach (Klassisch)",
    subtitle: "KI Solo／2 Spieler",
    rules: "Alle Figuren beginnen verdeckt. Nach dem Umdrehen werden Figuren nach traditioneller Rangordnung geschlagen. Alle gegnerischen Figuren zu schlagen oder den Gegner zugunfähig zu machen gewinnt.",
  },
  "darkchess-variant": {
    name: "Verdecktes Schach (Variante)",
    subtitle: "KI Solo／2 Spieler",
    rules: "Wie die klassische Version, aber Kanonenangriff und Sprungschlag folgen Variantenregeln, was neue Taktiken ermöglicht.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules: "Setzt abwechselnd schwarze und weiße Steine auf die Kreuzungen eines 19×19-Bretts; wer mehr Gebiet kontrolliert, gewinnt. Vollständig umschlossene Steine ohne Freiheiten werden gefangen.",
  },
  gomoku: { name: "Gomoku", subtitle: "17×17", rules: "Setzt abwechselnd Steine; wer als Erster fünf in einer Reihe verbindet, gewinnt." },
  othello: {
    name: "Othello",
    subtitle: "Standard",
    rules: "Setzt abwechselnd Steine; eingeschlossene gegnerische Steine werden auf Ihre Farbe gedreht. Am Ende gewinnt, wer mehr Steine hat.",
  },
  mahjong: {
    name: "Chinesisches Mahjong",
    subtitle: "KI Solo (3 Computer)",
    rules: "Spielt an einem Tisch mit drei Computergegnern, zieht und legt abwechselnd Steine ab, könnt abgelegte Steine mit Chow／Pong／Kong beanspruchen. Wer zuerst eine gültige Gewinnhand vervollständigt, gewinnt.",
  },
  luzhanqi: {
    name: "Luzhanqi (Militärschach)",
    subtitle: "KI Solo／2 Spieler",
    rules: "Der Rang der Figuren beider Seiten ist geheim; der Gegner sieht nur die Rückseite. Kämpfe werden nach Rang entschieden; wer zuerst die feindliche Flagge erobert oder den Gegner zugunfähig macht, gewinnt.",
  },
  checkers: {
    name: "Dame",
    subtitle: "Standard",
    rules: "Bewegt Figuren abwechselnd diagonal; könnt über gegnerische Figuren springen, um sie zu schlagen. Alle gegnerischen Figuren zu schlagen oder den Gegner zugunfähig zu machen gewinnt.",
  },
  tictactoe: {
    name: "Tic-Tac-Toe",
    subtitle: "Vergrößertes 3×3-Format",
    rules: "Setzt abwechselnd Symbole; wer als Erster drei in einer Reihe verbindet, gewinnt.",
  },
}

const it: GameTable = {
  xiangqi: {
    name: "Scacchi Cinesi",
    subtitle: "IA Solo／2 Giocatori",
    rules:
      "Muovete i pezzi a turno; il primo che metteinscacco matto il generale avversario senza via di fuga vince. Segue le regole tradizionali dello Xiangqi: il carro va dritto, il cavallo a L, l'elefante in diagonale nel proprio territorio, il consigliere in diagonale vicino al palazzo, il soldato può muoversi lateralmente dopo aver attraversato il fiume.",
  },
  "darkchess-classic": {
    name: "Scacchi Nascosti (Classico)",
    subtitle: "IA Solo／2 Giocatori",
    rules: "Tutti i pezzi iniziano coperti. Scoprendoli si catturano secondo l'ordine tradizionale dei ranghi. Catturare tutti i pezzi avversari o lasciarlo senza mosse fa vincere.",
  },
  "darkchess-variant": {
    name: "Scacchi Nascosti (Variante)",
    subtitle: "IA Solo／2 Giocatori",
    rules: "Come la versione classica, ma l'attacco e la cattura a salto del cannone seguono regole variante, aggiungendo nuove tattiche.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules: "Posizionate pietre nere e bianche a turno sulle intersezioni di una griglia 19×19; chi controlla più territorio vince. Le pietre completamente circondate senza libertà vengono capturate.",
  },
  gomoku: { name: "Gomoku", subtitle: "17×17", rules: "Posizionate pietre a turno; il primo che allinea cinque pietre in orizzontale, verticale o diagonale vince." },
  othello: {
    name: "Othello",
    subtitle: "Standard",
    rules: "Posizionate pedine a turno; le pedine avversarie intrappolate si girano nel vostro colore. Alla fine chi ha più pedine vince.",
  },
  mahjong: {
    name: "Mahjong Cinese",
    subtitle: "IA Solo (3 Computer)",
    rules: "Giocate a un tavolo con tre avversari controllati dal computer, pescate e scartate tessere a turno, potete rivendicare gli scarti con Chow／Pong／Kong. Chi completa prima una mano vincente valida vince.",
  },
  luzhanqi: {
    name: "Luzhanqi (Scacchi Militari)",
    subtitle: "IA Solo／2 Giocatori",
    rules: "Il rango dei pezzi di entrambe le parti è segreto; l'avversario vede solo il retro. Le battaglie si decidono per rango; chi cattura prima la bandiera nemica o lascia l'avversario senza mosse vince.",
  },
  checkers: {
    name: "Dama",
    subtitle: "Standard",
    rules: "Muovete i pezzi in diagonale a turno; potete saltare per catturare i pezzi avversari. Catturare tutti i pezzi avversari o lasciarlo senza mosse fa vincere.",
  },
  tictactoe: {
    name: "Tris",
    subtitle: "Formato Ampliato 3×3",
    rules: "Posizionate simboli a turno; il primo che allinea tre simboli in orizzontale, verticale o diagonale vince.",
  },
}

const ru: GameTable = {
  xiangqi: {
    name: "Китайские шахматы",
    subtitle: "ИИ Соло／2 Игрока",
    rules:
      "По очереди двигайте фигуры; кто первым поставит генерала противника в безвыходное положение, победит. Следует традиционным правилам Сянци: колесница ходит прямо, конь буквой Г, слон по диагонали на своей территории, советник по диагонали возле дворца, солдат может ходить в сторону после пересечения реки.",
  },
  "darkchess-classic": {
    name: "Тёмные шахматы (Классика)",
    subtitle: "ИИ Соло／2 Игрока",
    rules: "Все фигуры начинаются лицом вниз. После открытия фигуры бьют по традиционному порядку рангов. Победа — съесть все фигуры противника или лишить его ходов.",
  },
  "darkchess-variant": {
    name: "Тёмные шахматы (Вариант)",
    subtitle: "ИИ Соло／2 Игрока",
    rules: "Как классика, но атака и прыжковое взятие пушки следуют вариантным правилам, добавляя новую тактику.",
  },
  go: {
    name: "Го",
    subtitle: "19×19",
    rules: "По очереди ставьте чёрные и белые камни на пересечения доски 19×19; кто контролирует больше территории, побеждает. Камни, полностью окружённые без «дыхания», захватываются.",
  },
  gomoku: { name: "Гомоку", subtitle: "17×17", rules: "По очереди ставьте камни; кто первым выстроит пять в ряд по горизонтали, вертикали или диагонали, побеждает." },
  othello: {
    name: "Отелло",
    subtitle: "Стандарт",
    rules: "По очереди ставьте фишки; фишки противника, зажатые между вашими, переворачиваются в ваш цвет. В конце победит тот, у кого больше фишек.",
  },
  mahjong: {
    name: "Китайский маджонг",
    subtitle: "ИИ Соло (3 компьютера)",
    rules: "Играйте за столом с тремя компьютерными соперниками, по очереди берите и сбрасывайте фишки, можно забирать сбросы через Чоу／Пон／Кон. Кто первым соберёт правильную выигрышную комбинацию, победит.",
  },
  luzhanqi: {
    name: "Лучжанци (Военные шахматы)",
    subtitle: "ИИ Соло／2 Игрока",
    rules: "Ранг фигур обеих сторон скрыт; противник видит только заднюю сторону. Битвы решаются по рангу; кто первым захватит флаг противника или лишит его ходов, победит.",
  },
  checkers: {
    name: "Шашки",
    subtitle: "Стандарт",
    rules: "По очереди двигайте фигуры по диагонали; можно перескакивать, чтобы съесть фигуры противника. Победа — съесть все фигуры противника или лишить его ходов.",
  },
  tictactoe: {
    name: "Крестики-нолики",
    subtitle: "Увеличенный формат 3×3",
    rules: "По очереди ставьте символы; кто первым выстроит три в ряд по горизонтали, вертикали или диагонали, победит.",
  },
}

const ar: GameTable = {
  xiangqi: {
    name: "الشطرنج الصيني",
    subtitle: "ذكاء اصطناعي فردي／لاعبان",
    rules:
      "بالتناوب حرّك القطع؛ من يحاصر جنرال الخصم أولاً بلا مخرج يفوز. يتبع قواعد شيانغتشي التقليدية: العربة تتحرك في خط مستقيم، الحصان بشكل حرف L، الفيل قطريًا داخل منطقته، المستشار قطريًا قرب القصر، والجندي يمكنه التحرك جانبيًا بعد عبور النهر.",
  },
  "darkchess-classic": {
    name: "الشطرنج المخفي (كلاسيكي)",
    subtitle: "ذكاء اصطناعي فردي／لاعبان",
    rules: "تبدأ جميع القطع مقلوبة، وعند كشفها تُؤكل حسب ترتيب الرتب التقليدي. الفوز يكون بأكل جميع قطع الخصم أو تركه بلا حركة.",
  },
  "darkchess-variant": {
    name: "الشطرنج المخفي (متغير)",
    subtitle: "ذكاء اصطناعي فردي／لاعبان",
    rules: "مثل النسخة الكلاسيكية، لكن هجوم وقفز المدفع يتبعان قواعد متغيرة، مما يضيف تكتيكات جديدة.",
  },
  go: {
    name: "جو (Go)",
    subtitle: "19×19",
    rules: "بالتناوب ضع حجارة سوداء وبيضاء عند تقاطعات لوحة 19×19؛ من يسيطر على مساحة أكبر يفوز. الحجارة المحاصرة بالكامل بلا أنفاس تُؤسر.",
  },
  gomoku: { name: "جوموكو", subtitle: "17×17", rules: "بالتناوب ضع الحجارة؛ من يصل أولاً إلى خمسة متتالية أفقيًا أو عموديًا أو قطريًا يفوز." },
  othello: {
    name: "أوثيلو",
    subtitle: "قياسي",
    rules: "بالتناوب ضع القطع؛ قطع الخصم المحاصرة بين قطعك تنقلب إلى لونك. في النهاية من يملك أكثر قطع يفوز.",
  },
  mahjong: {
    name: "ماهجونج الصيني",
    subtitle: "ذكاء اصطناعي فردي (3 حواسيب)",
    rules: "اجلس على طاولة مع ثلاثة خصوم حاسوبيين، اسحب وتخلّ من القطع بالتناوب، يمكنك المطالبة بقطع مرمية عبر تشاو／بونج／كونج. من يكمل يدًا فائزة صحيحة أولاً يفوز.",
  },
  luzhanqi: {
    name: "لوجانتشي (شطرنج الجيش)",
    subtitle: "ذكاء اصطناعي فردي／لاعبان",
    rules: "رتبة قطع كل جانب سرية، والخصم يرى فقط الجانب الخلفي. تُحسم المعارك بالرتبة؛ من يستولي على راية الخصم أو يتركه بلا حركة أولاً يفوز.",
  },
  checkers: {
    name: "الداما",
    subtitle: "قياسي",
    rules: "بالتناوب حرّك القطع قطريًا؛ يمكنك القفز لأكل قطع الخصم. الفوز يكون بأكل جميع قطع الخصم أو تركه بلا حركة.",
  },
  tictactoe: {
    name: "إكس أو",
    subtitle: "نسخة موسعة 3×3",
    rules: "بالتناوب ضع الرموز؛ من يصل أولاً إلى ثلاثة متتالية أفقيًا أو عموديًا أو قطريًا يفوز.",
  },
}

const hi: GameTable = {
  xiangqi: {
    name: "चीनी शतरंज",
    subtitle: "एआई एकल／2 खिलाड़ी",
    rules:
      "बारी-बारी से मोहरे चलाएं; जो पहले प्रतिद्वंद्वी के जनरल को बिना रास्ते के फंसा दे वह जीतता है। पारंपरिक शियांगकी नियमों के अनुसार: रथ सीधा चलता है, घोड़ा L आकार में, हाथी अपने क्षेत्र में तिरछा, सलाहकार महल के पास तिरछा, और सैनिक नदी पार करने के बाद बगल में चल सकता है।",
  },
  "darkchess-classic": {
    name: "डार्क चेस (क्लासिक)",
    subtitle: "एआई एकल／2 खिलाड़ी",
    rules: "सभी मोहरे उलटे रखे जाते हैं; पलटने के बाद पारंपरिक क्रम में खाए जाते हैं। प्रतिद्वंद्वी के सभी मोहरे खाकर या उसे चाल-रहित बनाकर जीत होती है।",
  },
  "darkchess-variant": {
    name: "डार्क चेस (वेरिएंट)",
    subtitle: "एआई एकल／2 खिलाड़ी",
    rules: "क्लासिक जैसा ही, पर तोप का आक्रमण व कूद-कर खाना वेरिएंट नियमों के अनुसार होता है, जिससे नई रणनीतियाँ मिलती हैं।",
  },
  go: {
    name: "गो",
    subtitle: "19×19",
    rules: "बारी-बारी से 19×19 बोर्ड के चौराहों पर काले-सफेद पत्थर रखें; अधिक क्षेत्र घेरने वाला जीतता है। पूरी तरह घिरे व सांस-रहित पत्थर पकड़े जाते हैं।",
  },
  gomoku: { name: "गोमोकू", subtitle: "17×17", rules: "बारी-बारी से पत्थर रखें; क्षैतिज, लंबवत या तिरछी दिशा में पहले पांच लगातार बनाने वाला जीतता है।" },
  othello: {
    name: "ओथेलो",
    subtitle: "स्टैंडर्ड",
    rules: "बारी-बारी से टुकड़े रखें; बीच में फंसे प्रतिद्वंद्वी के टुकड़े आपके रंग में बदल जाते हैं। अंत में अधिक टुकड़े वाला जीतता है।",
  },
  mahjong: {
    name: "चीनी माहजोंग",
    subtitle: "एआई एकल (3 कंप्यूटर)",
    rules: "तीन कंप्यूटर प्रतिद्वंद्वियों के साथ खेलें, बारी-बारी से टाइल उठाएं व फेंकें, चाओ／पोंग／कोंग से दूसरों की फेंकी टाइल ले सकते हैं। पहले वैध विजयी हाथ पूरा करने वाला जीतता है।",
  },
  luzhanqi: {
    name: "लुज़ानकी (सेना शतरंज)",
    subtitle: "एआई एकल／2 खिलाड़ी",
    rules: "दोनों पक्षों के मोहरों की रैंक गुप्त रहती है; प्रतिद्वंद्वी केवल पीठ देखता है। लड़ाई रैंक से तय होती है; पहले दुश्मन का झंडा छीनने या उसे चाल-रहित बनाने वाला जीतता है।",
  },
  checkers: {
    name: "चेकर्स",
    subtitle: "स्टैंडर्ड",
    rules: "बारी-बारी से तिरछा मोहरे चलाएं; कूदकर प्रतिद्वंद्वी के मोहरे खा सकते हैं। सभी मोहरे खाकर या चाल-रहित बनाकर जीत होती है।",
  },
  tictactoe: {
    name: "टिक-टैक-टो",
    subtitle: "बड़ा 3×3 प्रारूप",
    rules: "बारी-बारी से चिन्ह रखें; क्षैतिज, लंबवत या तिरछी दिशा में पहले तीन लगातार बनाने वाला जीतता है।",
  },
}

const tr: GameTable = {
  xiangqi: {
    name: "Çin Satrancı",
    subtitle: "Yapay Zeka Solo／2 Oyuncu",
    rules:
      "Sırayla taş hareket ettirin; rakibin generalini önce çıkışsız köşeye sıkıştıran kazanır. Geleneksel Xiangqi kurallarına uyar: Araba düz gider, At L şeklinde, Fil kendi bölgesinde çapraz, Danışman saray yakınında çapraz, Asker nehri geçtikten sonra yana hareket edebilir.",
  },
  "darkchess-classic": {
    name: "Gizli Satranç (Klasik)",
    subtitle: "Yapay Zeka Solo／2 Oyuncu",
    rules: "Tüm taşlar ters başlar; açıldıktan sonra geleneksel rütbe sırasına göre yenir. Rakibin tüm taşlarını yemek veya onu hamlesiz bırakmak kazandırır.",
  },
  "darkchess-variant": {
    name: "Gizli Satranç (Varyant)",
    subtitle: "Yapay Zeka Solo／2 Oyuncu",
    rules: "Klasik ile aynıdır, ancak topun saldırı ve zıplayarak yeme şekli varyant kurallarına göredir, yeni taktikler ekler.",
  },
  go: {
    name: "Go",
    subtitle: "19×19",
    rules: "Sırayla 19×19 tahtanın kesişim noktalarına siyah-beyaz taş koyun; daha fazla alanı kontrol eden kazanır. Tamamen çevrili ve nefessiz taşlar ele geçirilir.",
  },
  gomoku: { name: "Gomoku", subtitle: "17×17", rules: "Sırayla taş koyun; yatay, dikey veya çapraz olarak önce beş taş dizen kazanır." },
  othello: {
    name: "Othello",
    subtitle: "Standart",
    rules: "Sırayla taş koyun; aranıza sıkışan rakip taşlar sizin renginize döner. Sonunda daha fazla taşı olan kazanır.",
  },
  mahjong: {
    name: "Çin Mahjong'u",
    subtitle: "Yapay Zeka Solo (3 Bilgisayar)",
    rules: "Üç bilgisayar rakibiyle masada oynayın, sırayla taş çekin ve atın, başkalarının attığı taşları Chow／Pong／Kong ile alabilirsiniz. Önce geçerli bir kazanan el tamamlayan kazanır.",
  },
  luzhanqi: {
    name: "Luzhanqi (Ordu Satrancı)",
    subtitle: "Yapay Zeka Solo／2 Oyuncu",
    rules: "Her iki tarafın taş rütbeleri gizlidir; rakip yalnızca arkayı görür. Savaşlar rütbeye göre kararlaştırılır; rakibin bayrağını önce alan veya onu hamlesiz bırakan kazanır.",
  },
  checkers: {
    name: "Dama",
    subtitle: "Standart",
    rules: "Sırayla taşları çapraz hareket ettirin; rakip taşları atlayıp yiyebilirsiniz. Rakibin tüm taşlarını yemek veya onu hamlesiz bırakmak kazandırır.",
  },
  tictactoe: {
    name: "XOX",
    subtitle: "Büyütülmüş 3×3 Format",
    rules: "Sırayla sembol koyun; yatay, dikey veya çapraz olarak önce üç sembol dizen kazanır.",
  },
}

const bn: GameTable = {
  xiangqi: {
    name: "চীনা দাবা",
    subtitle: "এআই একক／২ খেলোয়াড়",
    rules:
      "পালাক্রমে ঘুঁটি নাড়ুন; যে প্রথমে প্রতিপক্ষের জেনারেলকে কোণঠাসা করবে সে জয়ী হবে। ঐতিহ্যবাহী শিয়াংছি নিয়ম অনুসরণ করে: রথ সোজা চলে, ঘোড়া L আকারে, হাতি নিজের এলাকায় তির্যক, উপদেষ্টা রাজপ্রাসাদের কাছে তির্যক, সৈনিক নদী পার হওয়ার পর পাশে যেতে পারে।",
  },
  "darkchess-classic": {
    name: "ডার্ক চেস (ক্লাসিক)",
    subtitle: "এআই একক／২ খেলোয়াড়",
    rules: "সব ঘুঁটি উল্টো রাখা হয়; উল্টে দেখানোর পর ঐতিহ্যবাহী পদক্রম অনুযায়ী খাওয়া হয়। প্রতিপক্ষের সব ঘুঁটি খেয়ে ফেলা বা তাকে চাল-শূন্য করে দেওয়াই জয়।",
  },
  "darkchess-variant": {
    name: "ডার্ক চেস (ভ্যারিয়েন্ট)",
    subtitle: "এআই একক／২ খেলোয়াড়",
    rules: "ক্লাসিকের মতোই, তবে কামানের আক্রমণ ও লাফিয়ে খাওয়ার নিয়ম ভিন্ন, যা নতুন কৌশল যুক্ত করে।",
  },
  go: {
    name: "গো",
    subtitle: "১৯×১৯",
    rules: "পালাক্রমে ১৯×১৯ বোর্ডের সংযোগস্থলে কালো-সাদা পাথর রাখুন; যে বেশি এলাকা দখল করবে সে জয়ী। সম্পূর্ণ ঘেরাও হওয়া নিঃশ্বাসহীন পাথর ধরা পড়ে।",
  },
  gomoku: { name: "গোমোকু", subtitle: "১৭×১৭", rules: "পালাক্রমে পাথর রাখুন; আনুভূমিক, উলম্ব বা তির্যকভাবে প্রথমে পাঁচটি সাজানো খেলোয়াড় জয়ী।" },
  othello: {
    name: "অথেলো",
    subtitle: "স্ট্যান্ডার্ড",
    rules: "পালাক্রমে ঘুঁটি রাখুন; মাঝে আটকে পড়া প্রতিপক্ষের ঘুঁটি আপনার রঙে বদলে যায়। শেষে বেশি ঘুঁটি থাকা খেলোয়াড় জয়ী।",
  },
  mahjong: {
    name: "চীনা মাহজং",
    subtitle: "এআই একক (৩ কম্পিউটার)",
    rules: "তিন কম্পিউটার প্রতিপক্ষের সাথে খেলুন, পালাক্রমে টাইল তুলুন ও ফেলুন, অন্যের ফেলা টাইল চাও／পং／কং করে নিতে পারেন। প্রথমে বৈধ জয়ী হাত সম্পূর্ণ করা খেলোয়াড় জয়ী।",
  },
  luzhanqi: {
    name: "লুজানছি (সামরিক দাবা)",
    subtitle: "এআই একক／২ খেলোয়াড়",
    rules: "দুই পক্ষের ঘুঁটির পদমর্যাদা গোপন থাকে; প্রতিপক্ষ শুধু পেছনের দিক দেখে। যুদ্ধ পদমর্যাদা অনুযায়ী নির্ধারিত হয়; প্রথমে প্রতিপক্ষের পতাকা দখল বা তাকে চাল-শূন্য করা খেলোয়াড় জয়ী।",
  },
  checkers: {
    name: "চেকার্স",
    subtitle: "স্ট্যান্ডার্ড",
    rules: "পালাক্রমে তির্যকভাবে ঘুঁটি নাড়ুন; ঝাঁপ দিয়ে প্রতিপক্ষের ঘুঁটি খেতে পারেন। প্রতিপক্ষের সব ঘুঁটি খাওয়া বা তাকে চাল-শূন্য করাই জয়।",
  },
  tictactoe: {
    name: "টিক-ট্যাক-টো",
    subtitle: "বড় ৩×৩ ফরম্যাট",
    rules: "পালাক্রমে চিহ্ন রাখুন; আনুভূমিক, উলম্ব বা তির্যকভাবে প্রথমে তিনটি সাজানো খেলোয়াড় জয়ী।",
  },
}

export const PUZZLE_GAME_TEXT: Record<LangId, GameTable> = {
  "zh-TW": zhTW,
  "zh-CN": zhCN,
  en,
  ja,
  ko,
  vi,
  th,
  id,
  ms,
  fil,
  es,
  pt,
  fr,
  de,
  it,
  ru,
  ar,
  hi,
  tr,
  bn,
}

export const PUZZLE_COMMON_TEXT: Record<LangId, PuzzleCommonText> = {
  "zh-TW": {
    mahjongWall: "牌牆",
    mahjongTotalRounds: "總局數",
    mahjongWinCount: "胡牌次數",
    mahjongWinRate: "胡牌率",
    mahjongYourDiscards: "您的棄牌",
    mahjongEatPongKong: "吃・碰・槓",
    mahjongTingWinDraw: "聽・胡・摸牌",
    checkersKing: "王",
    comingSoonText: "這款遊戲正在陸續製作中，完成後會自動出現在這個格子裡，敬請期待！",
    backToLobby: "返回大廳",
    costToastTemplate: "本局已扣除 {cost} 遊戲幣",
  },
  "zh-CN": {
    mahjongWall: "牌墙",
    mahjongTotalRounds: "总局数",
    mahjongWinCount: "胡牌次数",
    mahjongWinRate: "胡牌率",
    mahjongYourDiscards: "您的弃牌",
    mahjongEatPongKong: "吃・碰・杠",
    mahjongTingWinDraw: "听・胡・摸牌",
    checkersKing: "王",
    comingSoonText: "这款游戏正在陆续制作中，完成后会自动出现在这个格子里，敬请期待！",
    backToLobby: "返回大厅",
    costToastTemplate: "本局已扣除 {cost} 游戏币",
  },
  en: {
    mahjongWall: "Wall",
    mahjongTotalRounds: "Total Rounds",
    mahjongWinCount: "Wins",
    mahjongWinRate: "Win Rate",
    mahjongYourDiscards: "Your Discards",
    mahjongEatPongKong: "Chow · Pong · Kong",
    mahjongTingWinDraw: "Ready · Win · Draw",
    checkersKing: "K",
    comingSoonText: "This game is being built and will appear here automatically once ready — stay tuned!",
    backToLobby: "Back to Lobby",
    costToastTemplate: "{cost} game coins deducted for this round",
  },
  ja: {
    mahjongWall: "牌山",
    mahjongTotalRounds: "総局数",
    mahjongWinCount: "和了回数",
    mahjongWinRate: "和了率",
    mahjongYourDiscards: "あなたの捨て牌",
    mahjongEatPongKong: "チー・ポン・カン",
    mahjongTingWinDraw: "聴牌・和了・ツモ",
    checkersKing: "王",
    comingSoonText: "このゲームは現在制作中です。完成すると自動的にこのマスに表示されます。お楽しみに！",
    backToLobby: "ロビーに戻る",
    costToastTemplate: "今回のゲームで{cost}ゲームコインを消費しました",
  },
  ko: {
    mahjongWall: "패산",
    mahjongTotalRounds: "총 판수",
    mahjongWinCount: "승리 횟수",
    mahjongWinRate: "승률",
    mahjongYourDiscards: "나의 버린 패",
    mahjongEatPongKong: "치・펑・깡",
    mahjongTingWinDraw: "텐・후・쯔모",
    checkersKing: "킹",
    comingSoonText: "이 게임은 현재 제작 중이며 완성되면 이 칸에 자동으로 표시됩니다. 기대해 주세요!",
    backToLobby: "로비로 돌아가기",
    costToastTemplate: "이번 게임에서 게임 코인 {cost}개가 차감되었습니다",
  },
  vi: {
    mahjongWall: "Tường bài",
    mahjongTotalRounds: "Tổng số vòng",
    mahjongWinCount: "Số lần thắng",
    mahjongWinRate: "Tỷ lệ thắng",
    mahjongYourDiscards: "Bài bạn đã đánh",
    mahjongEatPongKong: "Ăn・Bắt Cạ・Bắt Khàn",
    mahjongTingWinDraw: "Chờ・Thắng・Rút bài",
    checkersKing: "Vua",
    comingSoonText: "Trò chơi này đang được phát triển và sẽ tự động xuất hiện tại đây khi hoàn tất, hãy chờ đón!",
    backToLobby: "Về Sảnh Game",
    costToastTemplate: "Đã trừ {cost} xu trò chơi cho lượt này",
  },
  th: {
    mahjongWall: "กำแพงไพ่",
    mahjongTotalRounds: "จำนวนรอบทั้งหมด",
    mahjongWinCount: "จำนวนครั้งที่ชนะ",
    mahjongWinRate: "อัตราการชนะ",
    mahjongYourDiscards: "ไพ่ที่คุณทิ้ง",
    mahjongEatPongKong: "กิน・ป๊อง・กง",
    mahjongTingWinDraw: "เตี้ยม・ฮู・จั่ว",
    checkersKing: "คิง",
    comingSoonText: "เกมนี้กำลังอยู่ในระหว่างการพัฒนา เมื่อเสร็จแล้วจะปรากฏที่ช่องนี้โดยอัตโนมัติ โปรดติดตาม!",
    backToLobby: "กลับสู่ห้องโถงเกม",
    costToastTemplate: "หักเหรียญเกม {cost} เหรียญสำหรับรอบนี้",
  },
  id: {
    mahjongWall: "Tembok Kartu",
    mahjongTotalRounds: "Total Ronde",
    mahjongWinCount: "Jumlah Menang",
    mahjongWinRate: "Tingkat Menang",
    mahjongYourDiscards: "Kartu Buangan Anda",
    mahjongEatPongKong: "Chow・Pong・Kong",
    mahjongTingWinDraw: "Siap・Menang・Ambil",
    checkersKing: "Raja",
    comingSoonText: "Game ini masih dalam pengembangan dan akan otomatis muncul di sini setelah selesai. Nantikan!",
    backToLobby: "Kembali ke Lobi",
    costToastTemplate: "{cost} koin permainan telah dipotong untuk ronde ini",
  },
  ms: {
    mahjongWall: "Dinding Jubin",
    mahjongTotalRounds: "Jumlah Pusingan",
    mahjongWinCount: "Bilangan Menang",
    mahjongWinRate: "Kadar Menang",
    mahjongYourDiscards: "Jubin Buangan Anda",
    mahjongEatPongKong: "Chow・Pong・Kong",
    mahjongTingWinDraw: "Sedia・Menang・Ambil",
    checkersKing: "Raja",
    comingSoonText: "Permainan ini sedang dibangunkan dan akan muncul secara automatik di sini apabila siap. Nantikan!",
    backToLobby: "Kembali ke Lobi",
    costToastTemplate: "{cost} syiling permainan telah ditolak untuk pusingan ini",
  },
  fil: {
    mahjongWall: "Dingding ng Tile",
    mahjongTotalRounds: "Kabuuang Round",
    mahjongWinCount: "Bilang ng Panalo",
    mahjongWinRate: "Win Rate",
    mahjongYourDiscards: "Mga Itinapon Mong Tile",
    mahjongEatPongKong: "Chow・Pong・Kong",
    mahjongTingWinDraw: "Ready・Panalo・Kuha",
    checkersKing: "Hari",
    comingSoonText: "Ang larong ito ay kasalukuyang ginagawa at lalabas dito nang otomatiko kapag tapos na. Manatiling tuned!",
    backToLobby: "Bumalik sa Lobby",
    costToastTemplate: "{cost} game coins ang naibawas para sa round na ito",
  },
  es: {
    mahjongWall: "Muro de Fichas",
    mahjongTotalRounds: "Rondas Totales",
    mahjongWinCount: "Victorias",
    mahjongWinRate: "Tasa de Victoria",
    mahjongYourDiscards: "Tus Descartes",
    mahjongEatPongKong: "Chow・Pong・Kong",
    mahjongTingWinDraw: "Listo・Ganar・Robar",
    checkersKing: "Rey",
    comingSoonText: "Este juego está en desarrollo y aparecerá aquí automáticamente cuando esté listo. ¡Manténte atento!",
    backToLobby: "Volver al Vestíbulo",
    costToastTemplate: "Se descontaron {cost} monedas de juego en esta partida",
  },
  pt: {
    mahjongWall: "Muro de Peças",
    mahjongTotalRounds: "Rodadas Totais",
    mahjongWinCount: "Vitórias",
    mahjongWinRate: "Taxa de Vitória",
    mahjongYourDiscards: "Seus Descartes",
    mahjongEatPongKong: "Chow・Pong・Kong",
    mahjongTingWinDraw: "Pronto・Vitória・Comprar",
    checkersKing: "Rei",
    comingSoonText: "Este jogo está em desenvolvimento e aparecerá aqui automaticamente quando estiver pronto. Aguarde!",
    backToLobby: "Voltar ao Lobby",
    costToastTemplate: "{cost} moedas de jogo foram deduzidas nesta partida",
  },
  fr: {
    mahjongWall: "Mur de Tuiles",
    mahjongTotalRounds: "Total des Manches",
    mahjongWinCount: "Victoires",
    mahjongWinRate: "Taux de Victoire",
    mahjongYourDiscards: "Vos Défausses",
    mahjongEatPongKong: "Chow・Pong・Kong",
    mahjongTingWinDraw: "Prêt・Victoire・Piocher",
    checkersKing: "Roi",
    comingSoonText: "Ce jeu est en cours de développement et apparaîtra ici automatiquement une fois prêt. Restez à l'écoute !",
    backToLobby: "Retour au Salon",
    costToastTemplate: "{cost} jetons de jeu ont été déduits pour cette partie",
  },
  de: {
    mahjongWall: "Mauerstapel",
    mahjongTotalRounds: "Gesamtrunden",
    mahjongWinCount: "Siege",
    mahjongWinRate: "Siegquote",
    mahjongYourDiscards: "Ihre Abwürfe",
    mahjongEatPongKong: "Chow・Pong・Kong",
    mahjongTingWinDraw: "Bereit・Sieg・Ziehen",
    checkersKing: "König",
    comingSoonText: "Dieses Spiel befindet sich noch in Entwicklung und erscheint hier automatisch, sobald es fertig ist. Bleiben Sie gespannt!",
    backToLobby: "Zurück zur Lobby",
    costToastTemplate: "{cost} Spielmünzen wurden für diese Runde abgezogen",
  },
  it: {
    mahjongWall: "Muro di Tessere",
    mahjongTotalRounds: "Round Totali",
    mahjongWinCount: "Vittorie",
    mahjongWinRate: "Tasso di Vittoria",
    mahjongYourDiscards: "I Tuoi Scarti",
    mahjongEatPongKong: "Chow・Pong・Kong",
    mahjongTingWinDraw: "Pronto・Vittoria・Pesca",
    checkersKing: "Re",
    comingSoonText: "Questo gioco è in fase di sviluppo e apparirà qui automaticamente una volta pronto. Restate sintonizzati!",
    backToLobby: "Torna alla Sala",
    costToastTemplate: "{cost} monete di gioco sono state dedotte per questa partita",
  },
  ru: {
    mahjongWall: "Стена костей",
    mahjongTotalRounds: "Всего раундов",
    mahjongWinCount: "Побед",
    mahjongWinRate: "Процент побед",
    mahjongYourDiscards: "Ваши сбросы",
    mahjongEatPongKong: "Чоу・Пон・Кон",
    mahjongTingWinDraw: "Тинг・Победа・Взять",
    checkersKing: "Король",
    comingSoonText: "Эта игра сейчас в разработке и появится здесь автоматически, когда будет готова. Следите за обновлениями!",
    backToLobby: "Вернуться в лобби",
    costToastTemplate: "За этот раунд списано {cost} игровых монет",
  },
  ar: {
    mahjongWall: "جدار البلاط",
    mahjongTotalRounds: "إجمالي الجولات",
    mahjongWinCount: "عدد الانتصارات",
    mahjongWinRate: "نسبة الفوز",
    mahjongYourDiscards: "بلاطاتك المرمية",
    mahjongEatPongKong: "تشاو・بونج・كونج",
    mahjongTingWinDraw: "تينج・فوز・سحب",
    checkersKing: "الملك",
    comingSoonText: "هذه اللعبة قيد التطوير حاليًا وستظهر هنا تلقائيًا عند اكتمالها. تابعونا!",
    backToLobby: "العودة إلى الردهة",
    costToastTemplate: "تم خصم {cost} من عملات اللعبة لهذه الجولة",
  },
  hi: {
    mahjongWall: "टाइल दीवार",
    mahjongTotalRounds: "कुल राउंड",
    mahjongWinCount: "जीत की संख्या",
    mahjongWinRate: "जीत दर",
    mahjongYourDiscards: "आपकी फेंकी टाइलें",
    mahjongEatPongKong: "चाओ・पोंग・कोंग",
    mahjongTingWinDraw: "तैयार・जीत・उठाना",
    checkersKing: "राजा",
    comingSoonText: "यह गेम अभी बनाया जा रहा है और तैयार होने पर यहां स्वचालित रूप से दिखेगा। बने रहें!",
    backToLobby: "लॉबी में वापस जाएं",
    costToastTemplate: "इस राउंड के लिए {cost} गेम कॉइन काटे गए",
  },
  tr: {
    mahjongWall: "Taş Duvarı",
    mahjongTotalRounds: "Toplam Tur",
    mahjongWinCount: "Kazanma Sayısı",
    mahjongWinRate: "Kazanma Oranı",
    mahjongYourDiscards: "Attığınız Taşlar",
    mahjongEatPongKong: "Chow・Pong・Kong",
    mahjongTingWinDraw: "Hazır・Kazan・Çek",
    checkersKing: "Şah",
    comingSoonText: "Bu oyun geliştirilmekte ve hazır olduğunda otomatik olarak burada görünecek. Takipte kalın!",
    backToLobby: "Lobiye Dön",
    costToastTemplate: "Bu tur için {cost} oyun jetonu kesildi",
  },
  bn: {
    mahjongWall: "টাইল প্রাচীর",
    mahjongTotalRounds: "মোট রাউন্ড",
    mahjongWinCount: "জয়ের সংখ্যা",
    mahjongWinRate: "জয়ের হার",
    mahjongYourDiscards: "আপনার ফেলা টাইল",
    mahjongEatPongKong: "চাও・পং・কং",
    mahjongTingWinDraw: "রেডি・জয়・তোলা",
    checkersKing: "রাজা",
    comingSoonText: "এই গেমটি তৈরি করা হচ্ছে এবং সম্পূর্ণ হলে এখানে স্বয়ংক্রিয়ভাবে দেখা যাবে। সাথেই থাকুন!",
    backToLobby: "লবিতে ফিরে যান",
    costToastTemplate: "এই রাউন্ডের জন্য {cost} গেম কয়েন কাটা হয়েছে",
  },
}

export function puzzleGameText(lang: LangId, id: PuzzleGameId): PuzzleGameText {
  return PUZZLE_GAME_TEXT[lang]?.[id] ?? PUZZLE_GAME_TEXT["zh-TW"][id]
}

export function puzzleCommonText(lang: LangId): PuzzleCommonText {
  return PUZZLE_COMMON_TEXT[lang] ?? PUZZLE_COMMON_TEXT["zh-TW"]
}
