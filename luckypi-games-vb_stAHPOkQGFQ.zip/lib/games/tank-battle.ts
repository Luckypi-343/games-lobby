// 坦克大戰 — 左右移動並發射砲彈，率先命中對方戰車 3 次者獲勝。
export const TB_COLS = 7
export const TB_ROWS = 9
export const TB_WIN_HITS = 3

export interface TbBullet {
  col: number
  row: number
}

export interface TbState {
  playerCol: number
  enemyCol: number
  playerBullets: TbBullet[]
  enemyBullets: TbBullet[]
  playerScore: number
  enemyScore: number
  enemyMoveCooldown: number
  enemyFireCooldown: number
  over: boolean
  won: boolean
}

export function tbNew(): TbState {
  return {
    playerCol: Math.floor(TB_COLS / 2),
    enemyCol: Math.floor(TB_COLS / 2),
    playerBullets: [],
    enemyBullets: [],
    playerScore: 0,
    enemyScore: 0,
    enemyMoveCooldown: 3,
    enemyFireCooldown: 4,
    over: false,
    won: false,
  }
}

export function tbMove(state: TbState, dx: number): TbState {
  if (state.over) return state
  const col = Math.max(0, Math.min(TB_COLS - 1, state.playerCol + dx))
  return { ...state, playerCol: col }
}

export function tbShoot(state: TbState): TbState {
  if (state.over || state.playerBullets.length >= 2) return state
  return { ...state, playerBullets: [...state.playerBullets, { col: state.playerCol, row: TB_ROWS - 2 }] }
}

export function tbTick(state: TbState): TbState {
  if (state.over) return state

  let enemyCol = state.enemyCol
  let enemyMoveCooldown = state.enemyMoveCooldown - 1
  if (enemyMoveCooldown <= 0) {
    const dir = state.playerCol > enemyCol ? 1 : state.playerCol < enemyCol ? -1 : Math.random() < 0.5 ? 1 : -1
    enemyCol = Math.max(0, Math.min(TB_COLS - 1, enemyCol + dir))
    enemyMoveCooldown = 3
  }

  let enemyBullets = state.enemyBullets.map((b) => ({ ...b, row: b.row + 1 }))
  let enemyFireCooldown = state.enemyFireCooldown - 1
  if (enemyFireCooldown <= 0 && state.enemyBullets.length < 2) {
    enemyBullets.push({ col: enemyCol, row: 1 })
    enemyFireCooldown = 4
  }

  let playerBullets = state.playerBullets.map((b) => ({ ...b, row: b.row - 1 }))

  let playerScore = state.playerScore
  let enemyScore = state.enemyScore

  const survivingPlayerBullets: TbBullet[] = []
  for (const b of playerBullets) {
    if (b.row <= 0 && b.col === enemyCol) {
      playerScore += 1
    } else if (b.row >= 0) {
      survivingPlayerBullets.push(b)
    }
  }
  playerBullets = survivingPlayerBullets

  const survivingEnemyBullets: TbBullet[] = []
  for (const b of enemyBullets) {
    if (b.row >= TB_ROWS - 1 && b.col === state.playerCol) {
      enemyScore += 1
    } else if (b.row < TB_ROWS) {
      survivingEnemyBullets.push(b)
    }
  }
  enemyBullets = survivingEnemyBullets

  const over = playerScore >= TB_WIN_HITS || enemyScore >= TB_WIN_HITS
  const won = playerScore >= TB_WIN_HITS

  return {
    playerCol: state.playerCol,
    enemyCol,
    playerBullets,
    enemyBullets,
    playerScore,
    enemyScore,
    enemyMoveCooldown,
    enemyFireCooldown,
    over,
    won,
  }
}
