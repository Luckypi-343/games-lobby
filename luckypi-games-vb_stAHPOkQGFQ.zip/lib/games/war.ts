// 戰爭牌（War）：牌堆對半分給雙方，每輪各翻一張牌比大小，較大者贏得該輪；平手時雙方各燒一張再翻牌比大小。
import { type Card, freshDeck, shuffled } from "./cards"

export interface WarState {
  playerDeck: Card[]
  aiDeck: Card[]
  playerFlip: Card[]
  aiFlip: Card[]
  round: number
  playerWins: number
  aiWins: number
  ties: number
  status: "playing" | "over"
  lastResult: "win" | "loss" | "tie" | null
  overallWinner: "player" | "ai" | "tie" | null
}

export function warInitial(): WarState {
  const deck = shuffled(freshDeck())
  const half = Math.floor(deck.length / 2)
  return {
    playerDeck: deck.slice(0, half),
    aiDeck: deck.slice(half),
    playerFlip: [],
    aiFlip: [],
    round: 0,
    playerWins: 0,
    aiWins: 0,
    ties: 0,
    status: "playing",
    lastResult: null,
    overallWinner: null,
  }
}

export function warFlip(state: WarState): WarState {
  if (state.status !== "playing") return state
  let playerDeck = [...state.playerDeck]
  let aiDeck = [...state.aiDeck]
  const playerFlip: Card[] = []
  const aiFlip: Card[] = []

  if (playerDeck.length === 0 || aiDeck.length === 0) {
    const overallWinner = playerDeck.length > aiDeck.length ? "player" : aiDeck.length > playerDeck.length ? "ai" : "tie"
    return { ...state, status: "over", overallWinner }
  }

  let pc = playerDeck.pop()!
  let ac = aiDeck.pop()!
  playerFlip.push(pc)
  aiFlip.push(ac)

  let ties = state.ties
  // Simplified war resolution: on tie, burn one extra card each side (if available) then compare again, up to 3 times.
  let attempts = 0
  while (pc.rank === ac.rank && attempts < 3) {
    if (playerDeck.length === 0 || aiDeck.length === 0) break
    ties++
    playerDeck.pop() // burn
    aiDeck.pop() // burn
    if (playerDeck.length === 0 || aiDeck.length === 0) break
    pc = playerDeck.pop()!
    ac = aiDeck.pop()!
    playerFlip.push(pc)
    aiFlip.push(ac)
    attempts++
  }

  let lastResult: WarState["lastResult"]
  let playerWins = state.playerWins
  let aiWins = state.aiWins
  if (pc.rank === ac.rank) {
    lastResult = "tie"
    ties++
  } else if (pc.rank > ac.rank) {
    lastResult = "win"
    playerWins++
    playerDeck = [...playerDeck, ...playerFlip, ...aiFlip]
  } else {
    lastResult = "loss"
    aiWins++
    aiDeck = [...aiDeck, ...playerFlip, ...aiFlip]
  }

  const status: WarState["status"] = playerDeck.length === 0 || aiDeck.length === 0 ? "over" : "playing"
  const overallWinner =
    status === "over" ? (playerDeck.length > aiDeck.length ? "player" : aiDeck.length > playerDeck.length ? "ai" : "tie") : null

  return {
    playerDeck,
    aiDeck,
    playerFlip,
    aiFlip,
    round: state.round + 1,
    playerWins,
    aiWins,
    ties,
    status,
    lastResult,
    overallWinner,
  }
}
