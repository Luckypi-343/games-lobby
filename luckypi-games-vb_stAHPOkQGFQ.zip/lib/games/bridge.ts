// 橋牌（簡化版）：您與電腦夥伴（北）組隊，對戰電腦兩位對手（西／東）。
// 為了讓單機版好上手，省略正式橋牌的「叫牌」流程，改成每局開局自動決定王牌花色（也可能是「無王」），
// 直接進入出牌階段：四人輪流出牌，須跟牌（有同花色的牌就必須打同花色），
// 沒有同花色時可以打任意牌（包含王牌），每一輪由「同花色最大」或「王牌最大」的人贏得該輪，
// 13輪出完後，您與夥伴合計贏得的輪數若達7輪（過半）即視為達成合約獲勝，對手合計達7輪則您方落敗。
import { type Card, type Suit, SUIT_SYMBOL, RANK_LABEL, freshDeck, shuffled } from "./cards"

export type Seat = "south" | "west" | "north" | "east" // 南(您) / 西 / 北(夥伴) / 東
export const SEAT_ORDER: Seat[] = ["south", "west", "north", "east"]
export const SEAT_LABEL: Record<Seat, string> = { south: "您", west: "西家", north: "夥伴", east: "東家" }
export function isYourTeam(seat: Seat): boolean {
  return seat === "south" || seat === "north"
}

export interface Trick {
  ledSuit: Suit
  plays: { seat: Seat; card: Card }[]
  winner: Seat | null
}

export interface BridgeState {
  trump: Suit | null // null = 無王
  hands: Record<Seat, Card[]>
  turn: Seat
  leader: Seat
  currentTrick: Trick
  completedTricks: Trick[]
  tricksWon: Record<Seat, number>
  finished: boolean
  outcome: "win" | "lose" | null
}

export function dealBridge(): BridgeState {
  const deck = shuffled(freshDeck())
  const hands: Record<Seat, Card[]> = { south: [], west: [], north: [], east: [] }
  SEAT_ORDER.forEach((seat, i) => {
    hands[seat] = deck.slice(i * 13, i * 13 + 13).sort((a, b) => a.suit - b.suit || a.rank - b.rank)
  })
  const trump = (Math.floor(Math.random() * 5) - 1) as -1 | Suit
  return {
    trump: trump === -1 ? null : trump,
    hands,
    turn: "south",
    leader: "south",
    currentTrick: { ledSuit: hands.south[0].suit, plays: [], winner: null },
    completedTricks: [],
    tricksWon: { south: 0, west: 0, north: 0, east: 0 },
    finished: false,
    outcome: null,
  }
}

export function nextSeat(seat: Seat): Seat {
  return SEAT_ORDER[(SEAT_ORDER.indexOf(seat) + 1) % 4]
}

// 是否必須跟牌：手上有跟出方花色的牌時就不能打別的花色。
export function legalCards(hand: Card[], ledSuit: Suit | null): Card[] {
  if (ledSuit == null) return hand
  const followers = hand.filter((c) => c.suit === ledSuit)
  return followers.length > 0 ? followers : hand
}

function trickWinner(trick: Trick, trump: Suit | null): Seat {
  let best = trick.plays[0]
  for (const p of trick.plays.slice(1)) {
    const bestIsTrump = trump != null && best.card.suit === trump
    const pIsTrump = trump != null && p.card.suit === trump
    if (pIsTrump && !bestIsTrump) {
      best = p
    } else if (pIsTrump === bestIsTrump) {
      if (p.card.suit === best.card.suit && p.card.rank > best.card.rank) best = p
    }
  }
  return best.seat
}

// 電腦座位的簡易出牌邏輯：能跟牌就跟，優先打得贏這一輪的最小牌，贏不了就丟最小的牌。
function aiChoose(hand: Card[], trick: Trick, trump: Suit | null): Card {
  const options = legalCards(hand, trick.plays.length > 0 ? trick.ledSuit : null)
  if (trick.plays.length === 0) {
    return [...options].sort((a, b) => a.rank - b.rank)[0]
  }
  const currentWinner = trickWinner({ ...trick, plays: trick.plays }, trump)
  const winningCard = trick.plays.find((p) => p.seat === currentWinner)!.card
  const canBeat = options.filter((c) => {
    const isTrump = trump != null && c.suit === trump
    const winIsTrump = trump != null && winningCard.suit === trump
    if (isTrump && !winIsTrump) return true
    if (isTrump === winIsTrump && c.suit === winningCard.suit) return c.rank > winningCard.rank
    return false
  })
  if (canBeat.length > 0) return [...canBeat].sort((a, b) => a.rank - b.rank)[0]
  return [...options].sort((a, b) => a.rank - b.rank)[0]
}

export function playCard(state: BridgeState, seat: Seat, card: Card): BridgeState {
  if (state.finished || state.turn !== seat) return state
  const hand = state.hands[seat]
  const ledSuit = state.currentTrick.plays.length > 0 ? state.currentTrick.ledSuit : card.suit
  const legal = legalCards(hand, state.currentTrick.plays.length > 0 ? state.currentTrick.ledSuit : null)
  if (!legal.some((c) => c.id === card.id)) return state

  let next: BridgeState = {
    ...state,
    hands: { ...state.hands, [seat]: hand.filter((c) => c.id !== card.id) },
    currentTrick: {
      ledSuit: state.currentTrick.plays.length > 0 ? state.currentTrick.ledSuit : ledSuit,
      plays: [...state.currentTrick.plays, { seat, card }],
      winner: null,
    },
  }

  if (next.currentTrick.plays.length === 4) {
    const winner = trickWinner(next.currentTrick, next.trump)
    const finishedTrick: Trick = { ...next.currentTrick, winner }
    const tricksWon = { ...next.tricksWon, [winner]: next.tricksWon[winner] + 1 }
    const completedTricks = [...next.completedTricks, finishedTrick]
    const handsLeft = next.hands.south.length
    if (handsLeft === 0) {
      const yourTeamTricks = tricksWon.south + tricksWon.north
      next = {
        ...next,
        completedTricks,
        tricksWon,
        finished: true,
        outcome: yourTeamTricks >= 7 ? "win" : "lose",
        currentTrick: { ledSuit: 0 as Suit, plays: [], winner },
      }
    } else {
      next = {
        ...next,
        completedTricks,
        tricksWon,
        leader: winner,
        turn: winner,
        currentTrick: { ledSuit: next.hands[winner][0]?.suit ?? (0 as Suit), plays: [], winner: null },
      }
    }
  } else {
    next = { ...next, turn: nextSeat(seat) }
  }

  // 電腦座位自動出牌，直到輪到「您」或整局結束。
  while (!next.finished && next.turn !== "south") {
    const aiSeat = next.turn
    const aiHand = next.hands[aiSeat]
    const aiCard = aiChoose(aiHand, next.currentTrick, next.trump)
    next = playCard(next, aiSeat, aiCard)
  }

  return next
}

export function suitSymbol(suit: Suit | null): string {
  return suit == null ? "無王" : SUIT_SYMBOL[suit]
}

export function cardLabel(card: Card): string {
  return `${SUIT_SYMBOL[card.suit]}${RANK_LABEL[card.rank]}`
}
