export type XQColor = "r" | "b"
export type XQType = "R" | "N" | "B" | "A" | "K" | "C" | "P"
export interface XQPiece {
  type: XQType
  color: XQColor
}
export type XQBoard = (XQPiece | null)[]

export const XQ_COLS = 9
export const XQ_ROWS = 10

export interface XQMove {
  from: number
  to: number
}

export interface XQState {
  board: XQBoard
  turn: XQColor
  status: "playing" | "checkmate" | "stalemate"
  lastMove: XQMove | null
  inCheck: boolean
}

function idx(r: number, c: number) {
  return r * XQ_COLS + c
}
function rc(i: number): [number, number] {
  return [Math.floor(i / XQ_COLS), i % XQ_COLS]
}
function inBounds(r: number, c: number) {
  return r >= 0 && r < XQ_ROWS && c >= 0 && c < XQ_COLS
}

export function xqInitial(): XQState {
  const board: XQBoard = Array(XQ_COLS * XQ_ROWS).fill(null)
  const back: XQType[] = ["R", "N", "B", "A", "K", "A", "B", "N", "R"]
  back.forEach((t, c) => (board[idx(0, c)] = { type: t, color: "b" }))
  board[idx(2, 1)] = { type: "C", color: "b" }
  board[idx(2, 7)] = { type: "C", color: "b" }
  ;[0, 2, 4, 6, 8].forEach((c) => (board[idx(3, c)] = { type: "P", color: "b" }))

  back.forEach((t, c) => (board[idx(9, c)] = { type: t, color: "r" }))
  board[idx(7, 1)] = { type: "C", color: "r" }
  board[idx(7, 7)] = { type: "C", color: "r" }
  ;[0, 2, 4, 6, 8].forEach((c) => (board[idx(6, c)] = { type: "P", color: "r" }))

  return { board, turn: "r", status: "playing", lastMove: null, inCheck: false }
}

function inPalace(r: number, c: number) {
  return c >= 3 && c <= 5 && (r <= 2 || r >= 7)
}

function pseudoMoves(board: XQBoard, from: number): number[] {
  const piece = board[from]
  if (!piece) return []
  const [r, c] = rc(from)
  const moves: number[] = []
  const push = (r2: number, c2: number) => {
    if (!inBounds(r2, c2)) return false
    const target = board[idx(r2, c2)]
    if (!target) {
      moves.push(idx(r2, c2))
      return true
    }
    if (target.color !== piece.color) moves.push(idx(r2, c2))
    return false
  }

  switch (piece.type) {
    case "R": {
      const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]]
      for (const [dr, dc] of dirs) {
        let rr = r + dr
        let cc = c + dc
        while (inBounds(rr, cc)) {
          if (!push(rr, cc)) break
          rr += dr
          cc += dc
        }
      }
      break
    }
    case "N": {
      const steps = [
        [2, 1, 1, 0],
        [2, -1, 1, 0],
        [-2, 1, -1, 0],
        [-2, -1, -1, 0],
        [1, 2, 0, 1],
        [-1, 2, 0, 1],
        [1, -2, 0, -1],
        [-1, -2, 0, -1],
      ]
      for (const [dr, dc, legR, legC] of steps) {
        const legR2 = r + legR
        const legC2 = c + legC
        if (inBounds(legR2, legC2) && board[idx(legR2, legC2)]) continue
        const r2 = r + dr
        const c2 = c + dc
        if (inBounds(r2, c2)) {
          const target = board[idx(r2, c2)]
          if (!target || target.color !== piece.color) moves.push(idx(r2, c2))
        }
      }
      break
    }
    case "B": {
      const dirs = [[2, 2], [2, -2], [-2, 2], [-2, -2]]
      for (const [dr, dc] of dirs) {
        const midR = r + dr / 2
        const midC = c + dc / 2
        const r2 = r + dr
        const c2 = c + dc
        if (!inBounds(r2, c2)) continue
        if (board[idx(midR, midC)]) continue
        const inOwnSide = piece.color === "r" ? r2 >= 5 : r2 <= 4
        if (!inOwnSide) continue
        const target = board[idx(r2, c2)]
        if (!target || target.color !== piece.color) moves.push(idx(r2, c2))
      }
      break
    }
    case "A": {
      const dirs = [[1, 1], [1, -1], [-1, 1], [-1, -1]]
      for (const [dr, dc] of dirs) {
        const r2 = r + dr
        const c2 = c + dc
        if (!inBounds(r2, c2) || !inPalace(r2, c2)) continue
        const target = board[idx(r2, c2)]
        if (!target || target.color !== piece.color) moves.push(idx(r2, c2))
      }
      break
    }
    case "K": {
      const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]]
      for (const [dr, dc] of dirs) {
        const r2 = r + dr
        const c2 = c + dc
        if (!inBounds(r2, c2) || !inPalace(r2, c2)) continue
        const target = board[idx(r2, c2)]
        if (!target || target.color !== piece.color) moves.push(idx(r2, c2))
      }
      break
    }
    case "C": {
      const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]]
      for (const [dr, dc] of dirs) {
        let rr = r + dr
        let cc = c + dc
        let screenFound = false
        while (inBounds(rr, cc)) {
          const target = board[idx(rr, cc)]
          if (!screenFound) {
            if (!target) moves.push(idx(rr, cc))
            else screenFound = true
          } else {
            if (target) {
              if (target.color !== piece.color) moves.push(idx(rr, cc))
              break
            }
          }
          rr += dr
          cc += dc
        }
      }
      break
    }
    case "P": {
      const forward = piece.color === "r" ? -1 : 1
      const r2 = r + forward
      if (inBounds(r2, c)) {
        const target = board[idx(r2, c)]
        if (!target || target.color !== piece.color) moves.push(idx(r2, c))
      }
      const crossed = piece.color === "r" ? r <= 4 : r >= 5
      if (crossed) {
        for (const dc of [1, -1]) {
          const c2 = c + dc
          if (inBounds(r, c2)) {
            const target = board[idx(r, c2)]
            if (!target || target.color !== piece.color) moves.push(idx(r, c2))
          }
        }
      }
      break
    }
  }
  return moves
}

function findKing(board: XQBoard, color: XQColor): number {
  return board.findIndex((p) => p?.type === "K" && p.color === color)
}

function isAttacked(board: XQBoard, square: number, byColor: XQColor): boolean {
  for (let i = 0; i < board.length; i++) {
    const p = board[i]
    if (p && p.color === byColor) {
      if (pseudoMoves(board, i).includes(square)) return true
    }
  }
  return false
}

export function xqLegalMoves(state: XQState, from: number): number[] {
  const piece = state.board[from]
  if (!piece || piece.color !== state.turn) return []
  const pseudo = pseudoMoves(state.board, from)
  return pseudo.filter((to) => {
    const next = state.board.slice()
    next[to] = next[from]
    next[from] = null
    const kingSq = findKing(next, piece.color)
    return kingSq === -1 ? false : !isAttacked(next, kingSq, piece.color === "r" ? "b" : "r")
  })
}

export function xqAllLegalMoves(state: XQState): XQMove[] {
  const out: XQMove[] = []
  for (let i = 0; i < state.board.length; i++) {
    const p = state.board[i]
    if (p && p.color === state.turn) {
      for (const to of xqLegalMoves(state, i)) out.push({ from: i, to })
    }
  }
  return out
}

export function xqMove(state: XQState, from: number, to: number): XQState {
  if (!xqLegalMoves(state, from).includes(to)) return state
  const board = state.board.slice()
  board[to] = board[from]
  board[from] = null
  const nextTurn: XQColor = state.turn === "r" ? "b" : "r"
  const kingSq = findKing(board, nextTurn)
  const inCheck = kingSq !== -1 && isAttacked(board, kingSq, state.turn)
  const nextState: XQState = { board, turn: nextTurn, status: "playing", lastMove: { from, to }, inCheck }
  const legal = xqAllLegalMoves(nextState)
  if (legal.length === 0) nextState.status = inCheck ? "checkmate" : "stalemate"
  return nextState
}

const VALUES: Record<XQType, number> = { R: 90, N: 40, B: 20, A: 20, K: 1000, C: 45, P: 10 }

function evaluate(board: XQBoard): number {
  let score = 0
  for (const p of board) {
    if (!p) continue
    const v = VALUES[p.type]
    score += p.color === "r" ? v : -v
  }
  return score
}

function minimax(state: XQState, depth: number, alpha: number, beta: number, maximizing: boolean): number {
  if (depth === 0 || state.status !== "playing") {
    const evalScore = evaluate(state.board)
    if (state.status === "checkmate") return state.turn === "r" ? -100000 - depth : 100000 + depth
    return evalScore
  }
  const moves = xqAllLegalMoves(state)
  if (moves.length === 0) return maximizing ? -100000 : 100000
  let best = maximizing ? -Infinity : Infinity
  for (const m of moves) {
    const next = xqMove(state, m.from, m.to)
    const val = minimax(next, depth - 1, alpha, beta, !maximizing)
    if (maximizing) {
      best = Math.max(best, val)
      alpha = Math.max(alpha, val)
    } else {
      best = Math.min(best, val)
      beta = Math.min(beta, val)
    }
    if (beta <= alpha) break
  }
  return best
}

export function xqAiMove(state: XQState, depth = 2): XQMove | null {
  const moves = xqAllLegalMoves(state)
  if (moves.length === 0) return null
  const maximizing = state.turn === "r"
  let best: XQMove | null = null
  let bestScore = maximizing ? -Infinity : Infinity
  const shuffled = moves
    .map((m) => ({ m, r: Math.random() }))
    .sort((a, b) => a.r - b.r)
    .map((x) => x.m)
  for (const m of shuffled) {
    const next = xqMove(state, m.from, m.to)
    const val = minimax(next, depth - 1, -Infinity, Infinity, !maximizing)
    if ((maximizing && val > bestScore) || (!maximizing && val < bestScore)) {
      bestScore = val
      best = m
    }
  }
  return best
}

export const XQ_LABELS: Record<XQColor, Record<XQType, string>> = {
  r: { R: "俥", N: "傌", B: "相", A: "仕", K: "帥", C: "炮", P: "兵" },
  b: { R: "車", N: "馬", B: "象", A: "士", K: "將", C: "砲", P: "卒" },
}
