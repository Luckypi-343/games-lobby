// 撿紅點：您與電腦輪流出牌，出的牌點數跟桌面上的牌相同就能「撿」走（連同自己出的牌一起收進得分堆），
// 沒有相同點數就把牌留在桌面上。整副牌（不含鬼牌）出完後，比較雙方撿到的「紅牌（紅心／方塊）」點數，
// 一般紅牌 1 分，紅色 10、J、Q、K 各算 10 分（俗稱「紅十」「紅人頭」），總分較高者獲勝。
import { type Card, isRedSuit, freshDeck, shuffled } from "./cards"

export type PrpPlayer = "you" | "ai"

export interface PickRedPointsState {
  table: Card[]
  hand: Record<PrpPlayer, Card[]>
  drawPile: Card[]
  captured: Record<PrpPlayer, Card[]>
  lastCapturer: PrpPlayer | null
  turn: PrpPlayer
  finished: boolean
  outcome: "win" | "lose" | "draw" | null
}

export function cardPoints(card: Card): number {
  if (!isRedSuit(card.suit)) return 0
  if (card.rank >= 10) return 10 // 紅10／J／Q／K
  return 1
}

export function totalPoints(cards: Card[]): number {
  return cards.reduce((sum, c) => sum + cardPoints(c), 0)
}

export function dealPickRedPoints(): PickRedPointsState {
  const deck = shuffled(freshDeck())
  const table = deck.slice(0, 4)
  const you = deck.slice(4, 8)
  const ai = deck.slice(8, 12)
  const drawPile = deck.slice(12)
  return {
    table,
    hand: { you, ai },
    drawPile,
    captured: { you: [], ai: [] },
    lastCapturer: null,
    turn: "you",
    finished: false,
    outcome: null,
  }
}

function refillIfNeeded(state: PickRedPointsState): PickRedPointsState {
  if (state.hand.you.length > 0 || state.hand.ai.length === 0) return state
  // 雙方手牌都出完時，若牌堆還有牌，各補發 4 張繼續。
  if (state.drawPile.length === 0) return state
  const drawPile = [...state.drawPile]
  const you = drawPile.splice(0, Math.min(4, drawPile.length))
  const ai = drawPile.splice(0, Math.min(4, drawPile.length))
  return { ...state, drawPile, hand: { you, ai } }
}

function finishIfDone(state: PickRedPointsState): PickRedPointsState {
  const noHandsLeft = state.hand.you.length === 0 && state.hand.ai.length === 0
  if (!noHandsLeft || state.drawPile.length > 0) return state
  // 桌面剩牌歸最後一次撿牌的人（沒人撿過就作廢，不計分）。
  let captured = state.captured
  if (state.table.length > 0 && state.lastCapturer) {
    captured = { ...captured, [state.lastCapturer]: [...captured[state.lastCapturer], ...state.table] }
  }
  const you = totalPoints(captured.you)
  const ai = totalPoints(captured.ai)
  const outcome: "win" | "lose" | "draw" = you > ai ? "win" : you < ai ? "lose" : "draw"
  return { ...state, table: [], captured, finished: true, outcome }
}

export function playPrpCard(state: PickRedPointsState, player: PrpPlayer, card: Card): PickRedPointsState {
  if (state.finished || state.turn !== player) return state
  const hand = state.hand[player]
  if (!hand.some((c) => c.id === card.id)) return state

  const matches = state.table.filter((c) => c.rank === card.rank)
  let table = state.table
  let captured = state.captured
  let lastCapturer = state.lastCapturer
  if (matches.length > 0) {
    table = state.table.filter((c) => c.rank !== card.rank)
    captured = { ...captured, [player]: [...captured[player], ...matches, card] }
    lastCapturer = player
  } else {
    table = [...state.table, card]
  }

  let next: PickRedPointsState = {
    ...state,
    table,
    captured,
    lastCapturer,
    hand: { ...state.hand, [player]: hand.filter((c) => c.id !== card.id) },
    turn: player === "you" ? "ai" : "you",
  }
  next = refillIfNeeded(next)
  next = finishIfDone(next)

  // 電腦自動出牌：優先打能撿到最高分的牌，撿不到就丟手上點數最小的牌。
  while (!next.finished && next.turn === "ai" && next.hand.ai.length > 0) {
    const aiHand = next.hand.ai
    let bestCard = aiHand[0]
    let bestScore = -1
    for (const c of aiHand) {
      const m = next.table.filter((t) => t.rank === c.rank)
      const score = totalPoints(m) + cardPoints(c)
      if (m.length > 0 && score > bestScore) {
        bestScore = score
        bestCard = c
      }
    }
    if (bestScore < 0) {
      bestCard = [...aiHand].sort((a, b) => cardPoints(a) - cardPoints(b))[0]
    }
    next = playPrpCard(next, "ai", bestCard)
  }

  return next
}
