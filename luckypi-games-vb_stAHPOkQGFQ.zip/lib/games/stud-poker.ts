// 梭哈：玩家 vs 莊家(電腦)，各發5張牌，直接比牌型大小（同花順、鐵支、葫蘆、同花、順子、三條、兩對、一對、高牌）。
import { type Card, freshDeck, shuffled, evaluate5, HAND_NAME } from "./cards"

export interface StudState {
  deck: Card[]
  player: Card[]
  dealer: Card[]
  status: "betting" | "over"
  result: "win" | "loss" | "tie" | null
  playerHandName: string | null
  dealerHandName: string | null
  wins: number
  losses: number
  hands: number
}

function cmpScore(a: number[], b: number[]): number {
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const av = a[i] ?? -1
    const bv = b[i] ?? -1
    if (av !== bv) return av - bv
  }
  return 0
}

export function studInitial(): StudState {
  return studNewHand({
    deck: [],
    player: [],
    dealer: [],
    status: "betting",
    result: null,
    playerHandName: null,
    dealerHandName: null,
    wins: 0,
    losses: 0,
    hands: 0,
  })
}

export function studNewHand(prev: StudState): StudState {
  let deck = shuffled(freshDeck())
  if (deck.length < 12) deck = shuffled(freshDeck())
  const player = Array.from({ length: 5 }, () => deck.pop()!)
  const dealer = Array.from({ length: 5 }, () => deck.pop()!)
  return {
    deck,
    player,
    dealer,
    status: "betting",
    result: null,
    playerHandName: null,
    dealerHandName: null,
    wins: prev.wins,
    losses: prev.losses,
    hands: prev.hands + 1,
  }
}

export function studReveal(state: StudState): StudState {
  if (state.status !== "betting") return state
  const ps = evaluate5(state.player)
  const ds = evaluate5(state.dealer)
  const diff = cmpScore(ps, ds)
  const result: StudState["result"] = diff === 0 ? "tie" : diff > 0 ? "win" : "loss"
  return {
    ...state,
    status: "over",
    result,
    playerHandName: HAND_NAME[ps[0]],
    dealerHandName: HAND_NAME[ds[0]],
    wins: state.wins + (result === "win" ? 1 : 0),
    losses: state.losses + (result === "loss" ? 1 : 0),
  }
}
