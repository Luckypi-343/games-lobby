// 炸金花：玩家 vs 莊家(電腦)，各發3張牌，直接比牌型大小
// （三條(豹子) > 同花順 > 同花(金花) > 順子 > 對子 > 單張）。
import { type Card, freshDeck, shuffled, evaluate3, threeCardHandName } from "./cards"

export interface ZjhState {
  deck: Card[]
  player: Card[]
  dealer: Card[]
  status: "betting" | "over"
  result: "win" | "loss" | "tie" | null
  playerHandName: string | null
  dealerHandName: string | null
  wins: number
  losses: number
  hands: number
}

function cmpScore(a: number[], b: number[]): number {
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const av = a[i] ?? -1
    const bv = b[i] ?? -1
    if (av !== bv) return av - bv
  }
  return 0
}

export function zjhInitial(): ZjhState {
  return zjhNewHand({
    deck: [],
    player: [],
    dealer: [],
    status: "betting",
    result: null,
    playerHandName: null,
    dealerHandName: null,
    wins: 0,
    losses: 0,
    hands: 0,
  })
}

export function zjhNewHand(prev: ZjhState): ZjhState {
  let deck = shuffled(freshDeck())
  if (deck.length < 10) deck = shuffled(freshDeck())
  const player = [deck.pop()!, deck.pop()!, deck.pop()!]
  const dealer = [deck.pop()!, deck.pop()!, deck.pop()!]
  return {
    deck,
    player,
    dealer,
    status: "betting",
    result: null,
    playerHandName: null,
    dealerHandName: null,
    wins: prev.wins,
    losses: prev.losses,
    hands: prev.hands + 1,
  }
}

export function zjhReveal(state: ZjhState): ZjhState {
  if (state.status !== "betting") return state
  const ps = evaluate3(state.player)
  const ds = evaluate3(state.dealer)
  const diff = cmpScore(ps, ds)
  const result: ZjhState["result"] = diff === 0 ? "tie" : diff > 0 ? "win" : "loss"
  return {
    ...state,
    status: "over",
    result,
    playerHandName: threeCardHandName(state.player),
    dealerHandName: threeCardHandName(state.dealer),
    wins: state.wins + (result === "win" ? 1 : 0),
    losses: state.losses + (result === "loss" ? 1 : 0),
  }
}
