// 分色排序 — 把試管內混雜的顏色倒一倒，讓每支試管都變成單一顏色。
export const WS_CAPACITY = 4
export const WS_COLORS = 6
export const WS_EMPTY_TUBES = 2
export const WS_PALETTE = [
  "bg-rose-500",
  "bg-sky-500",
  "bg-emerald-500",
  "bg-amber-500",
  "bg-fuchsia-500",
  "bg-indigo-500",
]

export interface WsState {
  tubes: number[][]
  selected: number | null
  moves: number
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

export function wsNew(): WsState {
  const units: number[] = []
  for (let c = 0; c < WS_COLORS; c++) for (let n = 0; n < WS_CAPACITY; n++) units.push(c)
  const shuffled = shuffle(units)
  const tubes: number[][] = []
  for (let t = 0; t < WS_COLORS; t++) tubes.push(shuffled.slice(t * WS_CAPACITY, (t + 1) * WS_CAPACITY))
  for (let e = 0; e < WS_EMPTY_TUBES; e++) tubes.push([])
  return { tubes, selected: null, moves: 0 }
}

export function wsWon(tubes: number[][]): boolean {
  return tubes.every((t) => t.length === 0 || (t.length === WS_CAPACITY && t.every((c) => c === t[0])))
}

export function wsTap(state: WsState, i: number): WsState {
  if (state.selected === null) {
    if (state.tubes[i].length === 0) return state
    return { ...state, selected: i }
  }
  if (state.selected === i) return { ...state, selected: null }
  const src = state.tubes[state.selected]
  const dst = state.tubes[i]
  if (src.length === 0) return { ...state, selected: null }
  const top = src[src.length - 1]
  if (dst.length > 0 && dst[dst.length - 1] !== top) return { ...state, selected: null }
  if (dst.length >= WS_CAPACITY) return { ...state, selected: null }
  let count = 0
  for (let k = src.length - 1; k >= 0; k--) {
    if (src[k] === top) count++
    else break
  }
  const space = WS_CAPACITY - dst.length
  const pourCount = Math.min(count, space)
  const tubes = state.tubes.map((t, idx2) => {
    if (idx2 === state.selected) return t.slice(0, t.length - pourCount)
    if (idx2 === i) return [...t, ...Array(pourCount).fill(top)]
    return t
  })
  return { tubes, selected: null, moves: state.moves + 1 }
}
