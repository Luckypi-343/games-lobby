// 殭屍防禦 — 點擊消滅逼近的殭屍，撐過所有波次即獲勝。
export const ZD_LANES = 4
export const ZD_LIVES = 5
export const ZD_WAVE_TARGET = 5

export interface Zombie {
  id: number
  lane: number
  dist: number
  speed: number
  hp: number
}

export interface ZdState {
  zombies: Zombie[]
  wave: number
  lives: number
  score: number
  spawned: number
  waveQuota: number
  spawnCooldown: number
  over: boolean
  won: boolean
  nextId: number
}

export function zdNew(): ZdState {
  return {
    zombies: [],
    wave: 1,
    lives: ZD_LIVES,
    score: 0,
    spawned: 0,
    waveQuota: 5,
    spawnCooldown: 0,
    over: false,
    won: false,
    nextId: 1,
  }
}

export function zdHit(state: ZdState, id: number): ZdState {
  if (state.over) return state
  const z = state.zombies.find((zz) => zz.id === id)
  if (!z) return state
  const hp = z.hp - 1
  if (hp <= 0) {
    return { ...state, zombies: state.zombies.filter((zz) => zz.id !== id), score: state.score + 5 }
  }
  return { ...state, zombies: state.zombies.map((zz) => (zz.id === id ? { ...zz, hp } : zz)) }
}

export function zdTick(state: ZdState): ZdState {
  if (state.over) return state

  let zombies = state.zombies.map((z) => ({ ...z, dist: z.dist - z.speed }))
  let lives = state.lives
  const survivors: Zombie[] = []
  for (const z of zombies) {
    if (z.dist <= 0) lives -= 1
    else survivors.push(z)
  }
  zombies = survivors

  let spawned = state.spawned
  let spawnCooldown = state.spawnCooldown - 1
  let waveQuota = state.waveQuota
  let wave = state.wave

  if (spawnCooldown <= 0 && spawned < waveQuota) {
    const lane = Math.floor(Math.random() * ZD_LANES)
    const speed = 1.1 + wave * 0.18 + Math.random() * 0.4
    const hp = wave >= 4 && Math.random() < 0.3 ? 2 : 1
    zombies = [...zombies, { id: state.nextId, lane, dist: 100, speed, hp }]
    spawned += 1
    spawnCooldown = Math.max(14, 34 - wave * 3)
  }

  let won = state.won
  let over = false
  if (spawned >= waveQuota && zombies.length === 0) {
    if (wave >= ZD_WAVE_TARGET) {
      won = true
      over = true
    } else {
      wave += 1
      waveQuota = 5 + wave
      spawned = 0
      spawnCooldown = 20
    }
  }

  if (lives <= 0) over = true

  return {
    zombies,
    wave,
    lives,
    score: state.score,
    spawned,
    waveQuota,
    spawnCooldown,
    over,
    won,
    nextId: state.nextId + 1,
  }
}
