"use client"

import { useEffect, useRef, useState } from "react"
import { Box, Mountain } from "lucide-react"
import { PuzzleShell } from "./puzzle-shell"
import { tbNew, tbMove, tbShoot, tbTick, TB_COLS, TB_ROWS, TB_WIN_HITS, type TbState } from "@/lib/games/tank-battle"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playCaptureSound, playWinSound, playLossSound } from "@/lib/games/game-audio"

interface Battlefield {
  id: number
  name: string
  ground: string
  sky: string
  obstacle: "crate" | "rock"
  obstacleColor: string
  layout: Array<[number, number]>
}

// 10 個主題關卡戰場，各自不同地貌配色與障礙佈置，模仿傳統戰場場景
const BATTLEFIELDS: Battlefield[] = [
  { id: 1, name: "黃沙戰線", ground: "#c9a46a", sky: "#f3dfb0", obstacle: "rock", obstacleColor: "#8a6a44", layout: [[3, 1], [3, 5], [5, 3]] },
  { id: 2, name: "雪原要塞", ground: "#e7eef5", sky: "#cfe0ee", obstacle: "crate", obstacleColor: "#8899aa", layout: [[2, 2], [4, 4], [6, 1], [6, 5]] },
  { id: 3, name: "叢林迷霧", ground: "#4f6b3c", sky: "#7a9a5e", obstacle: "rock", obstacleColor: "#2f4426", layout: [[3, 3], [4, 1], [4, 5], [5, 3]] },
  { id: 4, name: "都市廢墟", ground: "#6b6b6f", sky: "#9a9aa0", obstacle: "crate", obstacleColor: "#4a4a4e", layout: [[2, 1], [2, 5], [5, 2], [5, 4]] },
  { id: 5, name: "海岸灘頭", ground: "#d9c89a", sky: "#9fc9e0", obstacle: "crate", obstacleColor: "#a67c4e", layout: [[3, 2], [3, 4]] },
  { id: 6, name: "峽谷山地", ground: "#8c7a63", sky: "#c7b896", obstacle: "rock", obstacleColor: "#5a4b38", layout: [[2, 3], [4, 1], [4, 5], [6, 3]] },
  { id: 7, name: "戈壁荒原", ground: "#b9a582", sky: "#e8d9ad", obstacle: "rock", obstacleColor: "#6e5c3f", layout: [[3, 0], [3, 6], [5, 3]] },
  { id: 8, name: "鋼鐵要塞", ground: "#55575c", sky: "#7d8086", obstacle: "crate", obstacleColor: "#2e3034", layout: [[2, 2], [2, 4], [4, 3], [6, 2], [6, 4]] },
  { id: 9, name: "熱帶叢林", ground: "#3f6b4a", sky: "#6b9a6f", obstacle: "rock", obstacleColor: "#254030", layout: [[3, 1], [3, 3], [3, 5], [5, 2], [5, 4]] },
  { id: 10, name: "極地防線", ground: "#dfe8f0", sky: "#aecbe0", obstacle: "crate", obstacleColor: "#5a7a94", layout: [[2, 3], [4, 1], [4, 5], [6, 3]] },
]

export function TankBattleView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [battlefield, setBattlefield] = useState<Battlefield | null>(null)
  const [state, setState] = useState<TbState>(() => tbNew())
  const overRef = useRef(false)

  // 每次重新挑戰都要回到戰場選擇畫面，重新選擇一個戰場並扣除遊戲幣再進入
  const restart = () => {
    setBattlefield(null)
    setState(tbNew())
    overRef.current = false
  }

  const startBattle = (bf: Battlefield) => {
    setBattlefield(bf)
    setState(tbNew())
    overRef.current = false
  }

  useEffect(() => {
    if (state.over && !overRef.current) {
      overRef.current = true
      if (soundOn) {
        if (state.won) playWinSound()
        else playLossSound()
      }
    }
  }, [state.over, state.won, soundOn])

  useEffect(() => {
    const id = setInterval(() => {
      setState((s) => {
        const before = s.playerScore + s.enemyScore
        const next = tbTick(s)
        if (next.playerScore + next.enemyScore > before && soundOn) playCaptureSound()
        return next
      })
    }, 260)
    return () => clearInterval(id)
  }, [soundOn])

  // 場地寬×高加大為原本的 1.3 倍 × 1.5 倍
  const WIDTH_SCALE = 1.3
  const HEIGHT_SCALE = 1.5
  const cellW = 26 * WIDTH_SCALE
  const cellH = 26 * HEIGHT_SCALE
  const gapW = 3 * WIDTH_SCALE
  const gapH = 3 * HEIGHT_SCALE
  const fieldWidth = TB_COLS * (cellW + gapW) - gapW + 16
  const fieldHeight = TB_ROWS * (cellH + gapH) - gapH + 16

  // 尚未選擇戰場：顯示 10 個關卡戰場讓玩家挑選，選定後才扣幣進入對戰
  if (!battlefield) {
    return (
      <PuzzleShell
        gameId="tank-battle"
        title="坦克大戰"
        subtitle="率先命中對方 3 次獲勝"
        status="請先選擇一個戰場再進入對戰"
        rulesBrief="左右移動戰車並發射砲彈，砲彈命中對方所在直線即得分，率先命中對方 3 次者獲勝。每次挑戰只能選擇一個戰場進入，戰場各有不同地貌與障礙佈置。"
        solved={false}
        cost={12}
        onBack={onBack}
        onRestart={() => {}}
      >
        <div className="grid w-full max-w-sm grid-cols-2 gap-2">
          {BATTLEFIELDS.map((bf) => (
            <button
              key={bf.id}
              onClick={() => startBattle(bf)}
              className="flex flex-col items-center gap-1 rounded-xl border border-border p-2 text-center shadow-sm transition active:scale-95"
              style={{ background: `linear-gradient(180deg, ${bf.sky}, ${bf.ground})` }}
            >
              <span className="text-[10px] font-bold text-white drop-shadow-[0_1px_1.5px_rgba(0,0,0,0.6)]">
                第 {bf.id} 戰場
              </span>
              <span className="text-xs font-bold text-white drop-shadow-[0_1px_1.5px_rgba(0,0,0,0.6)]">{bf.name}</span>
            </button>
          ))}
        </div>
      </PuzzleShell>
    )
  }

  return (
    <PuzzleShell
      gameId="tank-battle"
      title="坦克大戰"
      subtitle={`${battlefield.name}・率先命中對方 3 次獲勝`}
      status={`您：${state.playerScore} 分　對手：${state.enemyScore} 分（先達 ${TB_WIN_HITS} 分獲勝）`}
      rulesBrief="左右移動戰車並發射砲彈，砲彈命中對方所在直線即得分，率先命中對方 3 次者獲勝。"
      solved={state.over && state.won}
      cost={12}
      onBack={onBack}
      onRestart={restart}
    >
      <div
        className="relative touch-none overflow-hidden rounded-2xl border border-border shadow-lg"
        style={{
          width: fieldWidth,
          height: fieldHeight,
          padding: 8,
          background: `linear-gradient(180deg, ${battlefield.sky} 0%, ${battlefield.ground} 55%, ${battlefield.ground} 100%)`,
        }}
      >
        {/* 戰場障礙佈置，純視覺裝飾呈現仿真立體戰場氛圍 */}
        {battlefield.layout.map(([r, c], i) => {
          const ObstacleIcon = battlefield.obstacle === "crate" ? Box : Mountain
          return (
            <div
              key={`ob${i}`}
              className="pointer-events-none absolute flex items-center justify-center rounded-md"
              style={{
                width: cellW * 0.9,
                height: cellH * 0.9,
                left: c * (cellW + gapW) + cellW * 0.05,
                top: r * (cellH + gapH) + cellH * 0.05,
                background: battlefield.obstacleColor,
                boxShadow: "inset 0 2px 2px rgba(255,255,255,0.3), inset 0 -3px 4px rgba(0,0,0,0.3), 0 2px 4px rgba(0,0,0,0.35)",
                opacity: 0.85,
              }}
            >
              <ObstacleIcon className="h-3.5 w-3.5 text-white/70" strokeWidth={2} />
            </div>
          )
        })}

        {/* 敵方戰車：車身仿真立體漸層、砲塔與砲管朝下 */}
        <div
          className="absolute flex items-center justify-center rounded-md bg-gradient-to-b from-[oklch(0.68_0.2_25)] to-[oklch(0.5_0.22_25)] shadow-[0_2px_5px_rgba(0,0,0,0.4),inset_0_2px_2px_rgba(255,255,255,0.35)]"
          style={{ width: cellW, height: cellH, left: state.enemyCol * (cellW + gapW), top: 0 }}
        >
          <div
            className="absolute rounded-full bg-[oklch(0.55_0.22_25)] shadow-[inset_0_1px_1px_rgba(255,255,255,0.4)]"
            style={{ width: cellW * 0.5, height: cellW * 0.5, top: cellH * 0.1 }}
          />
          <div className="absolute left-1/2 top-0 h-[40%] w-[14%] -translate-x-1/2 rounded-b-full bg-[oklch(0.45_0.2_25)]" />
        </div>

        {/* 玩家戰車：車身仿真立體漸層、砲塔與砲管朝上 */}
        <div
          className="absolute flex items-center justify-center rounded-md bg-gradient-to-b from-[oklch(0.72_0.18_260)] to-[oklch(0.5_0.2_260)] shadow-[0_2px_5px_rgba(0,0,0,0.4),inset_0_2px_2px_rgba(255,255,255,0.35)]"
          style={{
            width: cellW,
            height: cellH,
            left: state.playerCol * (cellW + gapW),
            top: (TB_ROWS - 1) * (cellH + gapH),
          }}
        >
          <div
            className="absolute rounded-full bg-[oklch(0.58_0.2_260)] shadow-[inset_0_1px_1px_rgba(255,255,255,0.4)]"
            style={{ width: cellW * 0.5, height: cellW * 0.5, bottom: cellH * 0.1 }}
          />
          <div className="absolute bottom-0 left-1/2 h-[40%] w-[14%] -translate-x-1/2 rounded-t-full bg-[oklch(0.42_0.2_260)]" />
        </div>

        {state.playerBullets.map((b, i) => (
          <div
            key={`p${i}`}
            className="absolute rounded-full bg-[oklch(0.85_0.18_90)] shadow-[0_0_4px_rgba(255,200,0,0.8)]"
            style={{ width: 6, height: 12, left: b.col * (cellW + gapW) + cellW / 2 - 3, top: b.row * (cellH + gapH) }}
          />
        ))}
        {state.enemyBullets.map((b, i) => (
          <div
            key={`e${i}`}
            className="absolute rounded-full bg-destructive shadow-[0_0_4px_rgba(220,40,40,0.8)]"
            style={{ width: 6, height: 12, left: b.col * (cellW + gapW) + cellW / 2 - 3, top: b.row * (cellH + gapH) }}
          />
        ))}
      </div>
      {state.over && (
        <p className={`text-center text-xs font-semibold ${state.won ? "text-primary" : "text-destructive"}`}>
          {state.won ? "恭喜獲勝！" : "挑戰失敗，點「重新開始」再選擇戰場！"}
        </p>
      )}
      <div className="grid grid-cols-3 gap-1.5">
        <button
          onClick={() => setState((s) => tbMove(s, -1))}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-bold text-muted-foreground active:scale-90"
        >
          ←
        </button>
        <button
          onClick={() => setState((s) => tbShoot(s))}
          className="flex h-10 w-14 items-center justify-center rounded-full bg-accent text-xs font-bold text-accent-foreground active:scale-90"
        >
          開火
        </button>
        <button
          onClick={() => setState((s) => tbMove(s, 1))}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-bold text-muted-foreground active:scale-90"
        >
          →
        </button>
      </div>
    </PuzzleShell>
  )
}
