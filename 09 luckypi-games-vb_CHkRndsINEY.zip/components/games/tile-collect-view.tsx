"use client"

import type { ReactNode } from "react"
import { useState } from "react"
import { PuzzleShell } from "./puzzle-shell"
import { tcTap, tcIsCovered, TRAY_SIZE, type TileState } from "@/lib/games/tile-collect"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playMoveSound, playWinSound, playLossSound } from "@/lib/games/game-audio"

export function TileCollectView({
  gameId,
  title,
  subtitle,
  rulesBrief,
  cost,
  boardBg,
  renderIcon,
  initial,
  onBack,
}: {
  gameId: string
  title: string
  subtitle: string
  rulesBrief: string
  cost: number
  boardBg: string
  renderIcon: (icon: number, size: number) => ReactNode
  initial: () => TileState
  onBack: () => void
}) {
  const { soundOn } = useLuckyPi()
  const [state, setState] = useState<TileState>(() => initial())

  const restart = () => setState(initial())

  const tap = (id: number) => {
    if (state.won || state.lost) return
    const item = state.items.find((i) => i.id === id)
    if (!item || tcIsCovered(state.items, item) || item.collected) {
      if (soundOn) playLossSound()
      return
    }
    const next = tcTap(state, id)
    setState(next)
    if (soundOn) playMoveSound()
  }

  const remaining = state.items.filter((i) => !i.collected).length

  return (
    <PuzzleShell
      gameId={gameId}
      title={title}
      subtitle={subtitle}
      status={`剩餘 ${remaining} 個　收集槽 ${state.tray.length}/${TRAY_SIZE}`}
      rulesBrief={rulesBrief}
      solved={state.won}
      cost={cost}
      onBack={onBack}
      onRestart={restart}
    >
      <div
        className="relative overflow-hidden rounded-2xl border border-border shadow-lg"
        style={{ width: 340, maxWidth: "100%", aspectRatio: "1 / 1", background: boardBg }}
      >
        {state.items
          .filter((i) => !i.collected)
          .sort((a, b) => a.layer - b.layer)
          .map((item) => {
            const covered = tcIsCovered(state.items, item)
            return (
              <button
                key={item.id}
                onClick={() => tap(item.id)}
                className="absolute flex -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-xl transition-all active:scale-90"
                style={{
                  left: `${item.x}%`,
                  top: `${item.y}%`,
                  zIndex: item.layer * 10,
                  filter: covered ? "brightness(0.55) saturate(0.7)" : "none",
                  opacity: covered ? 0.85 : 1,
                }}
              >
                {renderIcon(item.icon, 40)}
              </button>
            )
          })}
      </div>

      <div className="flex w-full max-w-[340px] justify-center gap-1 rounded-2xl border border-border bg-card p-2 shadow-md">
        {Array.from({ length: TRAY_SIZE }).map((_, i) => (
          <div
            key={i}
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-dashed border-border bg-muted/40"
          >
            {state.tray[i] !== undefined ? renderIcon(state.tray[i], 26) : null}
          </div>
        ))}
      </div>

      {state.lost && (
        <p className="text-center text-xs font-semibold text-destructive">收集槽已滿，挑戰失敗，按「重新開始」再試一次！</p>
      )}
    </PuzzleShell>
  )
}
