"use client"

import { useState } from "react"
import { Sprout, Leaf, TreePine, Home, Building2, Castle, Sparkles, Cross, Church, Landmark, Gem, Mountain, PawPrint, Bot, Package } from "lucide-react"
import { BoardShell, type PuzzleOutcome } from "./board-shell"
import {
  dealTripleTown,
  placeItem,
  useBotOn,
  storeSwap,
  ITEM_LABEL,
  SIZE,
  type ItemKind,
  type TripleTownState,
} from "@/lib/games/triple-town"
import { playMoveSound, playCaptureSound, playLossSound } from "@/lib/games/game-audio"
import { useLuckyPi } from "@/contexts/luckypi-context"

const GAME_ID = "triple-town"

const RULES =
  "6×6 棋盤，點選空格放置目前手上的道具。草地集滿 3 個會升級成灌木，灌木集滿 3 個升級成樹木，接著依序是小屋、大屋、城堡、浮空城，一路合併蓋出高級建築。水晶是萬能牌，放在有可合併鄰居的位置會自動幫忙合併，若周圍沒有可合併的物件則會變成無法再利用的岩石。棋盤上偶爾會有熊或黑熊闖入：熊每回合會往旁邊空格移動，黑熊則會隨機跳到任意空格，若把牠們的去路完全封死，牠們就會死亡變成墓碑，墓碑集滿 3 個可以升級成教堂、大教堂、最終寶箱。手上拿到機器人道具時，點選棋盤上任一物件即可將其直接清除。旁邊的儲存槽可以先把目前道具存起來，之後再換回來用，提高佈局的靈活度。棋盤被填滿且無法再放置時，遊戲結束。"

const ICON_MAP: Record<ItemKind, { Icon: typeof Sprout; className: string }> = {
  grass: { Icon: Sprout, className: "bg-[#dcefc7] text-[#4d7c2b]" },
  bush: { Icon: Leaf, className: "bg-[#c4e3a0] text-[#3f6b22]" },
  tree: { Icon: TreePine, className: "bg-[#9fd17e] text-[#2f5318]" },
  hut: { Icon: Home, className: "bg-[#e7c79a] text-[#7a4a1f]" },
  house: { Icon: Building2, className: "bg-[#d9a66c] text-[#6b3d14]" },
  castle: { Icon: Castle, className: "bg-[#b98de0] text-[#4a1d6b]" },
  floatingCastle: { Icon: Sparkles, className: "bg-[#f3c84a] text-[#6b4d05]" },
  tombstone: { Icon: Cross, className: "bg-[#c7c7cf] text-[#4a4a52]" },
  church: { Icon: Church, className: "bg-[#aab6d6] text-[#2c3a66]" },
  cathedral: { Icon: Landmark, className: "bg-[#8aa0d6] text-[#1f2d5c]" },
  treasureChest: { Icon: Gem, className: "bg-[#f5d36a] text-[#6b4d05]" },
  crystal: { Icon: Gem, className: "bg-[#a8e3e8] text-[#0f6b73]" },
  rock: { Icon: Mountain, className: "bg-[#b7b2a8] text-[#4a463f]" },
  bear: { Icon: PawPrint, className: "bg-[#c99b6a] text-[#4a2f10]" },
  ninjaBear: { Icon: PawPrint, className: "bg-[#3a3a42] text-[#e8e8ee]" },
  bot: { Icon: Bot, className: "bg-[#9fd4e0] text-[#0f4a56]" },
}

function Tile({ kind, size = "normal" }: { kind: ItemKind; size?: "normal" | "small" }) {
  const { Icon, className } = ICON_MAP[kind]
  return (
    <div
      className={`flex items-center justify-center rounded-lg ${className} ${
        size === "small" ? "h-9 w-9" : "h-full w-full"
      }`}
      style={{
        boxShadow:
          "inset 0 2px 2px rgba(255,255,255,0.55), inset 0 -3px 4px rgba(0,0,0,0.25), 0 2px 3px rgba(0,0,0,0.2)",
      }}
      title={ITEM_LABEL[kind]}
    >
      {/* 圖騰放大並加上陰影，呈現仿真立體道具的厚度感 */}
      <Icon
        className={size === "small" ? "h-5 w-5 drop-shadow-sm" : "h-7 w-7 drop-shadow-[0_2px_1.5px_rgba(0,0,0,0.35)]"}
        strokeWidth={2}
      />
    </div>
  )
}

export function TripleTownView({ onBack }: { onBack: () => void }) {
  const { soundOn } = useLuckyPi()
  const [best, setBest] = useState(0)
  const [state, setState] = useState<TripleTownState>(() => dealTripleTown())

  function applyNext(next: TripleTownState, gained: boolean) {
    setBest((b) => Math.max(b, next.best))
    setState(next)
    if (soundOn) {
      if (next.finished) playLossSound()
      else if (gained) playCaptureSound()
      else playMoveSound()
    }
  }

  function handleCellClick(r: number, c: number) {
    if (state.finished) return
    if (state.next === "bot") {
      if (!state.grid[r][c]) return
      const next = useBotOn({ ...state, best }, r, c)
      applyNext(next, false)
      return
    }
    if (state.grid[r][c]) return
    const prevScore = state.score
    const next = placeItem({ ...state, best }, r, c)
    applyNext(next, next.score > prevScore)
  }

  function handleStore() {
    if (state.finished) return
    setState(storeSwap({ ...state, best }))
  }

  const result: PuzzleOutcome = state.finished ? "loss" : null

  const status = state.finished
    ? `挑戰結束！最終分數 ${state.score}（最高紀錄 ${best}）`
    : `分數 ${state.score} ・ 最高紀錄 ${best}`

  return (
    <BoardShell
      gameId={GAME_ID}
      title="三重鎮合併"
      subtitle="合併建築，小心熊群搗亂"
      status={status}
      rulesBrief={RULES}
      result={result}
      onBack={onBack}
      onRestart={() => setState(dealTripleTown(best))}
      mode="single"
    >
      <div className="flex w-full max-w-sm flex-col items-center gap-3">
        <div className="flex w-full items-center justify-between gap-3 rounded-xl bg-muted/60 px-3 py-2">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-muted-foreground">目前道具</span>
            <Tile kind={state.next} size="small" />
            <span className="text-[11px] font-semibold text-foreground">{ITEM_LABEL[state.next]}</span>
          </div>
          <button
            onClick={handleStore}
            disabled={state.finished}
            className="flex items-center gap-1.5 rounded-full bg-background px-2.5 py-1 text-[10px] font-semibold text-foreground shadow-sm transition active:scale-95 disabled:opacity-40"
          >
            <Package className="h-3.5 w-3.5" />
            {state.store ? <Tile kind={state.store} size="small" /> : <span className="text-muted-foreground">空</span>}
            儲存槽
          </button>
        </div>

        <div className="aspect-square w-full max-w-[320px] rounded-2xl bg-[#e6ddc8] p-2">
          <div className="grid h-full w-full gap-1.5" style={{ gridTemplateColumns: `repeat(${SIZE}, 1fr)`, gridTemplateRows: `repeat(${SIZE}, 1fr)` }}>
            {state.grid.map((row, r) =>
              row.map((cell, c) => (
                <button
                  key={`${r}-${c}`}
                  onClick={() => handleCellClick(r, c)}
                  disabled={state.finished || (!cell && state.next === "bot")}
                  className={`flex items-center justify-center rounded-md transition active:scale-95 disabled:cursor-default ${
                    cell ? "" : "bg-[#f3eedd]"
                  } ${state.next === "bot" && cell ? "ring-2 ring-accent/70" : ""}`}
                >
                  {cell && <Tile kind={cell.kind} />}
                </button>
              )),
            )}
          </div>
        </div>

        <p className="text-center text-[11px] leading-relaxed text-muted-foreground">
          {state.next === "bot"
            ? "手上是機器人，點選棋盤上任一物件將其清除。"
            : "點選空格放置道具，集滿 3 個相同物件即可合併升級。"}
        </p>
      </div>
    </BoardShell>
  )
}
