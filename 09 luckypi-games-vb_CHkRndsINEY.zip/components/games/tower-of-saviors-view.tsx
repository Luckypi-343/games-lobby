"use client"

import { useState } from "react"
import { RpgMatch3View } from "./rpg-match3-view"
import { towerNew, towerAdvance } from "@/lib/games/tower-of-saviors"
import type { RmState } from "@/lib/games/rpg-match3-core"

export function TowerOfSaviorsView({ onBack }: { onBack: () => void }) {
  const [state, setState] = useState<RmState>(() => towerNew())
  return (
    <RpgMatch3View
      gameId="tower-of-saviors"
      title="救世之塔"
      subtitle="寶石消除 + 卡牌戰鬥養成，六層關卡挑戰塔頂巨龍"
      rulesBrief="交換相鄰寶石湊出 3 個以上同色連線，對應屬性的隊友就會對敵人發動攻擊，粉紅愛心可以治療全隊。擊敗所有敵人過關後，隊伍會累積經驗升級、恢復滿血前往下一關，六關全破後重新開始更高難度的循環。隊伍全滅則挑戰失敗，可以重新開始。"
      cost={10}
      state={state}
      setState={setState}
      onNewGame={towerNew}
      onAdvance={towerAdvance}
      onBack={onBack}
    />
  )
}
