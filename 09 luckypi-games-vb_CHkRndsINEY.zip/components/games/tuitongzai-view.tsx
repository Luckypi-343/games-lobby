"use client"

import { useEffect, useState } from "react"
import { CasinoTableShell } from "@/components/luckypi/casino-table-shell"
import { useLuckyPi } from "@/contexts/luckypi-context"
import { playWinSound, playLossSound } from "@/lib/games/game-audio"
import {
  tuiInitial,
  tuiSetBet,
  tuiDeal,
  tuiSettle,
  tuiReset,
  handLabel,
  DOOR_LABEL,
  BET_MIN,
  BET_MAX,
  BET_STEP,
  type DoorId,
  type Tile,
  type TuiState,
} from "@/lib/games/tuitongzai"

const HUE = 200

const RULES =
  "推筒仔使用仿真中國麻將棋子代表一筒～九筒（各4張）加白板（4張，半點），共40張。開局前先分別調整頭門、天門、尾門三個門位的押注（10～500），按「開局」後莊家與三個門位各自掀出2張牌比大小。牌型大小順序：至尊寶（雙白板）＞對子（9對～1對）＞二八槓（2筒+8筒）＞一般點數（兩張相加取個位數，白板算0.5點，9.5點最大，0點鱉十最小）。每個門位各自跟莊家比較：贏得1倍注碼（1:1），特殊牌型對子加碼4倍、至尊寶加碼10倍；點數相同時依傳統規則算莊家勝。全部結算完畢即可按「再來一局」繼續。"

// 仿真中國麻將「筒」立體牌面：點位配置、顏色與陰影配方皆對齊益智區第7台中國麻將的筒子畫法。
const TILE_RED = "#b91c1c"
const TILE_BLUE = "#1c3f8f"
const TILE_GREEN = "#146c34"

type TongDot = { x: number; y: number; core: string; ring?: string; big?: boolean; ringSplit?: number }

const TONG_LAYOUTS: Record<number, TongDot[]> = {
  1: [{ x: 50, y: 50, core: TILE_RED, ring: TILE_GREEN, big: true, ringSplit: 40 }],
  2: [
    { x: 50, y: 28, core: TILE_BLUE },
    { x: 50, y: 72, core: TILE_GREEN },
  ],
  3: [
    { x: 50, y: 18, core: TILE_BLUE },
    { x: 50, y: 50, core: TILE_RED },
    { x: 50, y: 82, core: TILE_GREEN },
  ],
  4: [
    { x: 26, y: 22, core: TILE_BLUE },
    { x: 74, y: 22, core: TILE_GREEN },
    { x: 26, y: 78, core: TILE_GREEN },
    { x: 74, y: 78, core: TILE_BLUE },
  ],
  5: [
    { x: 26, y: 22, core: TILE_BLUE },
    { x: 74, y: 22, core: TILE_GREEN },
    { x: 50, y: 50, core: TILE_RED },
    { x: 26, y: 78, core: TILE_GREEN },
    { x: 74, y: 78, core: TILE_BLUE },
  ],
  6: [
    { x: 32, y: 20, core: TILE_BLUE },
    { x: 68, y: 20, core: TILE_BLUE },
    { x: 30, y: 55, core: TILE_RED },
    { x: 70, y: 55, core: TILE_RED },
    { x: 30, y: 85, core: TILE_RED },
    { x: 70, y: 85, core: TILE_RED },
  ],
  7: [
    { x: 22, y: 14, core: TILE_GREEN },
    { x: 50, y: 26, core: TILE_GREEN },
    { x: 78, y: 38, core: TILE_GREEN },
    { x: 28, y: 64, core: TILE_RED },
    { x: 72, y: 64, core: TILE_RED },
    { x: 28, y: 90, core: TILE_RED },
    { x: 72, y: 90, core: TILE_RED },
  ],
  8: [
    { x: 28, y: 12, core: TILE_BLUE },
    { x: 72, y: 12, core: TILE_BLUE },
    { x: 28, y: 37, core: TILE_BLUE },
    { x: 72, y: 37, core: TILE_BLUE },
    { x: 28, y: 63, core: TILE_BLUE },
    { x: 72, y: 63, core: TILE_BLUE },
    { x: 28, y: 88, core: TILE_BLUE },
    { x: 72, y: 88, core: TILE_BLUE },
  ],
  9: [
    { x: 22, y: 16, core: TILE_GREEN },
    { x: 50, y: 16, core: TILE_GREEN },
    { x: 78, y: 16, core: TILE_GREEN },
    { x: 22, y: 50, core: TILE_RED },
    { x: 50, y: 50, core: TILE_RED },
    { x: 78, y: 50, core: TILE_RED },
    { x: 22, y: 84, core: TILE_BLUE },
    { x: 50, y: 84, core: TILE_BLUE },
    { x: 78, y: 84, core: TILE_BLUE },
  ],
}

const TILE_BASE =
  "relative flex items-center justify-center overflow-hidden rounded-[5px] border border-amber-950/60 bg-gradient-to-b from-white via-amber-50 to-amber-100 shadow-[0_3px_0_rgba(120,80,20,0.55),0_4px_5px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.9)]"

function TongTile({ rank, baseSize }: { rank: number; baseSize: number }) {
  const layout = TONG_LAYOUTS[rank] ?? []
  return (
    <>
      {layout.map((d, i) => {
        const ring = d.ring ?? d.core
        const size = d.big ? Math.round(baseSize * 1.9) : baseSize
        const split = d.ringSplit ?? 55
        return (
          <span
            key={i}
            className="absolute rounded-full"
            style={{
              left: `${d.x}%`,
              top: `${d.y}%`,
              width: size,
              height: size,
              transform: "translate(-50%, -50%)",
              background: `radial-gradient(circle at 32% 26%, rgba(255,255,255,0.95), rgba(255,255,255,0.05) 38%, transparent 55%), radial-gradient(circle, ${d.core} 0 ${split}%, ${ring} ${split + 1}% 100%)`,
              boxShadow: "0 1px 1.5px rgba(0,0,0,0.4), inset 0 1px 1px rgba(255,255,255,0.35)",
            }}
          />
        )
      })}
    </>
  )
}

function TileFace({ tile, faceDown, size = "md" }: { tile: Tile | null; faceDown?: boolean; size?: "sm" | "md" | "lg" }) {
  const dim = size === "lg" ? "h-20 w-14" : size === "md" ? "h-16 w-12" : "h-12 w-9"
  const baseSize = size === "lg" ? 11 : size === "md" ? 9 : 7
  const isBlank = tile?.rank === 0
  if (faceDown || !tile) {
    return (
      <div
        className={`relative flex shrink-0 items-center justify-center overflow-hidden rounded-[5px] border border-emerald-950/70 bg-gradient-to-b from-emerald-800 via-emerald-900 to-emerald-950 shadow-[0_3px_0_rgba(0,0,0,0.5),0_4px_5px_rgba(0,0,0,0.4)] ${dim}`}
      />
    )
  }
  return (
    <div className={`${TILE_BASE} ${dim}`}>
      {isBlank ? (
        <span className="text-[10px] font-bold tracking-widest text-muted-foreground/70">白板</span>
      ) : (
        <TongTile rank={tile.rank} baseSize={baseSize} />
      )}
    </div>
  )
}

function DoorBetControl({ label, value, onChange, disabled }: { label: string; value: number; onChange: (v: number) => void; disabled: boolean }) {
  return (
    <div className="flex flex-1 flex-col items-center gap-1 rounded-xl border border-border/60 bg-card/70 p-2">
      <span className="text-xs font-semibold text-muted-foreground">{label}</span>
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          disabled={disabled}
          onClick={() => onChange(Math.max(BET_MIN, value - BET_STEP))}
          className="flex h-7 w-7 items-center justify-center rounded-full bg-muted font-bold disabled:opacity-40"
        >
          −
        </button>
        <span className="w-12 text-center font-mono text-sm font-bold">{value}</span>
        <button
          type="button"
          disabled={disabled}
          onClick={() => onChange(Math.min(BET_MAX, value + BET_STEP))}
          className="flex h-7 w-7 items-center justify-center rounded-full bg-muted font-bold disabled:opacity-40"
        >
          +
        </button>
      </div>
    </div>
  )
}

export function TuiTongZaiView({ onHome, onLobby }: { onHome: () => void; onLobby: () => void }) {
  const { soundOn, spendCoins, creditWin } = useLuckyPi()
  const [state, setState] = useState<TuiState>(tuiInitial)
  const [settled, setSettled] = useState(false)

  const totalBet = state.doors.head.bet + state.doors.sky.bet + state.doors.tail.bet

  function handleDeal() {
    if (state.phase !== "betting") return
    if (!spendCoins(totalBet)) return
    setSettled(false)
    const dealt = tuiDeal(state)
    setState(dealt)
    window.setTimeout(() => {
      setState((s) => tuiSettle(s))
    }, 900)
  }

  // 結算一次性發錢，避免重複入帳。
  useEffect(() => {
    if (state.phase !== "settled" || settled) return
    setSettled(true)
    const doors = Object.values(state.doors)
    const anyWin = doors.some((d) => d.result === "win")
    const totalReturn = doors.reduce((sum, d) => sum + (d.result === "win" ? d.bet + d.payout : 0), 0)
    if (soundOn) {
      if (anyWin) playWinSound()
      else playLossSound()
    }
    if (totalReturn > 0) creditWin(totalReturn)
  }, [state.phase, state.doors, settled, soundOn, creditWin])

  function handleNext() {
    setState((s) => tuiReset(s))
  }

  return (
    <CasinoTableShell
      title="推筒仔"
      rules={RULES}
      hue={HUE}
      bet={totalBet}
      betMin={BET_MIN}
      betMax={BET_MAX}
      betStep={BET_STEP}
      betLocked={state.phase !== "betting"}
      onBetChange={() => {}}
      onHome={onHome}
      onLobby={onLobby}
      hideBetBar
    >
      <div className="flex w-full flex-col items-center gap-4 px-3 pb-4">
        <div className="flex flex-col items-center gap-1">
          <span className="text-xs font-semibold text-muted-foreground">莊家</span>
          <div className="flex gap-1.5">
            <TileFace tile={state.bankerTiles?.[0] ?? null} faceDown={state.phase === "betting"} size="lg" />
            <TileFace tile={state.bankerTiles?.[1] ?? null} faceDown={state.phase === "betting"} size="lg" />
          </div>
          {state.bankerHand && <span className="text-xs font-bold text-amber-500">{handLabel(state.bankerHand)}</span>}
        </div>

        <div className="grid w-full grid-cols-3 gap-2">
          {(["head", "sky", "tail"] as DoorId[]).map((id) => {
            const door = state.doors[id]
            return (
              <div key={id} className="flex flex-col items-center gap-1.5 rounded-xl border border-border/60 bg-card/50 p-2">
                <span className="text-xs font-bold">{DOOR_LABEL[id]}</span>
                <div className="flex gap-1">
                  <TileFace tile={door.tiles?.[0] ?? null} faceDown={state.phase === "betting"} />
                  <TileFace tile={door.tiles?.[1] ?? null} faceDown={state.phase === "betting"} />
                </div>
                {door.hand && <span className="text-center text-[10px] leading-tight font-semibold">{handLabel(door.hand)}</span>}
                {door.result && (
                  <span className={`text-sm font-black ${door.result === "win" ? "text-emerald-500" : "text-rose-500"}`}>
                    {door.result === "win" ? `+${door.payout}` : door.payout}
                  </span>
                )}
              </div>
            )
          })}
        </div>

        {state.phase === "betting" && (
          <div className="flex w-full gap-2">
            {(["head", "sky", "tail"] as DoorId[]).map((id) => (
              <DoorBetControl
                key={id}
                label={DOOR_LABEL[id]}
                value={state.doors[id].bet}
                disabled={state.phase !== "betting"}
                onChange={(v) => setState((s) => tuiSetBet(s, id, v))}
              />
            ))}
          </div>
        )}

        <div className="flex w-full justify-center">
          {state.phase === "betting" ? (
            <button
              type="button"
              onClick={handleDeal}
              className="rounded-full px-8 py-3 text-base font-black text-white shadow-lg"
              style={{ background: `oklch(0.55 0.18 ${HUE})` }}
            >
              開局（總押注 {totalBet}）
            </button>
          ) : state.phase === "revealed" ? (
            <span className="rounded-full bg-muted px-6 py-2 text-sm font-semibold text-muted-foreground">結算中…</span>
          ) : (
            <button
              type="button"
              onClick={handleNext}
              className="rounded-full px-8 py-3 text-base font-black text-white shadow-lg"
              style={{ background: `oklch(0.55 0.18 ${HUE})` }}
            >
              再來一局
            </button>
          )}
        </div>
      </div>
    </CasinoTableShell>
  )
}
