// 博奕區第53台「象棋麻將」— 用象棋棋子取代麻將牌的湊牌對戰桌。
// 1 對眼 + 1 組（順子或刻子）＝ 5 顆棋子胡牌。莊家開局持5顆先打，閒家持4顆，
// 之後每家輪到自己時可以「吃」對方剛打出的那顆，或自己「摸」一顆，湊成5顆後沒胡牌就要選1顆打出（換牌或棄牌），手上維持4顆，接著換下一家，依此類推。

export type PieceColor = "red" | "black"

// rank 數字越小代表階級越高（帥/將最高），僅用於判斷「特種順」帥-仕-相／將-士-象。
export interface PieceKind {
  key: string
  label: string
  color: PieceColor
  rank: number
  count: number
}

// 俥-傌-炮／车-马-包 另外用 line 分組，讓一般順子只能在同一條「俥傌炮」或「兵」序列裡湊。
export const PIECE_KINDS: PieceKind[] = [
  { key: "shuai", label: "帥", color: "red", rank: 0, count: 1 },
  { key: "shi", label: "仕", color: "red", rank: 1, count: 2 },
  { key: "xiang", label: "相", color: "red", rank: 2, count: 2 },
  { key: "ju", label: "俥", color: "red", rank: 3, count: 2 },
  { key: "ma", label: "傌", color: "red", rank: 3, count: 2 },
  { key: "pao", label: "炮", color: "red", rank: 3, count: 2 },
  { key: "bing", label: "兵", color: "red", rank: 4, count: 5 },
  { key: "jiang", label: "將", color: "black", rank: 0, count: 1 },
  { key: "shiH", label: "士", color: "black", rank: 1, count: 2 },
  { key: "xiangH", label: "象", color: "black", rank: 2, count: 2 },
  { key: "che", label: "車", color: "black", rank: 3, count: 2 },
  { key: "maH", label: "馬", color: "black", rank: 3, count: 2 },
  { key: "bao", label: "包", color: "black", rank: 3, count: 2 },
  { key: "zu", label: "卒", color: "black", rank: 4, count: 5 },
]

// 特種順：同色之「帥-仕-相」／「將-士-象」。一般順子：同色之「俥-傌-炮」／「車-馬-包」。
const SPECIAL_RUNS: string[][] = [
  ["shuai", "shi", "xiang"],
  ["jiang", "shiH", "xiangH"],
]
const NORMAL_RUNS: string[][] = [
  ["ju", "ma", "pao"],
  ["che", "maH", "bao"],
]
const ALL_RUNS = [...SPECIAL_RUNS, ...NORMAL_RUNS]

export interface Piece {
  id: string
  kindKey: string
  label: string
  color: PieceColor
}

function buildDeck(): Piece[] {
  const deck: Piece[] = []
  for (const kind of PIECE_KINDS) {
    for (let i = 0; i < kind.count; i++) {
      deck.push({ id: `${kind.key}-${i}`, kindKey: kind.key, label: kind.label, color: kind.color })
    }
  }
  return deck
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

export type WinKind = "five-soldiers" | "same-color" | "mixed"

export interface WinInfo {
  kind: WinKind
  baseMultiplier: number
  label: string
}

/** 檢查 5 顆棋子是否能湊成「1 對眼 + 1 組（順子或刻子）」，若可以回傳贏法資訊。 */
export function evaluateHand(pieces: Piece[]): WinInfo | null {
  if (pieces.length !== 5) return null
  // 嘗試每一種「哪兩顆當眼」的組合，剩下 3 顆驗證是否為合法的一組。
  for (let i = 0; i < 5; i++) {
    for (let j = i + 1; j < 5; j++) {
      if (pieces[i].kindKey !== pieces[j].kindKey) continue
      const rest = pieces.filter((_, idx) => idx !== i && idx !== j)
      const info = evaluateSet(rest, pieces[i].kindKey)
      if (info) return info
    }
  }
  return null
}

function evaluateSet(rest: Piece[], eyeKey: string): WinInfo | null {
  if (rest.length !== 3) return null
  const keys = rest.map((p) => p.kindKey)
  // 刻子：三顆完全相同
  const isTriplet = keys[0] === keys[1] && keys[1] === keys[2]
  // 順子／特種順：三顆剛好等於某一組固定序列（不分順序）
  const sortedKeys = [...keys].sort().join(",")
  const isRun = ALL_RUNS.some((run) => [...run].sort().join(",") === sortedKeys)
  if (!isTriplet && !isRun) return null

  const allPieces = [...rest]
  const allSameColor = allPieces.every((p) => p.color === allPieces[0].color)

  // 5 兵或 5 卒：胡牌棋子裡，眼睛跟組合全部都是「兵」或全部都是「卒」（共用到 5 顆同一種腳兵）。
  if (isTriplet && (keys[0] === "bing" || keys[0] === "zu") && eyeKey === keys[0]) {
    return { kind: "five-soldiers", baseMultiplier: 5, label: "5兵／5卒" }
  }
  if (allSameColor) {
    return { kind: "same-color", baseMultiplier: 3, label: isTriplet ? "同色刻子" : "同色一對＋順子" }
  }
  return { kind: "mixed", baseMultiplier: 2, label: isTriplet ? "混合刻子" : "混合一對＋順子" }
}

/** 給定 4 顆手牌，從 6 種階級中嘗試每一種候選棋子，找出摸/吃哪一顆可以讓 5 顆湊成胡牌。 */
function findWinningFifth(fourPieces: Piece[]): Piece | null {
  if (fourPieces.length !== 4) return null
  for (const kind of PIECE_KINDS) {
    const candidate: Piece = { id: "probe", kindKey: kind.key, label: kind.label, color: kind.color }
    if (evaluateHand([...fourPieces, candidate])) return candidate
  }
  return null
}

export type Seat = "player" | "bot"
export type Phase = "idle" | "playing" | "resolved"
// stage: "react" = 輪到 turn 這家，要選擇吃牌或摸牌；"discard" = turn 這家手上已滿5顆，要選1顆打出。
export type Stage = "react" | "discard"
export type ResultType =
  | "player-self-draw"
  | "player-claim"
  | "bot-self-draw"
  | "bot-claim"
  | "bot-deal-win"
  | "draw-out"

export interface MahjongState {
  phase: Phase
  turn: Seat
  stage: Stage
  deck: Piece[]
  playerHand: Piece[]
  botHand: Piece[]
  discard: Piece[]
  lastDiscard: Piece | null
  lastDiscardBy: Seat | null
  drawnPiece: Piece | null // 本輪剛摸到或吃進、尚未打出的那顆
  result: ResultType | null
  winInfo: WinInfo | null
  winMultiplier: number
  log: string[]
}

export function mjInitial(): MahjongState {
  return {
    phase: "idle",
    turn: "bot",
    stage: "discard",
    deck: [],
    playerHand: [],
    botHand: [],
    discard: [],
    lastDiscard: null,
    lastDiscardBy: null,
    drawnPiece: null,
    result: null,
    winInfo: null,
    winMultiplier: 0,
    log: [],
  }
}

function pushLog(state: MahjongState, line: string): MahjongState {
  return { ...state, log: [...state.log.slice(-5), line] }
}

/** 開局：莊家（電腦）摸5顆、閒家（玩家）摸4顆，莊家先打出1顆。 */
export function mjDeal(): MahjongState {
  const deck = shuffle(buildDeck())
  const botHand = deck.splice(0, 5)
  const playerHand = deck.splice(0, 4)

  // 發牌就胡：莊家一開始摸到的5顆，若本身就湊成胡牌牌型，直接開胡，倍數固定5倍，不再打牌。
  const dealWin = evaluateHand(botHand)
  if (dealWin) {
    return pushLog(
      {
        phase: "resolved",
        turn: "bot",
        stage: "discard",
        deck,
        playerHand,
        botHand,
        discard: [],
        lastDiscard: null,
        lastDiscardBy: null,
        drawnPiece: null,
        result: "bot-deal-win",
        winInfo: dealWin,
        winMultiplier: 5,
        log: [],
      },
      `發牌就胡！莊家開局直接湊成「${dealWin.label}」，彩金 ×5！`,
    )
  }

  // 莊家先打：找出對自己最沒用的一顆直接打出（簡化 AI）。
  const dropIdx = pickDiscardIndex(botHand)
  const discarded = botHand[dropIdx]
  const remainingBot = botHand.filter((_, i) => i !== dropIdx)

  return pushLog(
    {
      phase: "playing",
      turn: "player",
      stage: "react",
      deck,
      playerHand,
      botHand: remainingBot,
      discard: [discarded],
      lastDiscard: discarded,
      lastDiscardBy: "bot",
      drawnPiece: null,
      result: null,
      winInfo: null,
      winMultiplier: 0,
      log: [],
    },
    `開局：莊家持5顆、玩家持4顆。莊家先打出「${discarded.label}」。`,
  )
}

/** 簡化 AI：從 5 顆棋子中選出留著最沒幫助的那顆打出。 */
function pickDiscardIndex(hand5: Piece[]): number {
  const scored = hand5.map((p, idx) => {
    let score = 0
    const others = hand5.filter((_, i) => i !== idx)
    if (others.some((o) => o.kindKey === p.kindKey)) score += 2
    if (others.filter((o) => o.color === p.color).length >= 3) score += 1
    const inRun = ALL_RUNS.some((run) => run.includes(p.kindKey) && others.some((o) => run.includes(o.kindKey)))
    if (inRun) score += 1
    return { idx, score }
  })
  scored.sort((a, b) => a.score - b.score)
  return scored[0].idx
}

function seatHand(state: MahjongState, seat: Seat): Piece[] {
  return seat === "player" ? state.playerHand : state.botHand
}

function withSeatHand(state: MahjongState, seat: Seat, hand: Piece[]): MahjongState {
  return seat === "player" ? { ...state, playerHand: hand } : { ...state, botHand: hand }
}

/** 目前輪到的這家，是否可以吃對方剛打出的那顆（有棄牌可吃，且輪到自己、尚未摸/吃）。 */
export function canEat(state: MahjongState): boolean {
  return (
    state.phase === "playing" &&
    state.stage === "react" &&
    !!state.lastDiscard &&
    state.lastDiscardBy !== state.turn &&
    seatHand(state, state.turn).length === 4
  )
}

/** 吃牌：把對方剛打出的那顆收進手牌（變5顆），立刻判斷是否胡牌。 */
export function mjEat(state: MahjongState, actor: Seat): MahjongState {
  if (!canEat(state) || state.turn !== actor) return state
  const piece = state.lastDiscard!
  const hand5 = [...seatHand(state, actor), piece]
  const win = evaluateHand(hand5)
  if (win) {
    const result: ResultType = actor === "player" ? "player-claim" : "bot-claim"
    const next = withSeatHand(
      { ...state, phase: "resolved", result, winInfo: win, winMultiplier: win.baseMultiplier },
      actor,
      hand5,
    )
    return pushLog(
      next,
      actor === "player"
        ? `吃牌胡！用對方打出的「${piece.label}」湊成「${win.label}」，彩金 ×${win.baseMultiplier}！`
        : `電腦吃牌胡，湊成「${win.label}」，莊家獲勝。`,
    )
  }
  const next = withSeatHand({ ...state, stage: "discard", drawnPiece: piece }, actor, seatHand(state, actor))
  return pushLog(withSeatHand(next, actor, hand5.filter((p) => p.id !== piece.id)), actor === "player" ? `吃進「${piece.label}」，請選1顆打出。` : `電腦吃進「${piece.label}」。`)
}

/** 摸牌：從牌堆摸1顆進手牌（變5顆），立刻判斷是否胡牌。 */
export function mjDraw(state: MahjongState, actor: Seat): MahjongState {
  if (state.phase !== "playing" || state.stage !== "react" || state.turn !== actor) return state
  if (state.deck.length === 0) {
    return pushLog({ ...state, phase: "resolved", result: "draw-out" }, "牌堆已摸完，流局退回押注。")
  }
  const deck = [...state.deck]
  const piece = deck.shift()!
  const hand5 = [...seatHand(state, actor), piece]
  const win = evaluateHand(hand5)
  if (win) {
    const result: ResultType = actor === "player" ? "player-self-draw" : "bot-self-draw"
    const multiplier = win.baseMultiplier + 1
    const next = withSeatHand(
      { ...state, deck, phase: "resolved", result, winInfo: win, winMultiplier: multiplier },
      actor,
      hand5,
    )
    return pushLog(
      next,
      actor === "player"
        ? `自摸！湊成「${win.label}」，彩金 ×${multiplier}！`
        : `電腦自摸，湊成「${win.label}」，莊家獲勝。`,
    )
  }
  return pushLog({ ...state, deck, stage: "discard", drawnPiece: piece }, actor === "player" ? `摸進「${piece.label}」，請選1顆打出。` : `電腦摸進一顆。`)
}

/** 打出一顆（含剛摸/吃到的那顆），手牌維持4顆，換對方行動。 */
export function mjDiscard(state: MahjongState, actor: Seat, pieceId: string): MahjongState {
  if (state.phase !== "playing" || state.stage !== "discard" || state.turn !== actor || !state.drawnPiece) return state
  const hand5 = [...seatHand(state, actor), state.drawnPiece]
  const idx = hand5.findIndex((p) => p.id === pieceId)
  if (idx === -1) return state
  const discarded = hand5[idx]
  const hand4 = hand5.filter((_, i) => i !== idx)
  const next = withSeatHand(
    {
      ...state,
      drawnPiece: null,
      stage: "react",
      turn: actor === "player" ? "bot" : "player",
      discard: [...state.discard, discarded],
      lastDiscard: discarded,
      lastDiscardBy: actor,
    },
    actor,
    hand4,
  )
  return pushLog(next, actor === "player" ? `玩家打出「${discarded.label}」。` : `電腦打出「${discarded.label}」。`)
}

/** 電腦自動行動：輪到電腦時，自動判斷要吃牌還是摸牌，再自動判斷打哪一顆。 */
export function mjBotAct(state: MahjongState): MahjongState {
  if (state.phase !== "playing" || state.turn !== "bot") return state

  if (state.stage === "react") {
    // 電腦判斷：吃牌能不能直接胡牌，能就吃；不能的話優先吃進湊對/湊色有幫助的牌，否則摸牌。
    let working = state
    if (canEat(state)) {
      const piece = state.lastDiscard!
      const hand5 = [...state.botHand, piece]
      const wouldWin = evaluateHand(hand5) !== null
      const helpful =
        state.botHand.some((p) => p.kindKey === piece.kindKey) ||
        ALL_RUNS.some((run) => run.includes(piece.kindKey) && state.botHand.some((p) => run.includes(p.kindKey)))
      if (wouldWin || helpful) {
        working = mjEat(state, "bot")
      } else {
        working = mjDraw(state, "bot")
      }
    } else {
      working = mjDraw(state, "bot")
    }
    if (working.phase === "resolved" || working.stage !== "discard") return working
    return mjBotAct(working)
  }

  // stage === "discard"：電腦手上5顆（含 drawnPiece），選出最沒用的一顆打出。
  if (!state.drawnPiece) return state
  const hand5 = [...state.botHand, state.drawnPiece]
  const dropIdx = pickDiscardIndex(hand5)
  return mjDiscard(state, "bot", hand5[dropIdx].id)
}

export const BET_MIN = 10
export const BET_MAX = 500
export const BET_STEP = 10
