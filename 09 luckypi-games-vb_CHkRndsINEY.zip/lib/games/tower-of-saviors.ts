// 救世之塔 — 寶石消除 + 簡化版卡牌戰鬥養成
import { rmNewBoard, rmGrantStageExp, type RmState, type RmCharacter, type RmEnemy } from "./rpg-match3-core"

const BASE_PARTY: Omit<RmCharacter, "hp">[] = [
  { id: "paladin", name: "聖騎士", element: 0, maxHp: 120, atk: 22, level: 1, exp: 0 },
  { id: "priest", name: "神官", element: 5 as 0, maxHp: 100, atk: 14, level: 1, exp: 0 },
  { id: "assassin", name: "暗影刺客", element: 4, maxHp: 90, atk: 26, level: 1, exp: 0 },
]

const ENEMY_NAMES = ["沼澤哥布林", "熔岩魔像", "冰封巫妖", "暗影石像鬼", "光輝守衛", "塔頂巨龍"]

function makeEnemy(stage: number, slot: number): RmEnemy {
  const element = ((stage + slot) % 5) as 0
  const scale = 1 + stage * 0.35
  return {
    id: `e${stage}-${slot}`,
    name: ENEMY_NAMES[(stage + slot) % ENEMY_NAMES.length],
    element,
    maxHp: Math.round(140 * scale),
    hp: Math.round(140 * scale),
    atk: Math.round(16 * scale),
    turnsToAttack: 3,
    attackIn: 3,
  }
}

export function towerNewStage(stage: number, party?: RmCharacter[]): RmState {
  const count = stage >= 4 ? 3 : stage >= 2 ? 2 : 1
  const enemies = Array.from({ length: count }, (_, i) => makeEnemy(stage, i))
  const basedParty = (party ?? BASE_PARTY.map((p) => ({ ...p, hp: p.maxHp }))).map((p) => ({
    ...p,
    hp: p.maxHp,
  }))
  return {
    grid: rmNewBoard(),
    party: basedParty,
    enemies,
    enemyIndex: 0,
    stage,
    maxStage: 6,
    log: [`第 ${stage} 關：${enemies.map((e) => e.name).join("、")} 擋路！`],
    gold: 0,
    resources: { wood: 0, stone: 0, food: 0 },
    cleared: false,
    defeated: false,
    lastDamage: 0,
  }
}

export function towerNew(): RmState {
  return towerNewStage(1)
}

export function towerAdvance(state: RmState): RmState {
  const leveled = rmGrantStageExp(state)
  if (leveled.stage >= leveled.maxStage) {
    return towerNewStage(1, leveled.party)
  }
  return towerNewStage(leveled.stage + 1, leveled.party)
}
