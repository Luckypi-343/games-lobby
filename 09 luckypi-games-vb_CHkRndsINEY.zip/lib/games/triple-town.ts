export type ItemKind =
  | "grass"
  | "bush"
  | "tree"
  | "hut"
  | "house"
  | "castle"
  | "floatingCastle"
  | "tombstone"
  | "church"
  | "cathedral"
  | "treasureChest"
  | "crystal"
  | "rock"
  | "bear"
  | "ninjaBear"
  | "bot"

export interface Cell {
  kind: ItemKind
}

export interface TripleTownState {
  grid: (Cell | null)[][]
  next: ItemKind
  store: ItemKind | null
  score: number
  best: number
  finished: boolean
  message: string
  lastMerged: Array<{ r: number; c: number }>
}

export const SIZE = 6

const GRASS_CHAIN: ItemKind[] = ["grass", "bush", "tree", "hut", "house", "castle", "floatingCastle"]
const TOMB_CHAIN: ItemKind[] = ["tombstone", "church", "cathedral", "treasureChest"]

const MERGE_SCORE: Partial<Record<ItemKind, number>> = {
  bush: 10,
  tree: 30,
  hut: 100,
  house: 300,
  castle: 1000,
  floatingCastle: 3000,
  church: 50,
  cathedral: 200,
  treasureChest: 800,
}

export const ITEM_LABEL: Record<ItemKind, string> = {
  grass: "草地",
  bush: "灌木",
  tree: "樹木",
  hut: "小屋",
  house: "大屋",
  castle: "城堡",
  floatingCastle: "浮空城",
  tombstone: "墓碑",
  church: "教堂",
  cathedral: "大教堂",
  treasureChest: "寶箱",
  crystal: "水晶",
  rock: "岩石",
  bear: "熊",
  ninjaBear: "黑熊",
  bot: "機器人",
}

function nextInChain(kind: ItemKind): ItemKind | null {
  const gi = GRASS_CHAIN.indexOf(kind)
  if (gi >= 0 && gi < GRASS_CHAIN.length - 1) return GRASS_CHAIN[gi + 1]
  const ti = TOMB_CHAIN.indexOf(kind)
  if (ti >= 0 && ti < TOMB_CHAIN.length - 1) return TOMB_CHAIN[ti + 1]
  return null
}

function isMergeable(kind: ItemKind): boolean {
  return GRASS_CHAIN.includes(kind) || TOMB_CHAIN.includes(kind)
}

function drawNext(): ItemKind {
  const r = Math.random()
  if (r < 0.78) return "grass"
  if (r < 0.94) return "crystal"
  return "bot"
}

function emptyCells(grid: (Cell | null)[][]): Array<{ r: number; c: number }> {
  const out: Array<{ r: number; c: number }> = []
  for (let r = 0; r < SIZE; r++) for (let c = 0; c < SIZE; c++) if (!grid[r][c]) out.push({ r, c })
  return out
}

function neighbors(r: number, c: number): Array<{ r: number; c: number }> {
  return [
    { r: r - 1, c },
    { r: r + 1, c },
    { r, c: c - 1 },
    { r, c: c + 1 },
  ].filter((p) => p.r >= 0 && p.r < SIZE && p.c >= 0 && p.c < SIZE)
}

export function dealTripleTown(best = 0): TripleTownState {
  const grid: (Cell | null)[][] = Array.from({ length: SIZE }, () => Array.from({ length: SIZE }, () => null))
  return {
    grid,
    next: "grass",
    store: null,
    score: 0,
    best,
    finished: false,
    message: "點選空格放置目前的道具，集滿 3 個相同物件即可合併升級！",
    lastMerged: [],
  }
}

function groupOf(grid: (Cell | null)[][], r: number, c: number, kind: ItemKind): Array<{ r: number; c: number }> {
  const seen = new Set<string>()
  const stack = [{ r, c }]
  const group: Array<{ r: number; c: number }> = []
  while (stack.length) {
    const cur = stack.pop()!
    const key = `${cur.r},${cur.c}`
    if (seen.has(key)) continue
    seen.add(key)
    const cell = grid[cur.r][cur.c]
    if (!cell || cell.kind !== kind) continue
    group.push(cur)
    for (const n of neighbors(cur.r, cur.c)) {
      if (!seen.has(`${n.r},${n.c}`)) stack.push(n)
    }
  }
  return group
}

/** Resolves cascading merges starting at a placed/upgraded cell. Mutates grid in place. Returns total score gained + merged coords touched. */
function resolveMerges(
  grid: (Cell | null)[][],
  start: { r: number; c: number },
): { gained: number; touched: Array<{ r: number; c: number }> } {
  let gained = 0
  const touched: Array<{ r: number; c: number }> = []
  let queue = [start]
  const guard = { n: 0 }
  while (queue.length && guard.n < 40) {
    guard.n++
    const { r, c } = queue.shift()!
    const cell = grid[r][c]
    if (!cell || !isMergeable(cell.kind)) continue
    const group = groupOf(grid, r, c, cell.kind)
    if (group.length >= 3) {
      const upgraded = nextInChain(cell.kind)
      for (const g of group) grid[g.r][g.c] = null
      if (upgraded) {
        grid[r][c] = { kind: upgraded }
        gained += (MERGE_SCORE[upgraded] ?? 0) * Math.max(1, group.length - 2)
        touched.push({ r, c })
        queue.push({ r, c })
      }
    }
  }
  return { gained, touched }
}

/** Places the current "next" item (grass or crystal) at an empty cell. */
export function placeItem(state: TripleTownState, r: number, c: number): TripleTownState {
  if (state.finished) return state
  if (state.next === "bot") return state
  if (state.grid[r][c]) return state

  const grid = state.grid.map((row) => row.map((cell) => (cell ? { ...cell } : null)))
  let gained = 0
  let touched: Array<{ r: number; c: number }> = []
  let message = state.message

  if (state.next === "crystal") {
    const neigh = neighbors(r, c)
      .map((n) => grid[n.r][n.c])
      .filter((cell): cell is Cell => !!cell && isMergeable(cell.kind))
    if (neigh.length === 0) {
      grid[r][c] = { kind: "rock" }
      message = "水晶周圍沒有可合併的物件，變成了岩石。"
    } else {
      const best = neigh.reduce((a, b) => (GRASS_CHAIN.concat(TOMB_CHAIN).indexOf(a.kind) >= GRASS_CHAIN.concat(TOMB_CHAIN).indexOf(b.kind) ? a : b))
      grid[r][c] = { kind: best.kind }
      const res = resolveMerges(grid, { r, c })
      gained = res.gained
      touched = res.touched
      message = gained > 0 ? "水晶幫忙湊成了合併！" : "水晶暫時化身為鄰近物件。"
    }
  } else {
    grid[r][c] = { kind: "grass" }
    const res = resolveMerges(grid, { r, c })
    gained = res.gained
    touched = res.touched
    if (gained > 0) message = "合併成功！"
  }

  return finishTurn({ ...state, grid, score: state.score + gained, lastMerged: touched, message })
}

/** Uses the bot item to remove an existing tile. */
export function useBotOn(state: TripleTownState, r: number, c: number): TripleTownState {
  if (state.finished || state.next !== "bot") return state
  if (!state.grid[r][c]) return state
  const grid = state.grid.map((row) => row.map((cell) => (cell ? { ...cell } : null)))
  grid[r][c] = null
  return finishTurn({ ...state, grid, message: "機器人清除了該格物件。" })
}

export function storeSwap(state: TripleTownState): TripleTownState {
  if (state.finished) return state
  if (state.store === null) {
    return { ...state, store: state.next, next: drawNext(), message: "已將道具收進儲存槽。" }
  }
  return { ...state, store: state.next, next: state.store, message: "已跟儲存槽互換道具。" }
}

function hazardPhase(grid: (Cell | null)[][]): { grid: (Cell | null)[][]; gained: number; message: string | null } {
  let gained = 0
  let message: string | null = null
  const next = grid.map((row) => row.map((cell) => (cell ? { ...cell } : null)))

  // move existing bears
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const cell = next[r][c]
      if (!cell || (cell.kind !== "bear" && cell.kind !== "ninjaBear")) continue
      const empties = emptyCells(next)
      if (cell.kind === "ninjaBear") {
        if (empties.length === 0) {
          next[r][c] = { kind: "tombstone" }
          message = "黑熊無路可逃，變成了墓碑。"
          continue
        }
        const pick = empties[Math.floor(Math.random() * empties.length)]
        next[r][c] = null
        next[pick.r][pick.c] = { kind: "ninjaBear" }
      } else {
        const openNeighbors = neighbors(r, c).filter((n) => !next[n.r][n.c])
        if (openNeighbors.length === 0) {
          next[r][c] = { kind: "tombstone" }
          message = "熊被困住了，變成了墓碑。"
          continue
        }
        const pick = openNeighbors[Math.floor(Math.random() * openNeighbors.length)]
        next[r][c] = null
        next[pick.r][pick.c] = { kind: "bear" }
      }
    }
  }

  // chance to spawn a new bear
  const empties = emptyCells(next)
  if (empties.length > 6 && Math.random() < 0.12) {
    const pick = empties[Math.floor(Math.random() * empties.length)]
    const isNinja = Math.random() < 0.3
    next[pick.r][pick.c] = { kind: isNinja ? "ninjaBear" : "bear" }
    message = isNinja ? "一隻黑熊悄悄跳上了棋盤！" : "一隻熊闖進了棋盤！"
  }

  return { grid: next, gained, message }
}

function finishTurn(state: TripleTownState): TripleTownState {
  const hazard = hazardPhase(state.grid)
  const grid = hazard.grid
  const nextItem = drawNext()
  const empties = emptyCells(grid)
  const finished = empties.length === 0
  const score = state.score + hazard.gained
  const best = Math.max(state.best, score)
  return {
    ...state,
    grid,
    next: nextItem,
    score,
    best,
    finished,
    message: hazard.message ?? state.message,
  }
}
