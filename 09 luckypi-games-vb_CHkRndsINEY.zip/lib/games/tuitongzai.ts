// 推筒仔 (Pai Gow Tiles style domino game), using simplified mahjong-tile artwork per spec.
// 40-tile deck: 一筒(1)~九筒(9) x4 each (36 tiles) + 白板(blank, 0.5 pt) x4.

export const BET_MIN = 10
export const BET_MAX = 500
export const BET_STEP = 10

export type DoorId = "head" | "sky" | "tail" // 頭門 / 天門 / 尾門

export const DOOR_LABEL: Record<DoorId, string> = {
  head: "頭門",
  sky: "天門",
  tail: "尾門",
}

export interface Tile {
  id: string
  // rank 1-9 = 筒子; rank 0 = 白板 (blank)
  rank: number
}

function buildDeck(): Tile[] {
  const tiles: Tile[] = []
  let n = 0
  for (let rank = 1; rank <= 9; rank++) {
    for (let i = 0; i < 4; i++) tiles.push({ id: `t${n++}`, rank })
  }
  for (let i = 0; i < 4; i++) tiles.push({ id: `t${n++}`, rank: 0 })
  return tiles
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

export type HandRank =
  | { kind: "supreme" } // 至尊寶 雙白板
  | { kind: "pair"; rank: number } // 對子 (1~9)
  | { kind: "twoEight" } // 二八槓
  | { kind: "point"; value: number } // 0 ~ 9.5 (0 = 鱉十)

// Higher score = bigger hand. Ordering per spec:
// supreme(1000) > pair9..pair1 (900+rank) > twoEight(800) > point 9.5..0 (value*10)
export function handScore(h: HandRank): number {
  if (h.kind === "supreme") return 10000
  if (h.kind === "pair") return 9000 + h.rank
  if (h.kind === "twoEight") return 8000
  return h.value * 10 // point: 0 .. 9.5 -> 0..95
}

export function evaluateHand(tiles: [Tile, Tile]): HandRank {
  const [a, b] = tiles
  const ranks = [a.rank, b.rank].sort((x, y) => x - y)
  // 至尊寶：雙白板
  if (a.rank === 0 && b.rank === 0) return { kind: "supreme" }
  // 對子：兩張相同筒子（白板不算對子因為上面已處理雙白板，單白板+筒子不算對子）
  if (a.rank === b.rank && a.rank !== 0) return { kind: "pair", rank: a.rank }
  // 二八槓：2筒 + 8筒
  if (ranks[0] === 2 && ranks[1] === 8) return { kind: "twoEight" }
  // 一般點數：相加，白板算0.5，取個位數（含半點）
  const total = (a.rank === 0 ? 0.5 : a.rank) + (b.rank === 0 ? 0.5 : b.rank)
  const whole = Math.floor(total)
  const frac = total - whole
  const pointValue = (whole % 10) + frac
  return { kind: "point", value: pointValue }
}

export function handLabel(h: HandRank): string {
  if (h.kind === "supreme") return "至尊寶（雙白板）"
  if (h.kind === "pair") return `對子 · ${h.rank === 0 ? "白板" : h.rank + "筒"}對`
  if (h.kind === "twoEight") return "二八槓"
  if (h.value === 0) return "鱉十（0點）"
  return `${h.value % 1 === 0 ? h.value : h.value}點`
}

export function tileLabel(t: Tile): string {
  return t.rank === 0 ? "板" : `${t.rank}`
}

export type RoundPhase = "betting" | "revealed" | "settled"

export interface DoorState {
  id: DoorId
  bet: number
  tiles: [Tile, Tile] | null
  hand: HandRank | null
  result: "win" | "lose" | "push" | null
  payout: number
}

export interface TuiState {
  phase: RoundPhase
  deck: Tile[]
  doors: Record<DoorId, DoorState>
  bankerTiles: [Tile, Tile] | null
  bankerHand: HandRank | null
  activeDoor: DoorId
  message: string | null
}

const DOOR_IDS: DoorId[] = ["head", "sky", "tail"]

export function tuiInitial(): TuiState {
  return {
    phase: "betting",
    deck: [],
    doors: {
      head: { id: "head", bet: 50, tiles: null, hand: null, result: null, payout: 0 },
      sky: { id: "sky", bet: 50, tiles: null, hand: null, result: null, payout: 0 },
      tail: { id: "tail", bet: 50, tiles: null, hand: null, result: null, payout: 0 },
    },
    bankerTiles: null,
    bankerHand: null,
    activeDoor: "head",
    message: null,
  }
}

export function tuiSetBet(state: TuiState, door: DoorId, bet: number): TuiState {
  if (state.phase !== "betting") return state
  const clamped = Math.max(BET_MIN, Math.min(BET_MAX, bet))
  return { ...state, doors: { ...state.doors, [door]: { ...state.doors[door], bet: clamped } } }
}

// Payout multiplier per special-rate table (optional enhanced rates), base win = 1:1.
function specialMultiplier(hand: HandRank): number {
  if (hand.kind === "supreme") return 10
  if (hand.kind === "pair") return 4
  return 1
}

export function tuiDeal(state: TuiState): TuiState {
  if (state.phase !== "betting") return state
  const deck = shuffle(buildDeck())
  let i = 0
  const draw2 = (): [Tile, Tile] => [deck[i++], deck[i++]]

  const bankerTiles = draw2()
  const bankerHand = evaluateHand(bankerTiles)
  const bankerScore = handScore(bankerHand)

  const doors: Record<DoorId, DoorState> = { ...state.doors }
  for (const id of DOOR_IDS) {
    const tiles = draw2()
    const hand = evaluateHand(tiles)
    const score = handScore(hand)
    let result: "win" | "lose" | "push"
    if (score > bankerScore) result = "win"
    else if (score < bankerScore) result = "lose"
    else result = "push" // 同點/同牌型 -> 傳統視為莊家勝 (lose for player), but allow push flag then resolve
    // Per spec: tie => banker wins (player loses)
    if (result === "push") result = "lose"

    let payout = 0
    const bet = doors[id].bet
    if (result === "win") {
      const mult = specialMultiplier(hand)
      payout = bet * mult
    } else {
      payout = -bet
    }

    doors[id] = { ...doors[id], tiles, hand, result, payout }
  }

  return {
    ...state,
    phase: "revealed",
    deck,
    bankerTiles,
    bankerHand,
    doors,
    message: null,
  }
}

export function tuiSettle(state: TuiState): TuiState {
  if (state.phase !== "revealed") return state
  return { ...state, phase: "settled" }
}

export function tuiReset(state: TuiState): TuiState {
  const doors: Record<DoorId, DoorState> = { ...state.doors }
  for (const id of DOOR_IDS) {
    doors[id] = { ...doors[id], tiles: null, hand: null, result: null, payout: 0 }
  }
  return { ...state, phase: "betting", bankerTiles: null, bankerHand: null, deck: [], doors, message: null }
}
